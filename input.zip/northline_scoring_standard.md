
# Northline Distribution Cooperative assessment-center scoring standard

Control owner: Talent Measurement Office
Process: Frontline Operations Supervisor assessment center
Center dates: May 12-14, 2026
Decision meeting: May 19, 2026
Controlling anchor set: FOS behavioral anchors version 2.1

## 1. Record authority and review boundary

This standard governs whether assessment-center scores are ready for the talent review panel. It does not select candidates, establish promotion eligibility, or replace employment-counsel review. Candidate IDs remain anonymous in the measurement file. Demographic or protected-characteristic information must not be inferred from schedules, assessor assignments, scores, or notes.

The roster is the planned state. The administration export is the contemporaneous event record. The score export contains transaction history as well as signed submissions. Assessor and observer notes can establish what behavior was seen, when an event occurred, and whether a briefing or packet exposure happened; they are evidence, not case outcomes. Preserve disagreements among these sources. Resolve each one against the sufficiency tests below and state what the records still cannot prove.

## 2. Expected population and administration evidence

The center uses three exercises. INBOX scores PLANNING, JUDGMENT, and SAFETY. HUDDLE scores SAFETY, JUDGMENT, and COACHING. COACH scores COACHING, JUDGMENT, and PLANNING. A usable administration creates one PRIMARY and one SECONDARY opportunity for each mapped competency, or nine paired results per candidate across the center.

An administration is usable only when the combined record supports completion on the current packet, independent observation in both stated roles, and control of scored content. For an interruption or more than one event row, examine the stop point, material actually exposed, restart conditions, elapsed time, and assessor continuity together. Session-state labels are routing fields rather than conclusions. Preserve every event row and state any material uncertainty instead of choosing a record solely because it is later or cleaner.

The current packet register is I-2026.03 for INBOX, H-2026.05 for HUDDLE, and C-2026.02 for COACH. The retired H-2026.04 HUDDLE packet shares the general opening with H-2026.05 but uses a different scored incident card and response prompts. Exposure to shared administrative wording is not the same as exposure to a scored cue; the surviving chronology must establish which content was available and whether a later observation remained independent.

## 3. Record lineage and anchor-version review

Each exported score row is a transaction, not an accepted rating by itself. Review authorship, observed role, event timing, submission state, lineage, supersession, and linked evidence as one provenance chain. Planned coverage, administration initials, signed state, and narrative evidence answer different questions; none is a universal tie-breaker. A signature attests the entry but does not by itself prove live observation, and a numeric fragment in a worksheet does not by itself establish a complete assessor submission. When those facts conflict, document why the retained source has the stronger direct and contemporaneous support.

Version 2.0 and 2.1 are not globally interchangeable. Use this controlled crosswalk for the six level descriptors represented in the carryover records:

| Exercise | Competency | Level | Version 2.0 | Version 2.1 |
| --- | --- | ---: | --- | --- |
| INBOX | PLANNING | 3 | Workable sequence with priorities | Workable sequence with priorities and an explicit owner or completion checkpoint |
| INBOX | JUDGMENT | 3 | Defensible choice using the relevant facts | Defensible choice using the relevant facts |
| INBOX | SAFETY | 4 | Anticipation plus verification and follow-through | Anticipation plus verification and follow-through |
| COACH | COACHING | 2 | Partial diagnosis without shared understanding | Partial diagnosis with an attempt to check understanding, but no shared account |
| COACH | JUDGMENT | 3 | Defensible choice using the relevant facts | Defensible choice using the relevant facts |
| COACH | PLANNING | 4 | Adaptation with resource checks and a contingency | Adaptation with resource checks and a contingency tied to an observable trigger |

An older version label neither accepts nor rejects a record. Compare the descriptor governing the assigned level with the current descriptor and then test the contemporaneous behavior evidence. Retain a carryover only when the current level meaning is supported; if a material current element is not established, leave the item for re-anchoring. Do not convert an older rating by arithmetic.

For each candidate, exercise, and competency, a complete pair contains exactly one usable PRIMARY and one usable SECONDARY submission. Zero or multiple usable records in either role make the pair incomplete until the source conflict is closed.

## 4. Behavioral anchors and adjudication review

PLANNING distinguishes a basic sequence with gaps at level 2, a workable sequence with priorities and an explicit owner or completion checkpoint at level 3, adaptation with resource checks and a contingency tied to an observable trigger at level 4, and integrated monitoring across dependencies at level 5. JUDGMENT distinguishes an untested or incomplete choice at level 2, a defensible choice using the relevant facts at level 3, an adaptive choice that weighs consequences at level 4, and explicit testing of assumptions and second-order effects at level 5.

SAFETY distinguishes late or incomplete containment at level 2, timely containment with basic escalation at level 3, anticipation plus verification and follow-through at level 4, and integrated prevention, contingency, and team learning at level 5. COACHING distinguishes direction without diagnosis or listening at level 1, partial diagnosis with an attempt to check understanding but no shared account at level 2, clear diagnosis and feedback with limited check-back at level 3, perspective-taking plus verified understanding and joint action at level 4, and adaptive coaching with ownership and follow-through at level 5.

An absolute difference of two or more points is a quantitative screen, not an answer. Read the two assessor accounts with the observer chronology. Identify the behavior both sources support, the controlling anchor element, and any fact that remains genuinely unavailable. Record one of SUPPORT_PRIMARY, SUPPORT_SECONDARY, CONVERGE_AT_1 through CONVERGE_AT_5, or INSUFFICIENT_EVIDENCE. A recommendation does not alter either source rating and remains OPEN until the panel records formal adjudication.

## 5. Candidate score-release status

A candidate is READY only when all nine pairs are complete and no screened discrepancy remains formally open. The provisional overall score for a READY candidate is the mean of the nine pair means, rounded to two decimals. Every other candidate remains REVIEW with the provisional score blank. These are score-release controls, not promotion decisions.

The center is RELEASE only when every candidate is READY. Any incomplete source pair or open formal adjudication makes the center HOLD. HOLD describes the current score record; it is not a finding that the assessment method is invalid.

## 6. Calibration evidence

Use complete usable pairs for the quantitative screen. Within each assessor and exercise, signed difference is the assessor's rating minus the counterpart's rating. Report the mean to two decimals and the percentage within one point to one decimal percentage-point precision. At six or more observations, CALIBRATE is the quantitative flag when the absolute mean is at least 0.50 or the within-one rate is below 80.0 percent. Fewer than six observations is MONITOR; other cells are STABLE.

The quantitative flag is a starting point. Compare the full cell with the clean subset that has no screened discrepancy, test whether the mean depends on one counterpart, and inspect whether disagreements concentrate in one exercise, competency, or anchor distinction. A stable aggregate may still warrant a focused agenda item when the behavioral dossiers show the same anchor-reading problem more than once. Keep score eligibility, formal adjudication, and assessor development as separate decisions.

## 7. Panel handoff

Order the work by release impact and available evidence. Close missing or unusable source records that block pair construction, move evidence-sufficient discrepancy recommendations to formal panel action, identify evidence that must be recovered before an adjudication can proceed, and carry recurring anchor distinctions into calibration. State why a workstream comes before another instead of copying a fixed sequence.

The workbook must preserve the imported rows, distinguish raw facts from expert judgments, show the complete pair boundary, and retain live formulas for deterministic counts, rates, means, status tests, and downstream gates. Expert recommendations remain visible static review entries with exact evidence references; formulas must not manufacture them. No approval signature, release date, promotion decision, or legal validation is created by the workbook.
