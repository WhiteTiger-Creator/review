# Authorization field observations

These notes came from the April through July Saturday reconciliation reviews. They are observations, not approval records.

## 12 April - Sacramento central
The authorization export arrived before the processor file, but two reversals posted after the market closed. The processor batch and bank receipt agreed once the reversals were attached. Finance kept the batch on hold until the receipt number was entered in the case.

## 18 April - Riverside west
The market manager photographed a deposit slip, but the image did not show the bank trace number. Technology could match the processor batch to the authorization total; Finance could not close the deposit leg from that image alone.

## 25 April - Oakland lake
One terminal retried an authorization after a communications drop. The second approval code pointed to the same customer transaction. The duplicate was removed only after the reversal log and processor detail were compared.

## 2 May - Fresno tower
The processor file landed after the current review window. No funds were released from the working sheet. The following morning's file contained the batch and the market deposit matched it without a manual adjustment.

## 9 May - Stockton civic
A manager entered the gross sales amount instead of the net deposit. The difference equaled the recorded reversals. The row was corrected in the review copy, while the original entry stayed attached to the case history.

## 16 May - Bakersfield east
The vendor portal showed "complete" before the bank acknowledgement arrived. Finance treated the portal status as a claim, not proof. The hold cleared after the bank receipt and processor batch identifier were both present.

## 23 May - Sacramento river
The authorization file contained one void and one reversal with different timestamps. Technology linked both to the same terminal session. The evidence was sufficient for reconciliation but did not establish a new cutoff time.

## 30 May - Oakland plaza
Two small deposits were combined by the bank. The market manager supplied both deposit slips and the bank trace. Finance documented the split before changing the case from open to closed.

## 6 June - Fresno south
The processor detail omitted a merchant sub-identifier used by the local terminal. The amount matched, but the owner field did not. Technology opened a mapping case and Finance left the affected batch held.

## 13 June - Stockton north
The vendor's same-day acknowledgement arrived before the processor settlement file. The acknowledgement did not include reversal detail. Reviewers noted that faster status messaging would not remove the reconciliation step.

## 20 June - Riverside downtown
The deposit receipt was complete, but the authorization total had been exported before two late reversals. The corrected export reconciled without a journal entry. Both versions remain in the case file.

## 27 June - Bakersfield market hall
One batch carried an unusual bank holiday delay. The delay was documented as an exception rather than used to set a network rule. Finance asked for a separate test before any service schedule changes.

## 4 July - Sacramento central
High volume did not change the matching method. Reviewers used authorization gross less reversals, then compared that amount with the processor settlement and bank deposit. Three unmatched batches remained held at the meeting close.

## 11 July - Oakland lake
The market manager supplied a receipt with a handwritten batch number. Technology confirmed the number against the processor file. Finance accepted the evidence after the electronic receipt replaced the photograph.

## 25 July - Fresno tower
The vendor offered to move the file window but did not provide a signed schedule or numeric cutoff. The team recorded the proposal for commercial review and made no operating change.
