from pathlib import Path
import zipfile
from docx import Document

ROOT = Path(__file__).resolve().parent
required = [
    "veterinary_assistant_workforce_planning_brief.docx",
    "veterinary_assistant_workforce_planning_brief.pdf",
    "veterinary_assistant_workforce_planning_presentation.pptx",
    "rubric.xlsx",
]
for name in required:
    p = ROOT / name
    assert p.exists(), f"Missing required output: {name}"
    assert p.stat().st_size > 0, f"Empty output: {name}"

doc = Document(ROOT / "veterinary_assistant_workforce_planning_brief.docx")
text = "\n".join(p.text for p in doc.paragraphs)
required_markers = ["O*NET-SUPPORTED FINDING", "MANAGEMENT INTERPRETATION", "LOCAL VALIDATION GAP"]
for marker in required_markers:
    assert marker in text, f"Missing evidence marker: {marker}"

for phrase in [
    "task-based onboarding",
    "Assignment guidance",
    "Accuracy and escalation",
    "90-day review",
    "Tasks.xlsx",
    "Detailed Work Activities.xlsx",
    "Work Context.xlsx",
]:
    assert phrase.lower() in text.lower(), f"Missing required content: {phrase}"

assert "veterinary_assistant_workforce_planning_brief.docx" in [p.name for p in ROOT.glob("*.docx")]
print("Output checks passed.")
