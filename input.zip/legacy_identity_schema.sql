-- PostgreSQL 15 staging contract for the East Bay audience conversion rehearsal.
-- The loader preserves source identifiers exactly as supplied. Dates and timestamps
-- are parsed before this SQL decision pack is run.

CREATE TABLE stg_legacy_subscriber (
    profile_ref        text PRIMARY KEY,
    subscriber_no      text NOT NULL UNIQUE,
    given_name         text,
    family_name        text,
    delivery_address1  text,
    delivery_city      text,
    delivery_state     char(2),
    delivery_postal    text,
    service_status     text NOT NULL,
    updated_at         timestamptz NOT NULL,
    source_row         text NOT NULL UNIQUE,
    CHECK (profile_ref ~ '^L[0-9]+$'),
    CHECK (service_status IN ('ACTIVE', 'SUSPENDED_BILLING', 'CLOSED'))
);

COMMENT ON TABLE stg_legacy_subscriber IS
'Loaded from legacy_subscriber_snapshot.ndjson. Delivery fields are operational delivery data, not billing-authority evidence.';

CREATE TABLE stg_web_profile (
    profile_ref              text PRIMARY KEY,
    web_user_id              text NOT NULL UNIQUE,
    given_name               text,
    family_name              text,
    login_email              text,
    self_reported_address1   text,
    self_reported_city       text,
    self_reported_state      char(2),
    self_reported_postal     text,
    account_state            text NOT NULL,
    updated_at               timestamptz NOT NULL,
    source_row               text NOT NULL UNIQUE,
    CHECK (profile_ref ~ '^D[0-9]+$'),
    CHECK (account_state IN ('ACTIVE', 'LOCKED', 'CLOSED'))
);

COMMENT ON TABLE stg_web_profile IS
'Loaded from web_profile_snapshot.ndjson. Login email and self-reported postal data are not automatic winners.';

CREATE TABLE stg_match_edge (
    edge_id             text PRIMARY KEY,
    left_ref            text NOT NULL,
    right_ref           text NOT NULL,
    relationship_hint   text NOT NULL,
    basis               text NOT NULL,
    captured_at         timestamptz NOT NULL,
    CHECK (left_ref <> right_ref),
    CHECK (relationship_hint IN ('SAME_PERSON', 'HOUSEHOLD_ONLY'))
);

CREATE INDEX stg_match_edge_left_idx ON stg_match_edge (left_ref);
CREATE INDEX stg_match_edge_right_idx ON stg_match_edge (right_ref);

COMMENT ON TABLE stg_match_edge IS
'Loaded from match_edge_export.ndjson. Mirrored or repeated rows are expected and must be normalized as unordered pairs.';

CREATE TABLE stg_billing_party (
    ledger_id          text PRIMARY KEY,
    profile_ref        text NOT NULL,
    billing_party_id   text NOT NULL,
    authority_state    text NOT NULL,
    effective_from     date NOT NULL,
    effective_to       date,
    billing_name       text NOT NULL,
    postal_address1    text NOT NULL,
    postal_city        text NOT NULL,
    postal_state       char(2) NOT NULL,
    postal_code        text NOT NULL,
    CHECK (authority_state IN ('CURRENT', 'PROPOSED', 'EXPIRED')),
    CHECK (effective_to IS NULL OR effective_to >= effective_from)
);

CREATE INDEX stg_billing_party_profile_window_idx
    ON stg_billing_party (profile_ref, effective_from, effective_to);

COMMENT ON TABLE stg_billing_party IS
'Loaded from billing_party_ledger.jsonl. Only an effective CURRENT row may provide billing name and postal values.';

CREATE TABLE stg_newsletter_event (
    event_id        text PRIMARY KEY,
    profile_ref     text NOT NULL,
    event_type      text NOT NULL,
    email           text,
    event_at        timestamptz NOT NULL,
    channel         text NOT NULL,
    source_record   text NOT NULL UNIQUE,
    CHECK (event_type IN (
        'OPT_IN', 'OPT_OUT', 'DELIVERED', 'OPEN', 'BOUNCE', 'EMAIL_CORRECTION'
    ))
);

CREATE INDEX stg_newsletter_event_profile_time_idx
    ON stg_newsletter_event (profile_ref, event_at DESC, event_id DESC);

COMMENT ON TABLE stg_newsletter_event IS
'Loaded from newsletter_consent_events.jsonl. Only OPT_IN and OPT_OUT are explicit permission events.';

CREATE TABLE stg_merge_suppression (
    suppression_id    text PRIMARY KEY,
    profile_ref       text NOT NULL,
    scope             text NOT NULL,
    reason_code       text NOT NULL,
    effective_from    date NOT NULL,
    effective_to      date,
    case_reference    text NOT NULL,
    recorded_by       text NOT NULL,
    note              text,
    CHECK (scope IN ('IDENTITY_MERGE', 'NEWSLETTER_SEND', 'DATA_SALE_EXPORT')),
    CHECK (effective_to IS NULL OR effective_to >= effective_from)
);

CREATE INDEX stg_merge_suppression_profile_window_idx
    ON stg_merge_suppression (profile_ref, scope, effective_from, effective_to);

COMMENT ON TABLE stg_merge_suppression IS
'Loaded from merge_suppression_register.xml. Scope and effective window are controlling fields.';

CREATE TABLE stg_refund_case (
    case_link_id   text PRIMARY KEY,
    case_id        text NOT NULL,
    profile_ref    text NOT NULL,
    status         text NOT NULL,
    issue          text NOT NULL,
    opened_at      timestamptz NOT NULL,
    closed_at      timestamptz,
    note           text,
    CHECK (status IN ('OPEN', 'INVESTIGATING', 'RESOLVED', 'DENIED', 'CLOSED')),
    CHECK (issue IN ('OWNER_DISPUTE', 'DELIVERY_CREDIT', 'VACATION_CREDIT', 'DUPLICATE_PAYMENT')),
    CHECK (closed_at IS NULL OR closed_at >= opened_at)
);

CREATE INDEX stg_refund_case_profile_status_idx
    ON stg_refund_case (profile_ref, status, issue);

COMMENT ON TABLE stg_refund_case IS
'Loaded from refund_ownership_cases.ndjson. Only an open OWNER_DISPUTE controls merge eligibility.';

-- Loader-level source coverage check. The decision pack performs pair-level checks.
CREATE VIEW stg_all_profile_ref AS
SELECT profile_ref, 'LEGACY'::text AS source_system
FROM stg_legacy_subscriber
UNION ALL
SELECT profile_ref, 'DIGITAL'::text AS source_system
FROM stg_web_profile;
