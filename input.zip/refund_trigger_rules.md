# Guest recovery note — mobile concessions

This note was approved by Guest Experience and Concessions on 15 July 2026. It applies when a paid mobile order remains open during an arena event; it does not change payment-provider terms.

At a two-minute rolling p95 queue age of 300 seconds, the stand supervisor should receive a warning and the command center should prepare to reduce new admissions for that stand or menu class. At 420 seconds, new admissions are held. Recovery requires two consecutive measurement windows below the warning point.

When the oldest paid order reaches 600 seconds, the Guest Experience lead and Concessions service manager review guest messaging, pickup alternatives, and refund handling. Technology may supply timestamps and transaction state, but it does not approve a refund. A stand hold is not a blanket refund instruction; each recovery action follows the existing guest-service playbook and payment status.

The incident record should capture the affected stand, first warning window, hold time, recovery windows, oldest open transaction, guest messaging decision, and the names of the Concessions and Guest Experience owners. MetroPay joins only when authorization volume, declines, provider timeouts, or a provider error burst is involved.
