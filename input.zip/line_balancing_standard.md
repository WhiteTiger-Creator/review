# Calder Process Engineering - Line Balancing and Launch Readiness Standard (rev. 6)

Owner: Process Engineering
Effective: 2026-08-01
Scope: paced assembly lines at client sites ahead of a new-SKU launch certification

## Takt time

Takt time is net available time per shift divided by the customer's demand for that shift.
Net available time already has personal, fatigue, and delay allowance built into it; do not add a
further allowance station by station. A station's paced content must not exceed takt.

## Standard work is the record of truth

The time study summary is a rollup for review, not the record. A rebalancing decision must be
verified against `standard_work_elements.csv`, the elemental breakdown each station's summary
time is built from. An element appearing at more than one station with the same name and the same
time is a transcription duplicate, not two real operations, and must be corrected to appear once,
at the station where the operation is actually performed.

## Changeover and setup time

A changeover or setup that recurs more than once per SKU run - anything tied to a reel, a roll, a
tool life, or a similar consumable - must be performed by a floating material handler outside the
paced operator cycle, regardless of its size. It may not be added to a station's standard work
even when the station's paced content has room for it, because a periodic task performed by the
paced operator stalls the line on the units it lands on; averaging its time across the units
between occurrences does not describe what happens to the unit it actually hits. A changeover or
setup tied only to a SKU changeover, not to a per-unit or per-batch consumable, is not paced
content and is excluded from the takt comparison entirely; it runs while the line is already
stopped for the change.

## Moving work between stations

A rebalance may move a whole element from one station to another only when the destination
station is at or after the element's own station in line sequence, or when the element has no
precedence dependency recorded against it in `standard_work_elements.csv`. Moving an element ahead
of a step it depends on is not permitted regardless of available time. A destination station under
an active ergonomic constraint in `ergonomic_assessment.csv` may not receive additional paced
content until a new assessment clears it, even when the station shows available time against takt.
This restriction applies only to the station actually receiving the content. A station that a
moved element's origin and destination merely sit on either side of in line sequence is not a
destination, receives nothing, and is not restricted by this rule even if it carries its own open
ergonomic constraint - only a station named as the receiving end of a move is.

## Claims

A labor claim naming ergonomic strain, fatigue, or posture is a referral to an ergonomic
assessment, not evidence of available time to reallocate. Resolve the claim through the assessment
process regardless of what the standard work sheet shows for that station, and do not use it to
justify moving paced content off the station unless the standard work sheet independently shows
time to move.

## Prior launches

A rebalance performed for a prior SKU family is background only. It is not authority for the
current line unless every input it depended on - the labor agreement's allowance, the station
count, and the fixture set - is confirmed unchanged for this launch.

## Certification

State the achievable output at the corrected, fully paced bottleneck, not at the station the
original summary happened to flag, and not as an average that a periodic stall would understate.
Recommend GO only when every paced station's corrected content is at or under takt and every
recurring changeover is off the paced cycle. A GO recommendation may carry named conditions that
do not by themselves block launch. Recommend HOLD if a paced station's corrected content still
exceeds takt, or if a required ergonomic clearance is outstanding for a station the plan depends
on.

## Verification before certification

Confirm the corrected total content per SKU family reconciles to the original elemental sum before
and after any move - a rebalance that changes the total is a content addition or loss, not a
move, and must be explained. Confirm no ergonomic-constrained station receives new paced content from any move. Confirm
no precedence violation was introduced. Confirm every recurring changeover in
`changeover_time_table.csv` is accounted for as off-cycle content, not folded into a station's
paced total.

## Sign-off

Process Engineering owns the corrected standard work and the rebalance. Industrial Relations owns
the ergonomic referral on any open claim. Materials owns staffing the floating material-handler
role for reassigned changeovers. The client's Manufacturing Engineering lead signs the
certification before the line is released for the launch build.
