# Kilbride Verification Partners - Test Quarantine Policy

Owner: Verification Practice
Applies to: all automated test suites run against client firmware.

## What quarantine means

A test case is quarantined when it has produced an inconsistent result against the same build on
repeated runs, or when its automation is known to be unreliable for a documented reason. A quarantined
test case does not count as verification evidence for any requirement while it remains quarantined,
regardless of the result recorded in the run log. This applies retroactively: a run recorded before a
test case was quarantined does not become evidence again if the test case is later released from
quarantine without being re-run against the build under verification.

## Requalification

A quarantined test case is requalified by fixing the underlying automation defect, then re-running it
at least three times against the build under verification with a consistent result. Requalification is
recorded in the test case inventory as a status change, not in the run log. Until requalification is
recorded, every run of that test case, past or future, is excluded from verification evidence.

## What quarantine is not

Quarantine is not a mechanism for excluding a test whose result is inconvenient. A test that fails
consistently and correctly is not quarantined; it is a defect. Only tests with genuinely inconsistent
or unreliable automation are eligible.
