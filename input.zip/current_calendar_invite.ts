type Booking = {
  bookingId: string;
  bookingVersion: number;
  officeId: string;
  officeTz: string;
  officeLocalStart: string;
  startUtc: string;
  endUtc: string;
  clientDisplayZone?: string;
};

function compactLocal(value: string): string {
  return value.replace(/[-:]/g, '').replace('T', 'T');
}

export function createInvite(booking: Booking): string {
  // RC2 reconstructs from the label and emits a floating date-time.
  const dtstart = compactLocal(booking.officeLocalStart);
  const durationMs = new Date(booking.endUtc).getTime() - new Date(booking.startUtc).getTime();
  const reconstructedEnd = new Date(new Date(booking.officeLocalStart).getTime() + durationMs);
  const dtend = compactLocal(reconstructedEnd.toISOString().slice(0, 19));
  return [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'BEGIN:VEVENT',
    `UID:${booking.bookingId}@linden.example`,
    `SEQUENCE:${booking.bookingVersion}`,
    `DTSTART:${dtstart}`,
    `DTEND:${dtend}`,
    `DESCRIPTION:Office time ${booking.officeLocalStart}`,
    'END:VEVENT',
    'END:VCALENDAR',
  ].join('\r\n');
}
