# Presslee Components - Launch Order PC-204R / PC-118S

Customer: Presslee Components
Line: Assembly Line 3, Building 2
Launch build date: 2026-09-21
Certification due: 2026-09-14

## Demand

Presslee has ordered 320 units per shift across the two SKUs in this launch family, PC-204R and
PC-118S, on a single mixed-model paced line. One shift is scheduled per day during ramp.

## Shift schedule

Net available time per shift, after breaks and the standard personal/fatigue/delay allowance, is
26,880 seconds. This is the figure to use for takt; it already reflects the allowance in
`line_balancing_standard.md`.

## Launch conditions

Presslee's own receiving inspection samples every 20th unit; three consecutive rejected samples
pause receiving until Calder issues a corrective disposition. Presslee has not pre-approved any
schedule slip past the 2026-09-14 certification date; a HOLD recommendation must state what has to
be true before certification can be revisited.
