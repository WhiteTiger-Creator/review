# ASC X12 837P 5010 - National Implementation Guide (excerpt)
# Sections 3.4, 3.6, and 4.1, professional claim loops

## 3.4 Diagnosis coding (HI segment)

Every diagnosis pointer must carry a qualifier identifying the code set. The principal diagnosis
qualifier is ABK for ICD-10-CM. The legacy qualifier BK, used for the ICD-9-CM transition, was
withdrawn nationally as of the prior implementation guide release and must not appear on any claim
regardless of payer. A claim that emits BK is non-conformant on its own terms, independent of any
payer's companion guide.

## 3.5 Referral number (REF*9F, loop 2300)

Situational. Required only when the claim indicates a referral was obtained (referral indicator
present and equal to Y). When present, the referral number must be transmitted as it was assigned by
the referring entity, in the format R- followed by five digits. A referral number sent without the
required prefix is non-conformant against this guide, independent of which payer receives the claim.

## 3.6 Line item control number (REF*6R, loop 2400)

Situational. Required only when a payer's companion guide requests it for line-level tracking. Absent a
payer requirement, this element is not used. A clearinghouse mapping is not required to populate it by
default, and doing so for a payer that does not request it is not itself a defect.

## 4.1 Paperwork segment (PWK, loop 2300)

Optional. Used to indicate that supplemental documentation exists for the claim. Payers vary in whether
they accept unsolicited PWK segments; absent a payer restriction, sending PWK when supplemental records
exist is conformant.
