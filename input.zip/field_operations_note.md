# Field operations note: how the last two waves were actually run

Upper Midwest Manufacturers Alliance
From: T. Oyelaran, Field Operations Manager
To: Northlake Research Group
Date: 2026-08-31

Northlake asked how the 2024 and 2025 waves were fielded, because the response
figures in the outcomes file are not comparable across the two years for every
band. They are not, and the reason is a protocol difference that only affected
part of the membership. This note sets out what happened so the planning rates
for 2026 are chosen on the right basis rather than on the most recent number in
the file.

## 1. The standing protocol

Both waves used the same core protocol for the whole membership:

- A mailed invitation to the survey contact of record, posted in the first week
  of the field period.
- A first email reminder at the end of week two.
- A second email reminder at the end of week four.
- No incentive, in either wave, for any band.

Field windows were comparable. The 2024 wave ran 14 October to 22 November
2024. The 2025 wave ran 13 October to 21 November 2025. Neither window included
a plant shutdown period of the kind that would depress returns from the larger
sites.

## 2. What was different in 2025

In 2025 we received a one-off grant from the state manufacturing extension
partnership, earmarked for improving returns from larger establishments. We
used it to add a telephone follow-up, staffed by a temporary two-person team
working from the survey contact list.

The telephone follow-up was applied to bands C and D only. That was a
deliberate choice and it was written into the grant: the money was for the
larger-establishment cells, which are the ones our members complain about most
when the report is thin. Bands A and B received the standing protocol in 2025
and nothing more.

The effect was large and it was confined to the two bands that got it. Bands C
and D returned noticeably better in 2025 than in 2024. Bands A and B moved very
little between the two years, which is what you would expect from two waves run
the same way in comparable windows.

## 3. What the 2026 wave will fund

The grant was a single award and it has been spent. There is no telephone
follow-up in the 2026 budget and there will not be one. The 2026 wave runs the
standing protocol for every band: mailed invitation, two email reminders, no
telephone stage, no incentive.

I want to be plain about the consequence, because it is the whole reason for
this note. The 2025 outcomes for bands C and D describe a protocol we are not
running again. Planning the 2026 sample on those numbers would assume a
telephone stage that does not exist and would under-invite the two bands that
can least afford it. For bands A and B the two waves are directly comparable,
and the more recent of them is the better guide.

## 4. Other operational points

Undeliverable records. Both waves record an establishment as undeliverable
where the mailed invitation returned and no working email address was held.
These are counted separately from ineligibles, which are establishments found
during the field period to be out of scope.

Partial responses. A partial is a questionnaire that was opened and abandoned
before the wage grid was completed. We record them because they tell us
something about instrument length, but a partial supplies no wage data and we
have never treated one as a complete.

Contactability. We hold a working survey contact for effectively the whole
membership, so invitation volume is limited by the size of the band and not by
our ability to reach it. Where a plan calls for more invitations than a band
contains, the band is simply too small for what is being asked of it, and no
amount of field effort changes that.

Capacity. We can field the invitation volumes the plan is likely to call for
without difficulty. The constraint this year is the completes budget, not the
mailing.
