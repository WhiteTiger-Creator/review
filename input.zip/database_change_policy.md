# Database Change Control - Production Data Removal

Hollis Data Services, applies to every client platform under a managed records agreement
Owner: Database Practice
Revision: 9

## Scope

Any statement that removes production customer data, including partition operations, runs under this
policy. Reads and reversible schema additions do not.

## Required properties of a removal change

1. The change set is a single reviewable file. No ad hoc statements at the prompt.
2. Every removal is bounded by an explicit predicate. `DELETE` without a `WHERE` clause, or a partition
   drop without a named partition, is rejected at review.
3. The change set records the expected row count for each statement before it runs, taken from an
   inventory query, and the runbook compares the actual count against it.
4. Removals run in batches of at most 50,000 rows with a commit between batches, so a long-running
   statement cannot hold locks across a billing window.
5. The change set is idempotent. Re-running it after a partial failure must not remove additional rows
   beyond the original scope.
6. A dry run against the same predicates is captured and attached before the change is scheduled.

## Verification and rollback

A removal is verified by a post-run count on the same predicate returning zero, and by a retained-set
count matching the pre-run inventory for every account excluded from the purge. Interval data is not
recoverable from the operational database once removed; the only rollback is a restore from the nightly
snapshot, which is retained for 14 days. A restore returns the entire tablespace, not selected rows, so
a purge that removes held records is a reportable incident rather than a correctable error.

## Approvals

The client's Records and Information Governance function approves the exception set. The client's Legal
function approves any purge that touches an account named in an open matter. The Hollis database
practice approves the statements. All three sign before
the window opens.
