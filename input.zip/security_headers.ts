export type HeaderMap = Record<string, string>;

const REPORT_ONLY_POLICY = [
  "default-src 'self' https:",
  "script-src 'self' 'unsafe-inline' 'unsafe-eval' https:",
  "style-src 'self' 'unsafe-inline' https:",
  "img-src 'self' data: https:",
  "connect-src 'self' https: wss:",
  "frame-src *",
  "worker-src 'self' blob:",
  "object-src 'self' data:",
  "report-uri /api/csp-report",
].join("; ");

export function securityHeaders(_pathname: string): HeaderMap {
  return {
    "Content-Security-Policy-Report-Only": REPORT_ONLY_POLICY,
  };
}
