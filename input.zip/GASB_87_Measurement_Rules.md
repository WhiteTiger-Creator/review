Ozark Ridge County, Missouri
Accounting Division, CAFR working paper
File: GASB_87_Measurement_Rules.md
Prepared: 22 July 2026
Applies to: FY2026 ACFR Note 8, measurement date 30 June 2026
Prepared by: County accountant desk (lease note)

This file is the measurement method for the FY2026 lease note. Use it with County_IBR_Table_FY2026.csv. Do not substitute ORC_Lease_Admin_SOP.md.

1. Measurement date
Fiscal year-end is 30 June 2026. Remaining payments, remaining term, and the payment in force are taken at that date. A later amendment does not change the 30 June number.

2. Identified asset (GASB 87 ¶12)
A contract is a lease on this note only if it conveys control of an identified physical asset (building, land, vehicle, tower, equipment). A vendor-hosted software subscription with no identified physical asset is Nonlease here. Do not apply GASB 96 in this workbook. ORC_IT_Contract_Inventory.csv is the support file for whether an IT contract has a physical asset.

3. Short-term (county application of GASB 87 para. 16 to 18)
If remaining_term_months on ORC_Lease_Abstracts.csv is 12 or less and purchase_option is N, classify Short-term. Do not record a lease liability. Remaining short-term cash (remaining_term_months × fixed monthly payment in force) is expense only. A purchase option takes the contract out of Short-term even if remaining term is 12 months or less.

4. Hold
If commencement_date is blank, or remaining_term_months is blank, classify Hold. Do not fill a date or a term from an invoice, a verbal start, or the SOP. Held contracts have closing liability $0.00 on this note. List each Hold on Exception_Log with the missing field.

5. Incremental borrowing rate (GASB 87 ¶34 as applied here)
The lessor rate is not stated on any of these contracts. Use the county incremental borrowing rate. Match remaining_term_months to County_IBR_Table_FY2026.csv (term_months_from through term_months_to, inclusive). Use that ibr_annual. Monthly rate = ibr_annual / 12. The 6.00 percent operations rate on the SOP and on the sop_rate column of the abstracts is not an IBR for this note.

6. Payments that enter present value (GASB 87 ¶22)
Present value uses the fixed monthly payment in force at 30 June 2026. Variable payments that depend on usage (miles, copies, overtime hours) stay out of the liability, including the variable_monthly_est column on the abstracts and variable_paid_fy2026 on the payment register. Index-based rent is not present on this population. Nonlease components that are stated separately stay out.

7. Present value
Let r = IBR_annual / 12 and n = remaining_term_months.
Liability = ROUND(PMT × (1 − (1 + r)^(−n)) / r, 2) when r > 0 and n > 0.
PMT is the fixed monthly payment in force at 30 June 2026 after any amendment effective on or before that date. For L-12, L12_Clinic_Annex_Amendment.pdf is the in-force rent if it differs from ORC_Lease_Abstracts.csv.

8. Status
Recognize: identified physical asset, facts complete, and either remaining term over 12 months or a purchase option.
Short-term: section 3.
Nonlease: no identified physical asset.
Hold: section 4.

9. Rollforward
Opening liability is opening_liability_2025-07-01 on the abstracts.
FY2026 implied interest for this note = ROUND(opening × IBR_annual, 2).
FY2026 principal reduction = ROUND(fixed_paid_fy2026 − implied interest, 2), not below zero.
Closing liability for Recognize contracts = the section 7 present value. Closing liability for Short-term, Nonlease, and Hold = 0.
A mid-year amendment (L-12) is a remeasurement. The rollforward will not foot to closing PV by opening minus principal. Closing is still the section 7 PV.

10. What the SOP cannot do
ORC_Lease_Admin_SOP.md may explain the 173-lease-liability posts. It cannot set the IBR, treat a remaining term of 12 months or less with no purchase option as a capitalized lease, or pull variable mileage into present value. It cannot supply a missing commencement date.

11. Source order when files disagree
  1. This file, for recognition, Hold, short-term, PV, and variable exclusion.
  2. County_IBR_Table_FY2026.csv, for the rate.
  3. L12_Clinic_Annex_Amendment.pdf, for L-12 PMT in force at 30 June 2026.
  4. ORC_Lease_Abstracts.csv, for term, asset, commencement, and the unamended payment.
  5. ORC_Payment_Register_FY2026.csv, for FY2026 cash on the rollforward.
  6. ORC_IT_Contract_Inventory.csv, for whether L-06 has a physical asset.
  7. ORC_Lease_Note_Request.txt, for the assignment only.
  8. ORC_Lease_Admin_SOP.md, for how rent was booked. Not a measurement source.

12. Note call
On Note_Cover pick one:
  post as measured: every priced contract is Recognize and the liability includes the full book.
  post after listed exclusions: Recognize contracts are complete; Short-term, Nonlease, and Hold are listed and kept off the liability.
  hold the note: Recognize contracts cannot be priced because required facts are missing.

13. Exception ranking
Rank Short-term remaining cash, Hold, Nonlease, and any variable amount kept out of PV by the dollars kept out of the liability, largest first. Tied amounts may share a rank. Short-term remaining cash is remaining_term_months times the fixed monthly payment. Variable dollars kept out of PV are remaining_term_months times variable_monthly_est. Do not rank a variable exclusion on a single month of variable_monthly_est. Hold and Nonlease with no priced cash kept out are $0.00. Point each item at GASB_87_Measurement_Rules.md (this file), County_IBR_Table_FY2026.csv, or L12_Clinic_Annex_Amendment.pdf.
