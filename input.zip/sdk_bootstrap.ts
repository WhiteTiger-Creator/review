/**
 * SDK entry point. Resolves which merchant is embedding us, wires the checkout steps, and
 * runs any pending client-side migration before the first step mounts.
 *
 * Shipped in 3.8.2.
 */

import { migrate, readCart, writeCart, V2Cart } from "./cart_store";

declare const __SDK_BUILD__: string;

export interface ResolveResponse {
  merchantId: string;
  channel: "loader" | "channel" | "pinned";
  features: Record<string, boolean>;
}

let resolved: ResolveResponse | null = null;

export async function resolveMerchant(publicKey: string): Promise<ResolveResponse> {
  const response = await fetch(
    `https://cdn.sedlak-commerce.example/sdk/resolve?k=${encodeURIComponent(publicKey)}`,
    { credentials: "omit" },
  );
  resolved = (await response.json()) as ResolveResponse;
  return resolved;
}

export function feature(name: string): boolean {
  if (!resolved) return true;
  return resolved.features[name] !== false;
}

export function currentBuild(): string {
  return typeof __SDK_BUILD__ === "string" ? __SDK_BUILD__ : "unknown";
}

function readPublicKey(): string {
  const tag = document.currentScript as HTMLScriptElement | null;
  const fromTag = tag?.dataset?.sedlakKey;
  if (fromTag) return fromTag;
  const fallback = document.querySelector<HTMLElement>("[data-sedlak-key]");
  return fallback?.dataset?.sedlakKey ?? "";
}

export async function boot(): Promise<V2Cart | null> {
  const key = readPublicKey();
  if (!key) {
    console.warn("[sdk] no merchant key on the page; checkout will not mount");
    return null;
  }

  await resolveMerchant(key);
  console.log("[sdk] build", currentBuild(), "merchant", resolved?.merchantId);

  const cart = migrate();
  if (cart) {
    writeCart(cart);
  }

  return readCart();
}

export function mount(): void {
  void boot().then((cart) => {
    document.dispatchEvent(new CustomEvent("sedlak:cart-ready", { detail: cart }));
  });
}

if (typeof window !== "undefined") {
  mount();
}
