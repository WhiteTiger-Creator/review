#include<cstdlib>

#include"functions_to_wrap.h"

const char *get_string(){
	int id = rand()%5;
	const char *str[] = {
		"hello world!",
		"this is function get_string()",
		"booyah!",
		"foo",
		"bar"
	};
	
	return str[ id ];
}

bool are_values_equal( int a, int b ){
	return a == b;
}

int num_arguments( bool arg0, bool arg1, bool arg2, bool arg3 ){
	if( !arg1 ) return 1;
	if( !arg2 ) return 2;
	if( !arg3 ) return 3;
	return 4;
}