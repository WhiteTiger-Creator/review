# Master supply agreement, schedule C
# Locklear Instrument Company and Ruvalcaba Clinical Labs
# Volume rebate schedule, executed 2026-03-11, effective for program year one.

## C.1 Program year

Program year one runs from 2026-04-01 through 2027-03-31.
Eligible purchases are the stated contract prices of new contracts and of amendments to existing
contracts executed by Ruvalcaba Clinical Labs with Locklear during the program year, measured
across all of the customer's sites and aggregated at the parent level. Consideration under
contracts executed before the program year opened is not eligible, whatever the delivery date,
and neither is any amount invoiced for freight, duties, third party software or pass through
regulatory fees.

A contract counts against the program year in which it was executed. An amendment counts against
the program year in which the amendment itself was executed, which may differ from the year of
the contract it amends. Cancelled orders are removed from eligible purchases; partially delivered
orders are not, because the schedule measures orders placed rather than goods shipped.

## C.2 Tiers

The rebate is retrospective. Once cumulative eligible purchases reach a tier during the program
year, the rebate percentage for that tier applies to all eligible purchases in the program year,
including purchases made before the tier was reached.

- Tier 1: cumulative eligible purchases of 0 dollars up to but not including 400,000 dollars. Rebate 0.0 percent.
- Tier 2: cumulative eligible purchases of 400,000 dollars up to but not including 750,000 dollars. Rebate 2.5 percent.
- Tier 3: cumulative eligible purchases of 750,000 dollars and above. Rebate 4.0 percent.

Only one tier applies at a time. The tier reached at the end of the program year governs the
final settlement. Tiers do not carry forward: cumulative purchases reset to nil at the start of
each program year and no tier attained in one year entitles the customer to that tier in the
next.

## C.3 Settlement

Locklear issues a credit note within forty five days of the end of the program year. The customer
may not offset the expected rebate against open invoices before the credit note is issued, and
may not net it against any other claim. Interim purchase reporting is available to the customer
on request; Locklear does not publish a running total unless asked, and no running total has been
requested in program year one.

Where the parties disagree on the cumulative figure, each party's own order records govern its
own submission and the difference is resolved from the executed contracts and amendments rather
than from either party's reporting.

## C.4 Audit and records

Either party may ask, once per program year and on thirty days notice, for the other's schedule
of eligible purchases for that year. The request is limited to order documents and amendment
records. It does not extend to cost, margin or pricing information, to records of any other
customer, or to any period outside the program year under review.

## C.5 Other terms

The schedule does not create a minimum purchase commitment, does not oblige the customer to buy
any product, and does not entitle the customer to return goods or to cancel a delivered order. It
applies only to Ruvalcaba Clinical Labs and may not be assigned without written consent. No other
customer in the region holds a rebate schedule in program year one.

The schedule terminates with the master supply agreement. If the agreement ends part way through
a program year, the tier is determined on eligible purchases to the termination date and settled
within forty five days of that date.

Notices under this schedule go to the Locklear contract administration desk and to the customer's
procurement director at the addresses in the master supply agreement.
