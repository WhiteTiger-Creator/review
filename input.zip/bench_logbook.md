# August spectrum replay bench log

**Mon 17 Aug, Raleigh lab**

Started the steady captures after lunch once the RF enclosure had settled. revC and revD are both on the table because the rooftop unit pool is mixed and we need to know whether the sketch behavior is tied to the receiver hardware. The first hour looked ordinary. Exact counter and sketch processes were pinned to the same host cores we used in July; the only intentional software change is the r43 sketch build. I left the receiver firmware mixed rather than upgrading everything because several rooftop boxes are still on 3.8.14.

At 14:31 the fan controller on the replay host stopped following its curve. RX-VX52K finished, but the package temperature was visibly climbing and the process did throttle before the end. I repeated that trace after resetting the controller and wrote the second capture under a new tag. Keep the first tag in the archive for the hardware team, but it is not a fair performance sample. Later, RX-MDPGV showed a PTP offset wandering well outside the rest of the day. The sync lead was only finger-tight. We reseated it and repeated the same trace; the replacement behaved normally.

One useful check from Monday: healthy 3.8.14 runs on both receiver revisions track the 3.8.16 runs closely. The sync problem is a capture-quality issue, not a reason to throw out every older-firmware result. The r43 code itself was not rebuilt between runs.

**Tue 18 Aug**

Hopping traces today. These are closer to the load we see around campus APs, with energy moving across neighboring 20 MHz bins rather than sitting in one place. The sketch is mostly following the exact top channels, although the fifth position is visibly less stable than it was in the steady set. That is expected to be the place where a 64 KiB structure gets squeezed, so I did not stop the campaign for single-position swaps.

RX-2TLAR is another host-cooling repeat. This one completed cleanly from the collector's point of view, but it ran during the same stuck fan episode we reproduced while checking the controller. The repeat is the one we should use. RX-TE5FU was the only hopping run where the time discipline did not settle after launch. We found the strain-relief on the sync lead pulling against the connector, moved the cable, and reran it. RX-S9HXU has a different problem: the collector dropped a block of frames and the log shows a gap long enough to swallow an entire hop. I would not compare channel ranks from that capture. The later repeat has no gap.

The revD pad is not showing up as a ranking change. Absolute occupied-frame counts differ a little, which is normal for the gain difference, but the ordering around the top of the list is behaving similarly on revC and revD.

**Thu 20 Aug**

Bursty set after Wednesday was lost to the chamber booking. This is the difficult replay: short high-duty bursts separated by quiet periods, with several channels close to the fifth-place cutoff. r43 still keeps the obvious leaders, but there are more swaps around ranks four through seven. That is the behavior we were worried about when we chose the rooftop gate around top-five recall instead of mean count error.

RX-UBM3F was captured while we were confirming the fan-controller fault under a heavier replay rate and should stay out of the comparison. RX-U6EYK had the same loose-sync signature as Monday, and RX-GV4TV has a clean clock but a large collector gap. All three were repeated before we shut the bench down. Nothing in the replacement runs suggests a persistent receiver fault.

I spot-checked a handful of the valid bursty traces by plotting exact and sketch counts. The misses are mostly threshold crossings: the sketch brings the sixth or seventh channel just above the fourth or fifth. Two traces also flip the first and second positions, but both channels stay in the top five. That matters for interpretation because the main failure is shortlist stability, not a wholesale loss of the strongest energy.

**Campaign closeout**

No counter saturation was reported in r43. Memory use is consistently much lower than the exact map, while CPU time per 10k frames is a little higher because of the hash updates. The field question is therefore not whether the implementation runs; it is whether the accuracy loss in the bursty condition is acceptable for the next rooftop slot. I have left every raw tag in the exports, including the captures we repeated, so the archive remains complete. Use the repeat history above when separating bench trouble from algorithm behavior.
