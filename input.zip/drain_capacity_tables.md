# Manufacturer flow capacities
## Extracted from the product data sheets for the drains and scuppers on this roof

Provided so the calculations in this file set can be checked without going back
to the manufacturers. These are the published values for the models installed.

### Eight inch cast iron roof drain with dome strainer

Flow in gallons per minute against the head of water measured above the drain
rim:

  * 1.0 inch of head: 125 gpm
  * 1.5 inches: 205 gpm
  * 2.0 inches: 280 gpm
  * 2.5 inches: 395 gpm
  * 3.0 inches: 500 gpm
  * 3.5 inches: 630 gpm
  * 4.0 inches: 760 gpm

Interpolate linearly between tabulated heads. The published values already
account for the dome strainer at full open area. The manufacturer's note says
the values do not hold where the strainer is obstructed and that no partial
obstruction factor is published.

### Type SC-1 through wall scupper, 24 inches wide by 4 inches high

Flow in gallons per minute against the head of water measured above the scupper
invert:

  * 1.0 inch of head: 80 gpm
  * 2.0 inches: 220 gpm
  * 3.0 inches: 400 gpm
  * 4.0 inches: 620 gpm

The scupper is a weir. It carries nothing at all until the water surface reaches
its invert, and it therefore sets the maximum depth water can reach on the roof
rather than draining the roof. Water below the scupper invert can only leave
through the primary drains.

### Ponded water

Water on a roof weighs 5.2 pounds per square foot per inch of depth.

### How the published values were produced

Both manufacturers test to the industry flow test standard for roof drainage
products, which puts the product in a test flume, raises the water surface in
steps and records the discharge at each step once the surface has stabilized.
The values are therefore steady state discharges at a held head and not peak
instantaneous rates. For a storm the length of the one under consideration that
distinction does not matter, because the water surface on the roof holds at or
near a constant depth for far longer than the tank takes to stabilize.

The drain values are for the drain assembly as a whole: the body, the dome
strainer and the clamping ring. The manufacturer states that the eight inch
drain body and an eight inch leader at the slopes normally used are not the
limiting element at any head in the table, so the tabulated flow is what the
assembly passes and there is no separate pipe capacity check to run against
these numbers.

### Installation conditions the published values assume

The published drain values assume the drain sits at the low point of its
tributary area with the membrane and insulation sloped into the sump on all
sides, so that the head measured above the rim is the head actually available.
Where the surrounding roof is higher than the rim by more than the sump can
absorb, water reaching the drain is limited by what the sump can gather rather
than by what the drain can pass, and the manufacturer declines to publish a
value for that condition.

The scupper values assume a clear opening at the stated width and height with a
smooth sleeve, no screen and no debris guard. A screen reduces the discharge and
the manufacturer's guidance is that a screened scupper should be taken at three
quarters of the tabulated flow. There are no screens on the scuppers at this
building.

### Obstruction

The manufacturer's note on the drain table says the values do not hold where the
strainer is obstructed and that no partial obstruction factor is published. In
practice a drain with a packed strainer is treated as out of service rather than
derated, because the discharge through a partly blocked strainer depends on the
character of the debris and cannot be predicted from the open area. That is a
conservative convention and it is the one this office uses.

### Warranty

Neither manufacturer's warranty is affected by the head at which a drain is
operated. The drain warranty is a materials and workmanship warranty on the
casting and it runs for the life of the roof assembly. The scupper sleeves are
covered under the membrane manufacturer's system warranty, which requires the
roof to be inspected twice a year and the drains kept clear, and which is void
where that has not been done.
