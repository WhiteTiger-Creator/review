# Help-desk notes from gate opening

These are the notes retained from the incident queue. Times are Central unless noted.

**HLP-7814 - 11:12, North Gate.** A weekend badge purchased on 30 July showed "not entitled" on SCN-N04. The agent confirmed the badge had not been used. Caller: gate lead M. Alvarez. Disposition at 12:06: restored after the cache update; no badge reissue.

**HLP-7819 - 11:19, East Gate.** Two guests returned from the parking lot and both badges admitted again. The gate lead had seen a successful first entry for each badge. Technology asked the lead to stop repeated test scans and retain the badge hashes. Linked scanner: SCN-E11.

**HLP-7823 - opened 11:23.** The vendor bridge was started after Operations escalated the North and East reports. The vendor's incident email later used the bridge-open time as the beginning of impact. The ticket history itself includes the earlier 11:12 call.

**HLP-7831 - 11:31, South Gate.** SCN-S09 uploaded a delayed batch. The scanner time and cache receipt are more than six minutes apart. The row was not deleted; it remains unresolved for the clock review.

**HLP-7840 - 11:43, River Gate.** Attendants were using a manual clicker while the queue moved. The caller did not report an outage of the handhelds; the complaint was inconsistent decisions between scanners.

**HLP-7852 - 11:57, North Gate.** M. Alvarez reported that the used-badge control now denied entry and the unused control admitted. Ticket remained open until East repeated the pair at 11:58.

**HLP-7855 - 12:04, East Gate.** R. Patel confirmed the second control pair. The incident queue was changed from active to monitoring. This ticket records service restoration only; it does not approve a credit or close the corrective action.

The help-desk supervisor did not accept ownership of the cache defect. Technology retained that evidence task, and Finance requested the reconciled counts before discussing the invoice.
