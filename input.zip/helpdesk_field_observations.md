# Help-desk incident notes

Times are Central as entered by the desk; they are not scanner-clock corrections.

**HLP-7814 | 11:12 | North.** A weekend badge purchased on 30 July displayed “not entitled” on SCN-N04. The lead confirmed it had not been used. At 12:06 the lead said normal scanning had returned.

**HLP-7819 | 11:19 | East.** Two guests returned from the parking lot and both badges admitted again. The lead had seen a first entry for each. Technology asked for badge hashes and stopped further test rescans.

**HLP-7823 | 11:23 | Vendor bridge.** Operations escalated the North and East reports. BadgeServe later used this bridge-open time in its incident summary. The ticket history retains the earlier call and control reference.

**HLP-7831 | 11:31 | South.** SCN-S09 uploaded a delayed batch. The desk retained the scanner and cache timestamps and left the batch open for clock review.

**HLP-7840 | 11:43 | River.** Attendants used a manual clicker. The caller described inconsistent badge decisions, not a handheld or network outage.

**HLP-7852 | 11:57 | North.** The used control denied and unused control admitted on generation 9125. The ticket stayed active until East ran its pair.

**HLP-7855 | 11:58 | East.** The second pair passed. The queue moved from active to monitoring; this did not accept the contractual correction evidence.
