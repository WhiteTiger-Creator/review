# FE-2026-117 field installation and inventory record

**Compiled by:** Marisol Vega, KMS Supplier Quality  
**Record cutoff:** 2026-08-14, 16:30 ET  
**Site:** Keystone Motion Systems, Monroeville, Pennsylvania  
**Affected assembly:** M12-1.75 x 55 mm property-class 12.9 socket-head fasteners at the upper palletizer mast joint

## Service call excerpts

**2026-08-08, 07:18 — Unit PMZ-4471, customer site in York, PA.** Field technician Eli Novak found the head separated from the upper-left mast-joint fastener during the start-of-shift walkdown. The unit had completed the prior evening's cycle count and was stationary when the separation was found. Installation record KMS-I-88214 shows fastener lot L24-0817, container C17-04, installed 2026-08-06 at 62 N-m with calibrated wrench TW-091. The wrench check performed after the service call read 62.4 N-m at the 62 N-m setting. The broken shank and head were bagged as FF-0817-01. Elapsed time from installation to discovery was approximately 41 hours.

**2026-08-11, 15:42 — Unit PMZ-4493, KMS Monroeville run-in bay.** During guard alignment, technician Jada Cole heard a light snap and found the upper-right mast-joint fastener separated below the head. Installation record KMS-I-88409 shows lot L24-0817, container C17-07, installed earlier that day at 63 N-m with wrench TW-104. The post-event wrench check read 63.1 N-m at the 63 N-m setting. The fastener had been under static clamp load for about 18 hours and the palletizer had not entered production cycling. The pieces were bagged as FF-0817-02.

No separated fastener from lots L24-0819, L24-0902, or L24-0905 has been reported as of the cutoff. The absence of a report from an uninstalled lot is not field exposure evidence.

## Installation record review

Quality technicians checked all 34 available torque records for lot L24-0817. Recorded installation values range from 61 to 64 N-m. Twenty-seven records carry a matching wrench-verification entry; seven early records refer to the daily calibration log rather than repeating the result on the traveler. Calibration log CAL-2026-08 lists all four wrenches used on the lot within plus or minus 0.6 N-m of their checked settings. No record shows an installation value above 65 N-m.

The mast joint uses two subject fasteners per palletizer. Shipping and work-order reconciliation identifies 412 installed L24-0817 fasteners across 206 units. The equipment serial list is controlled in KMS service system case SR-23918. Operations stopped shipment of those units at 11:20 ET on 2026-08-12, but 71 units were already at customer locations. Service has contacted 64 of those sites; seven acknowledgements remain open at the cutoff.

Manufacturing engineer Ben Hsu noted that a high-torque break normally shows a pronounced torsional lip near the origin. He did not see that feature during the unaided receiving examination, but he deferred the fracture-surface call to the laboratory. Supplier representative Darren Coates argued on the 2026-08-12 call that installation variation remained the likely cause because the baseline tensile certificates passed. He did not provide a torque record outside the shop window.

## Quantity reconciliation at cutoff

| Lot | Quantity received | Installed | Loose inventory | Container status |
| --- | ---: | ---: | ---: | --- |
| L24-0817 | 640 | 412 | 228 | C17-04 and C17-07 partly consumed; remaining containers in cage SQ-2 |
| L24-0819 | 610 | 0 | 610 | Six sealed containers and one opened sample container in cage SQ-2 |
| L24-0902 | 600 | 0 | 600 | Six sealed containers in production supermarket row M-14 |
| L24-0905 | 550 | 0 | 550 | Five sealed containers and one opened laboratory sample container in cage SQ-3 |

Receiving totals reconcile to 2,400 fasteners: 412 installed and 1,988 loose. Warehouse lead Noor Ellison counted the loose material twice on 2026-08-13. The enterprise inventory screen was 20 pieces higher for L24-0817 until issue ticket INV-66102 was posted against work order 4487; the table above reflects the corrected physical and system count.

## Traceability and supplier statements

Lots L24-0817 and L24-0819 appear on plating certificate NST-0715 under plating batch PB-26-0715. Lots L24-0902 and L24-0905 appear on separate certificates NST-0729 and NST-0730. All four lots trace to steel heat H6K44 through the forming certificates. Northline Surface Technologies sent furnace air-temperature charts with the certificates. KMS requested basket thermocouple records after the second fracture; the time-stamped production readings are in the controlled process export.

Fastener manufacturer Ridgeway Cold Form confirmed that no thread-roll die change occurred between the four lots. The supplier recorded one heading-tool change between L24-0819 and L24-0902. Receiving dimensional inspection found no head-to-shank radius rejection in the 32-piece retained sample. This statement is context only; the dimensional inspection was not intended to screen delayed fracture.

## Client decision needs from the 2026-08-14 call

Quality director Sarah Mensah needs a disposition for each of the four lots before the 07:30 production meeting on August 19. Plant manager Luis Ortega needs the number of loose pieces to segregate, the number of installed fasteners and units needing field action, and whether available cleared stock can cover replacement. Supplier Quality needs a cause statement that distinguishes established evidence from open questions and identifies objective closure evidence. Production will not install material in `HOLD` or `QUARANTINE` status.

KMS has 600 pieces from L24-0902 physically available if that lot meets the controlled release requirements. Service estimates one shift to kit 412 replacement pieces after a release decision. No alternative supplier material will arrive before August 25.

