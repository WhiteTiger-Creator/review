# Storefront SDK asset delivery

Owner: Platform Delivery. Last edited 2026-09-30 by R. Ivens.

This describes how merchant browsers actually obtain `checkout.js`, because the answer is
different for each of the three embed targets we support and the difference decides how long a
released build takes to reach real shoppers.

## Origins and paths

Everything ships from `cdn.sedlak-commerce.example`. Three paths matter.

`/sdk/loader.js` is a 1.8 KB shim. It reads the merchant key off the script tag, asks
`/sdk/resolve` which build that merchant should run, and injects the real bundle. Response
headers:

    Cache-Control: public, max-age=300
    Vary: Accept-Encoding

`/sdk/v3/checkout.js` is the floating major channel. Whatever we promote to the v3 channel is
served from this path, so a merchant who embeds it picks up new builds without touching their
page. Response headers:

    Cache-Control: public, max-age=86400, stale-while-revalidate=604800
    ETag: "<build sha>"

`/sdk/3.8.2/checkout.js` and every other `/sdk/<exact version>/checkout.js` path is an
immutable pin. Once published, that byte stream never changes:

    Cache-Control: public, max-age=31536000, immutable

## What a purge does and does not do

Purging clears our edge tier. It does not reach into a browser's HTTP cache. A browser holding
a fresh copy of `/sdk/v3/checkout.js` keeps using it until `max-age` expires, and after that
`stale-while-revalidate` lets it keep serving the stale copy while it revalidates in the
background. In the worst case a returning shopper runs the previous build for the full
`max-age` plus the full `stale-while-revalidate` interval before the new one takes effect.
This is the number to plan around. It is not an average; it is the tail, and the tail is what
breaks a launch.

We have never found a reliable way to shorten it after the fact. Shipping a build to the
channel and then purging, which Support asks for about once a quarter, only affects shoppers
whose browser had nothing cached to begin with.

## Loader-based merchants

The loader path looks instant and mostly is, but the loader itself is fetched by the merchant's
own HTML, and that HTML is cached by whatever the merchant put in front of it. A merchant
serving their storefront document with a long `max-age` will keep handing browsers a stale
document that references a stale loader response. Effective propagation for a loader merchant
is their document cache lifetime plus the 300 seconds on the loader, not 300 seconds alone.
`storefront_html_max_age_s` in the embed registry is the value we measured on their production
document in September.

## Pinned merchants

An exact pin never moves. There is no delivery mechanism that upgrades a pinned merchant,
including a channel promotion, a purge, or a `/sdk/resolve` change. The merchant has to edit
their page, or in the case of an app that ships a bundled document, release a new build of the
app. We keep every published pin alive indefinitely; nothing at the CDN layer expires them.

## Server-rendered integrations

One integration style sidesteps browser caching entirely and creates a slower dependency in
its place. A merchant whose platform inlines our bundle into their own rendered document at
their build time is running whatever snapshot they built with, and a channel promotion does
not reach them until they rebuild and deploy. `integration_type` in the embed registry records
which merchants are in this position.

## Service workers

A handful of merchants register a service worker that caches our bundle under their own rules.
When that happens their service worker cache lifetime replaces ours entirely, in both
directions: they can be slower than the channel and they can also serve a build we have already
retired at the edge. We cannot see or purge a merchant's service worker cache. The only lever
is asking them to bump their cache version, which requires a deploy on their side.

## How we measure a merchant's document cache

`storefront_html_max_age_s` is read off the merchant's production storefront document, not off
their staging site and not off what they tell us. The September sweep fetched each merchant's
home and cart documents twice from two regions and recorded the lower of the two `max-age`
values seen. Where a merchant sends no caching directive at all we record 300, which is what
their edge applies by default. One merchant serves the cart document with a materially longer
lifetime than the rest and it has been that way since they moved to their current host.

## Channel promotion mechanics

A promotion is a pointer move. The build is already published at its immutable path, the
channel path is repointed at it, and the edge is purged so the next origin fetch returns the
new bytes. Nothing about that sequence touches a browser that already holds a copy, which is
the whole reason the numbers above matter.

## Release windows

Storefront-affecting promotions go out on the standard release train, never ad hoc. See
`sdk_deprecation_policy.md` for the train schedule and the seasonal freeze, both of which are
contractual for tier 1 accounts.
