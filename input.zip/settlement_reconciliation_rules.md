# EBT settlement decision control notes

## Source standing

The review population is the complete set of rows in `market_batch_ledger.csv`; no row drops out because its evidence is partial. At the packet cutoff, `settlement_rule_notice.eml` is the approved control record. Vendor correspondence, committee notes, field observations, and calendars can explain what happened, but their timestamps or meeting status do not change an approved control.

## Reconciliation basis

The settlement obligation begins with authorized value after recorded reversals. Processor settlement and the market deposit are separate confirmation legs. Until both legs are supported, a row can be recognized only to the lower confirmed amount; the remainder stays unresolved. Form the portfolio match rate from the aggregated supported amount and aggregated net authorization, then round only the displayed percentage. Ledger count fields are additive for the retained population and may not be negative.

If the processor and deposit values differ, retain both source values and route the difference to its evidence owner. A partial evidence state remains visible and is not converted to approval.

## Hold closure and cross-source testing

An unmatched batch stays held. The market manager supplies the deposit receipt and attestation. Technology links authorization, reversal, processor, provider-product, and deposit-route identifiers. Finance reruns the row to zero variance, retains the closure case identifier, and makes any later release decision through the existing process.

A relationship status applies to the market mapping recorded in `vendor_asset_relationships.xml`; it does not close every ledger row or exception for that market. Event-trace amounts and timestamps must be reconciled to the ledger row and exception record before they are used as closure evidence. A calendar event, vendor portal state, acknowledgement, or meeting attendance is not closure by itself.

## Commercial decision and execution boundary

Use the supplied quotes, but keep a service tier or numeric cutoff unset unless an accepted record establishes it. A later pilot or faster service remains a proposal until the service schedule, price, field map, test population, test result, and approval are recorded. Faster acknowledgement does not replace bank, reversal, or row-level Finance proof.

This analysis does not release held funds, sign a vendor order, change merchant rules, alter production configuration, or post accounting entries. Those actions remain with their existing approved processes.
