# Locklear Instrument Company
# Contract amendments executed in the quarter ended June 30, 2026
# Extracted from the contract management system on 2026-07-02 by C. Coyne.
# Each entry reproduces the operative terms of the executed amendment. The full signed
# originals sit in the contract file under the same reference.

## A-2404-1

Contract: C-2404, Nakagawa Diagnostics Group, laboratory system validation and integration
Executed: 2026-05-12 by V. Marsalis for Locklear and by the Nakagawa director of laboratory
operations. Effective: 2026-05-15
Additional consideration: 76,000 dollars, fixed fee.
Billing: added to the remaining project progress billings in equal parts, first appearing on the
2026-06-30 billing. Payment terms are unchanged at net 45 days from invoice.

### Scope added

Nakagawa moved its specimen routing onto a second instrument line in March and asked that the
line be brought inside the validated system rather than qualified separately once the original
project closed. The amendment adds interface mapping between the routing controller and the
existing middleware, requalification of the affected test scripts, and a second round of
installation qualification covering the routing line.

The added work is performed by the same project team, under the same validation master plan
VMP-2118, and against the same acceptance criteria. The deliverable at the end of the project
remains one validated laboratory system. The routing line shares the middleware, the acceptance
protocol and the final system release with the original scope. No part of the added work has been
priced or sold by Locklear as a standalone service to any customer.

### Effect on other terms

Completion moves from 2026-12-31 to 2027-03-31. The acceptance protocol, the retention terms and
the limitation of liability are unchanged. The amendment does not add or remove any other
deliverable, does not change the fee for the original scope, and does not alter the payment
milestones already invoiced.

### Change order pricing

Project management priced the amendment from the change order pricing sheet dated 2026-05-06:

- Interface mapping and middleware configuration, 210 hours: 23,100 dollars
- Test script requalification, 128 hours: 14,080 dollars
- Installation qualification round for the routing line, 96 hours: 10,560 dollars
- Travel, validation consumables and documentation: 4,260 dollars

Project management estimated the added work at 52,000 dollars of
project cost in that pricing sheet, and that figure was used to price the amendment.

## A-2410-1

Contract: C-2410, Ruvalcaba Clinical Labs, analyzer and subscription
Executed: 2026-06-05 by the Locklear regional sales director and by the Ruvalcaba Fairlawn site
manager. Effective: 2026-06-05
Additional consideration: 148,000 dollars.
Billing: single invoice on shipment, payment terms unchanged at net 30 days from invoice.

### Scope added

Ruvalcaba's Fairlawn site ordered a second Locklear 8400 benchtop analyzer on the same paper as
its existing contract. The analyzer is a standard configuration taken from stock, carries the
current list price for that model with no discount and no allowance of any kind, and is not
interdependent with the equipment already supplied to the Ruvalcaba central site. It runs the
same assay menu and needs no interface work.

### Effect on other terms

Delivery and payment terms are those of the original contract, including FOB shipping point. No
subscription, installation, training or coverage was added, and the subscription term already
running under the original contract is unchanged. The warranty period for the added analyzer runs
from its own delivery date. Nothing in the original contract is repriced, rescheduled or
withdrawn, and neither party has agreed any credit, concession or offset in connection with the
order.

### Administrative

Both amendments were logged into the contract management system on the date of execution and
carry the countersigned originals as attachments. Neither amendment has been superseded or
cancelled as at the extraction date. There are no other amendments to any contract in the
quarter.
