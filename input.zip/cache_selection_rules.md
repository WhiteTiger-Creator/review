# Cache selection working rules

Use the decision cutoff of 2026-08-19. The approved standard controls a subject when a later email or field note is not itself approved for that subject.

## Joins and population

`route_layer_coverage.csv.option_id` uses the same option keys as the include columns in `package_sizes.tsv` and the option rows in `cache_dependency_table.tsv`: OPT-MW is Map-weighted package, OPT-RF is Route-first package, and OPT-AD is One-cycle aviation deferral. Include every active zone shown in the route file. Keep all record IDs in the workpaper; `canyon_record_lineage.xml` supplies the source-record join.

## Calculations

For each option, route coverage is `SUM(cached_route_km) / SUM(required_route_km)` across the 12 active zones. Do not average the 12 zone percentages. Package size is the sum of `size_gb` for components whose option include flag equals 1. Oldest layer age is the decision cutoff minus the earliest published date among included components whose status is accepted. Count recreation exclusions by comparing the two recreation-class rows with the selected option manifest.

Round package size to one decimal GB and coverage to one decimal percent only after aggregation. Storage headroom is the approved ceiling minus the unrounded package size.

## Gate order

First test mandatory aviation, evacuation, and canyon dependencies. Then test the approved storage ceiling and layer-age limit. Compare weighted route coverage only among options that pass those gates. A calendar event is a work window, not acceptance. An open storage case stays visible but changes the field ceiling only if the approved owner changes the standard or the device enters the assigned response fleet.

The paper may recommend a package and evidence gates. It does not release a package to crews, alter aviation procedure, sign a vendor order, or change device configuration.
