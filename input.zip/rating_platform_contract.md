# Partner API v3: rating platform capacity and enforcement contract

Owner: Platform Engineering, Sanderson Logistics
Applies to: Partner API v3 (`api.sanderson.example`)
Revision: 9, effective 2026-07-01

## 1. What this document fixes

This contract states the numbers and rules that any rate-limit or quota change must satisfy. It is the authority for platform capacity, request cost, budget division, and response behaviour. Commercial commitments live in the partner agreements and are binding on top of what is written here; where an agreement guarantees a partner more than a tier default, the agreement wins.

## 2. Serving topology

Partner traffic terminates on six API nodes behind the edge load balancer. The balancer distributes by least connections. A client that opens one long-lived connection pool is therefore served by one node for the life of that pool; a client that opens a fresh connection per request is spread across all six. Neither behaviour is prohibited and neither can be assumed.

Any counter that lives in a single node's process is a per-node counter. A limit enforced that way is multiplied by the number of nodes a client happens to reach, which is a property of the client's connection behaviour and not of its traffic volume. Enforcement state that must hold across the fleet belongs in the shared rate-limit store, which supports atomic increment and expiry.

## 3. Request cost

Endpoints do not cost the same. The rating platform is sized in cost units per minute, not requests per minute, and every limit in this system is expressed in cost units.

The weights below are the current schedule. A change to a weight is a capacity change and follows the same review.

| Endpoint | Cost units | Carrier fan-out | Basis |
|---|---:|---|---|
| `POST /v3/quotes` | 10 | yes | Fans out to up to nine carrier rating services and blocks until the slowest replies |
| `POST /v3/shipments` | 6 | yes | Writes the shipment and books one carrier leg |
| `GET /v3/shipments/{id}/tracking` | 1 | no | Single indexed read against the shipment store |
| `GET /v3/service-points` | 1 | no | Edge-cached on most requests; the origin read is one geo lookup |
| `GET /v3/health` | 0 | no | Liveness probe, exempt from enforcement |

A limit expressed in requests per minute is not equivalent to one expressed in cost units. Nine hundred tracking reads and ninety quote requests are the same number of cost units and are not the same load on any other axis, but cost units are the axis the rating platform is sized on.

## 4. Capacity and budget division

The rating platform sustains **9,000 cost units per minute** at the agreed latency objective. This figure is the sustained figure, not a peak.

Thirty percent of that, **2,700 cost units per minute**, is reserved for first-party traffic and for absorbing retries. First-party checkout and internal services draw from the reserve and are never counted against partner allocations.

Whatever remains after the reserve is the partner budget. The sum of the sustained allocations granted to all production partner keys must not exceed it. An allocation that would push the sum over the budget is not approved until capacity is raised or an existing allocation is released.

Sandbox traffic runs against a separate rating pool with its own hardware and does not draw on the 9,000. Sandbox keys are never counted against the partner budget, regardless of volume.

## 5. Allocation rules

A production partner key holds a sustained allocation in cost units per minute and a burst capacity. Burst capacity is twice the sustained allocation and refills continuously at the sustained rate; a key that has been idle can therefore spend up to three times its per-minute allocation inside one minute and no more.

An allocation must be at least the partner's observed 95th-percentile minute. Setting an allocation below observed legitimate use is a service reduction and requires the notice period in the partner agreement.

A key whose status is terminated or suspended holds no allocation. Allocation released this way returns to the partner budget and is available for reassignment.

## 6. Enforcement behaviour

Enforcement is keyed on the authenticated API key. Client IP address is not an identity: partners hosted by a shared integrator egress from one address, and several partners sharing an address must not share a bucket. IP keying is permitted only where no API key is present, which on this surface means the unauthenticated health endpoint alone.

A fixed calendar window is not an acceptable algorithm. A client that spends a full window immediately before a boundary and a full window immediately after it has sent twice its allowance in a span shorter than the window, which the platform cannot absorb. Enforcement must use a continuous algorithm.

A throttled request is answered `429` with `Retry-After` in seconds and with `RateLimit-Limit`, `RateLimit-Remaining` and `RateLimit-Reset`. A response that omits `Retry-After` invites an immediate retry, and an immediate retry from a throttled client is indistinguishable from an attack. `503` is reserved for platform unavailability and must not be returned for a throttling decision.

`GET /v3/health` is exempt from enforcement and carries no cost. No other endpoint is exempt.

## 7. Change control

A limit change is announced to affected partners before it takes effect, on the notice period in their agreement. Enforcement changes are deployed in observe-only mode first, where the decision is computed and recorded but not applied, and are promoted only after the recorded decisions have been reviewed against real traffic.
