# Gateway ops notes

Running file. Newest at the top. If you are reading this for the Routeline port, the calendar entries matter more than they look like they do.

## 2026-04-28

Scanner noise is back up, mostly /wp-login.php and /admin guesses from the usual places. The externals deny rules are earning their keep. No action.

## 2026-04-14

Marbury key rotation waiver renewed again. Security signed off through decommission on the condition nobody adds new consumers to marbury-legacy-apps. Nobody has, per the caller registry. The static keys make me itch but the runoff apps cannot do mTLS and are not getting rebuilt for a book in wind-down.

## 2026-03-15

rater-v2 is off. Quoting cut mobile over to the new rater on the 14th and we stopped the old containers Saturday morning. Registry updated same day. Traffic to it died exactly like the graph said it would.

## 2026-03-02

Billing cutover window observed, no gateway deploys first three business days per the standing ask. One partner-agents client wedged itself retrying a 404 against a route that has not existed since 2024; their integrator swears it is fixed. Fourth time. I keep a tally now, which says something about my optimism.

## 2026-02-20

The nightly config export job hit its timeout twice this week, same as January. It finishes on retry every time, so nobody will prioritize it, and the export we hand auditors is always one day stale. Ticket PLAT-1682 has been open since October. I have stopped promising a fix date.

## 2026-01-09

Statutory annual extract completed Wednesday. finance-batch posts into /statutory/annual-extract during the first business week of January, one week a year, and that is the whole traffic profile for that route. It filed clean this year. Next run is January 2027. I write this down every year because every year somebody looks at a quiet route in a traffic review and asks if we can turn it off. We cannot. The state filing calendar does not care about our 90-day dashboards.

## 2025-12-30

Year-end change freeze held. One emergency cert swap on the portal BFF, otherwise quiet.

## 2025-10-18

DR drill complete. ops-tools exercised the /dr routes for four hours Saturday; failover to the Cedar Rapids site worked, failback was slower than the runbook says, timing notes went to the resilience doc. These routes see traffic twice a year at most: the October drill and whatever ad hoc testing precedes it. They stay. If we ever actually need them, that will not be the week to discover they were tidied away.

## 2025-10-02 (backfilled from the cutover doc)

Marbury gateway book appended tonight, 2023 entry copied forward here for anyone hunting history: their Zuul export went in behind our rules verbatim, order preserved, because nobody in that war room wanted to hand-merge authorization at 2 a.m. The plan said we would rationalize it within a quarter. It is 2026.

## Standing notes

- The paper-invoice, fax-intake, and legacy-portal routes have been dark since their retirement dates in the registry. Their rules are still in the gateway because removing rules from the running box requires a change window nobody wants to spend on cleanup. The port is the cleanup.
- Quoting owns anything under /quotes. Billing asks that nothing touch invoice-adjacent paths during the first three business days of a month; that constraint is about deploys, and it does not bear on which rules exist.
- Marbury runoff reserving rounds differently than ours. If a rule choice ever comes down to whose logic handles reserving, it is theirs, the reinsurers audited that path in 2022 and nobody wants to re-open it.
- I still owe Distribution IT an answer on whether /marbury/agents can go read-only. Third quarter, maybe.
