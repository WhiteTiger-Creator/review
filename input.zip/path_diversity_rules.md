# Harvest OT link portfolio workpaper rules

This memo is the calculation rule set, not the recommendation. Apply it to the six elevator IDs carried by `elevator_outage_history.csv` and preserve the source identifiers in the final workpaper.

## Population and joins

Use every outage row whose `review_flag` is `retain`. Count elevators with `COUNT(DISTINCT elevator_id)`; do not sum a prebuilt portfolio field. Join each outage row to `ticket_event_trace.jsonl` through `elevator_outage_history.record_id = ticket_event_trace.outage_record_id`. Join candidate packages through `carrier_bid_book.elevator_id = elevator_outage_history.elevator_id`. Join handoff exceptions through both `handoff_exception_cases.elevator_id = carrier_bid_book.elevator_id` and `handoff_exception_cases.option_id = carrier_bid_book.option_id`. The calendar UID includes an RFC-style domain suffix, so join `elevator_outage_history.harvest_window_uid` to the local part of `scale_change_calendar.UID` before `@`.

No numeric portfolio result is supplied as a source value. The manager must calculate the results from row evidence. If an outage record lacks a ticket event, a window UID, or an elevator ID, keep it on an exception list and do not impute a favorable value.

## Eligible packages

Choose exactly one package per elevator. A current candidate is eligible only when `quote_status = signed_quote` and `window_fit = yes`. A working quote or a package outside the recorded installation window remains visible for comparison but does not enter the selected portfolio. The approved annualized ceiling is $340,000 from `harvest_service_resolution.rtf`.

Annualized package cost is:

`annual_recurring_cost + installation_cost / amortization_years`

Sum the six selected package costs before rounding to whole dollars. Finance must be able to trace every selected amount to its `option_id`.

## Path independence

A selected package counts as independent only when its `primary_origin` differs from its `fallback_origin` and there is no `open` exception for that option with `independence_effect = not_independent`. A different carrier label does not establish diversity. Closed exception rows with `no_effect` document why two origins remain separate; they do not add an elevator to the count on their own.

The portfolio independence count is the number of selected elevator packages passing that test. The assessed count is the number of distinct elevator IDs in the retained outage population.

## Service and loss calculations

For each elevator, historical outage minutes are `SUM(outage_minutes)` across retained rows. Protected outage minutes are historical outage minutes multiplied by the selected package's `modeled_failover_success_rate`. Portfolio protected hours are `SUM(protected outage minutes) / 60`.

Calculate each service window in minutes from its ICS `DTSTART` and `DTEND`. Residual outage minutes are `historical outage minutes x (1 - modeled_failover_success_rate)`. Modeled harvest availability is:

`1 - SUM(residual outage minutes) / SUM(service window minutes)`

Display the result as a percentage rounded to two decimals after portfolio aggregation. Do not average site percentages and do not use the number of outage rows as a denominator.

For each joined ticket event, observed backlog exposure is:

`ticket_backlog_minutes x loss_rate_per_backlog_minute_usd`

Modeled backlog loss avoided is that exposure multiplied by the selected package's failover success rate. Sum the row results before rounding to whole dollars. Ticket counts remain an audit field and are not a substitute for backlog minutes.

## Optimization order

Enumerate eligible one-package-per-elevator portfolios that remain at or below $340,000. First maximize the count of independent elevator paths. If more than one portfolio has the same independence count, maximize modeled backlog loss avoided. If a tie remains, choose the lower annualized cost. Keep the least-cost all-elevator portfolio in the comparison even when it fails the independence gate so the committee can see the cost of the shared-handoff shortcut.

An open exception may make a package the best available reserve while still preventing it from counting as independent. In that case, show the reserved amount and state that no order may be released until the named exception closes with observable origin and facility proof.

## Evidence precedence and boundaries

`harvest_service_resolution.rtf` is the approved, effective authority for the ceiling, roles, optimization order, and management boundary. Vendor claims, committee discussion, field observations, and calendar entries can provide facts or context but cannot silently override the resolution. When sources disagree, state the conflict, the subject, the status of each source, and why the approved effective record controls.

This workpaper supports a management recommendation only. It does not configure radios or routers, disclose credentials, issue a carrier order, authorize contract signature, change production settings, or change scale operating procedures.
