# Terminal observations from the spring feed review

These notes were compiled by A. Reyes after visits and remote sessions with the terminal technicians. They supplement the delivery history. They do not certify a vendor product or direct a sailing decision.

## Juneau: labels can hide a shared source

The TERM-08 console showed a primary tile and a reserve tile during the 25 March event. Their host names differed, yet the issue time, bulletin sequence, and recovery time matched. The screen’s green availability mark meant only that the endpoint answered. It did not mean that a fresh, independent forecast was present. The event appears in `outage_event_trace.jsonl` as `OUT-2026-03-25-A` and in the retained history as `FERR-8RPFNJ`.

During the 2 May follow-up (`FERR-HUFZQQ`), the reserve origin was `ORIG-COAST-Y`, not the shared `ORIG-NWP-A` seen in March. That later result is useful, but it cannot erase the earlier dependency failure. The monitor needs to retain origin and issue sequence for each receipt so reviewers can see the difference.

## Ketchikan: local network stayed up

The TERM-04 gateway logs show no interface flap during the 11 June missed deliveries. DNS queries resolved and the terminal could reach both endpoints. The outage trace records the primary miss at 11:08 and the reserve miss shortly afterward. Both carried `ORIG-NWP-B`. This supports the dispatch note that the problem was upstream rather than a terminal link failure.

The gateway maintenance scheduled in `ferry_change_calendar.ics` is a later controlled test. It may provide new evidence about the terminal path, but attendance at that test will not close the provider-origin question by itself.

## Homer: cached payload looked like a delivery

TERM-14 accepted an HTTP response before the 4 April decision, but the payload issue time had not advanced. The current health check counts a response as available even when it repeats the cached issue. That behavior explains why the desk saw a “reserve available” indicator while the event still qualifies as a common-origin miss. The corrective request is to test freshness and origin together.

The field team did not change the console during the visit. Any production change would need the normal IT change record and Marine Safety coordination.

## Petersburg and Sitka: independent ingress is visible, upstream proof is not

TERM-06 and TERM-03 use different physical ingress paths for the observed primary and reserve traffic. Packet captures show the reserve arriving over the satellite link. This reduces the chance of one terminal circuit taking out both feeds. It does not prove that the two products obtain their forecasts from separate upstream publishers.

`marine_asset_relationships.xml` records the local paths. Provider origin statements belong in the commercial and technical evidence retained by IT. The field record should not be stretched to answer that contract question.

## Clock and archive observations

The Skagway clock was 41 seconds ahead during an early AKR-09 sample. Network Operations corrected it before `FERR-387YV6`. The drift was too small to change the one-decimal-minute result, but the correction should remain with the event history.

The archive export at TERM-02 took 18.4 minutes in one test. That delay affects how quickly a reviewer can retrieve evidence; it did not change whether the forecast arrived before the route decision. The distinction matters because the packet includes both delivery performance and evidence-retention questions.

## What still needs a witnessed test

- Route AKR-14 needs an observation using a reserve that has a separately attested origin.
- Route AKR-04 needs the shared-ingress maintenance result attached to the existing outage lineage.
- The provider product named in each quote needs to be tied to the host, origin code, and history records it claims to represent.
- The monitor should flag stale issue time even if the endpoint answers normally.
- Renewal evidence should include the raw timestamp basis and not just dashboard percentages.

The spring sample supports the route-weighted calculations because the `FERR-*` identifiers point back to timestamped observations. It does not support a named award on its own. The remaining gap is not another average; it is the provider-to-feed identity record and an accepted origin-independence statement.
