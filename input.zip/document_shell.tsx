import Script from "next/script";
import type { ReactNode } from "react";

type Props = {
  pathname: string;
  consentGranted: boolean;
  children: ReactNode;
};

export function DocumentShell({ pathname, consentGranted, children }: Props) {
  return (
    <html lang="en">
      <head>
        <style>{`html{font-family:system-ui}.checkout-shell{min-height:480px}`}</style>
        <script
          dangerouslySetInnerHTML={{
            __html: `window.__HARBOR__=${JSON.stringify({ pathname, consentGranted })}`,
          }}
        />
        <Script src="https://cdn.metricsbeacon.example/client.js" strategy="afterInteractive" />
        <Script src="https://cdn.carechat.example/widget.js" strategy="afterInteractive" />
      </head>
      <body>{children}</body>
    </html>
  );
}
