# Sampling and estimation standard

Northlake Research Group
Applies to: every probability sample design issued to a client
Revision: 13

This standard fixes the methods used on establishment surveys so that two
statisticians handed the same frame and the same budget produce the same design.
Where a method is stated here, use it rather than a defensible alternative, and
where a design departs from it, say so in the plan and give the reason.

## 2. The frame the design is sized from

2.1 Size the design from the reconciled frame, not from the frame as first
supplied. Where a client supplies a correction to its own frame after the
verification date, apply the correction before any allocation arithmetic is
done. An allocation computed on a superseded count is wrong even if every later
step is right.

2.2 Apply corrections in two classes. A removal takes an establishment out of
the frame entirely and reduces the total. A reclassification moves an
establishment from one stratum to another and leaves the total unchanged. State
both the removals and the reclassifications, by stratum, and show the reconciled
stratum counts alongside the counts they replace.

2.3 Prior standard deviations are stratum parameters carried from the most
recent completed wave. Do not re-estimate them when the frame is reconciled, and
do not attempt to adjust them for establishments that changed stratum.

## 3. Response rates

3.1 The response rate for a stratum is completed responses divided by eligible
records contacted. Eligible records are those invited less those found
ineligible and less those undeliverable.

3.2 Partial responses are not completes. A partial contributes to neither the
numerator nor the denominator adjustment; it is simply not a complete.

3.3 Where more than one prior wave exists, the planning rate for a stratum comes
from the most recent wave fielded on a comparable window. Do not smooth rates
across strata; response behavior differs by establishment size and that
difference is what the allocation has to absorb.

3.4 Clause 3.3 yields to the protocol test. Where a prior wave was fielded under
a contact protocol that differs from the protocol funded for the current wave,
that wave does not supply the planning rate for the strata affected by the
difference. Use instead the most recent wave whose protocol matches what the
current wave will actually run, even where an older wave is the only one that
qualifies. Apply the test stratum by stratum: a protocol difference confined to
some strata leaves the remaining strata on the ordinary recency rule of 3.3.

## 4. Allocation

4.1 Allocate completes by Neyman allocation, so that the sample assigned to a
stratum is proportional to the stratum's population size multiplied by its prior
standard deviation on the measure of interest.

4.2 Round allocations by largest remainder so that the parts sum to the budget
exactly. Do not round each stratum independently and accept a total that misses
the budget.

4.3 Where a client sets a minimum cell for publication, no stratum may be
allocated fewer completes than that minimum. A stratum that Neyman would place
below the minimum is raised to it.

4.4 Where raising a stratum to the minimum would require contacting more
establishments than the stratum contains, the minimum cannot be bought. Take a
complete enumeration of that stratum, plan on the completes the enumeration is
expected to yield, and record the stratum as falling short of the minimum.

4.5 Where a client sets a precision requirement on the strata it publishes
separately, apply it after 4.3 and 4.4 and only to those strata that will in
fact be published on their own. A stratum held below the client's minimum cell
is not published on its own and the stratum precision requirement does not reach
it. A stratum that will be published and whose allocation misses the requirement
is raised to the smallest number of completes that satisfies it, and is then
fixed.

4.6 After any stratum is fixed by 4.3, 4.4 or 4.5, reallocate the remaining
budget across the unfixed strata by Neyman on those strata alone. Repeat the
checks in 4.3 to 4.5 on the reallocated result, and stop when a pass changes
nothing.

## 5. Invitation volume

5.1 Invitations for a stratum are the planned completes divided by the planning
response rate, rounded up to the next whole establishment.

5.2 A stratum under complete enumeration is invited in full, and its expected
completes are the frame count multiplied by the planning response rate, rounded
down. Rounding down is deliberate: a plan that rounds a yield up promises
completes the frame cannot supply.

5.3 A plan may not invite more establishments than a stratum contains. Where the
arithmetic of 5.1 calls for more, the requirement that produced it cannot be
bought and the plan says so rather than quietly capping the number.

## 6. Weighting and precision

6.1 The design weight for a stratum is the stratum population divided by its
planned completes. Design weights sum to the frame population, and a plan whose
weights do not is arithmetically wrong.

6.2 Report the design effect from unequal weighting using Kish's formula: the
number of completes multiplied by the sum of squared weights, divided by the
square of the sum of the weights. Report the effective sample size as completes
divided by the design effect.

6.3 The margin of error on a stratified mean is 1.96 multiplied by the square
root of the summed stratum variance contributions, where each contribution is
the squared population share multiplied by the stratum variance over its
completes, multiplied by the finite population correction. Apply the correction;
on a membership frame of this size, omitting it overstates the margin of error
materially.

6.4 The margin of error on a single stratum is 1.96 multiplied by the square
root of the stratum variance over its completes, multiplied by the finite
population correction for that stratum. The population share does not enter a
single-stratum margin.

6.5 Compare a margin of error against a client requirement on the unrounded
value. Present margins rounded to the cent, but never decide whether a
requirement is met on the presented figure, because a margin that rounds to the
requirement can sit either side of it.

## 7. Reportability

7.1 A stratum that reaches the client's minimum cell is reportable on its own. A
stratum that does not is reported only in combination, and the plan names the
combination.

7.2 State plainly whether the design meets the client's precision requirement.
Where it does not, give the completes that would be needed to meet it, computed
on the same allocation method and holding every stratum fixed by 4.4 and 4.5 at
the number that fixed it, rather than describing the shortfall in words.

## 8. What the plan contains

8.1 In order: the design summary, the frame reconciliation, the stratification,
the response rate basis, the allocation with every step that moved a number, the
invitation plan, the weighting specification, the precision result, and
reportability with limitations.

8.2 Every figure is stated with the arithmetic that produced it. A plan that
states a sample size without showing the allocation that produced it cannot be
checked by the client's board and will be returned.

## 9. Handling of client-supplied records

9.1 A client frame or directory is supplied to us for sizing and field
management. It is not ours to republish. Do not reproduce establishment names,
member identifiers, or named contact details from a client's records anywhere in
a plan, a report, or an appendix. A methodology document is circulated to a
board, tabled at meetings, and frequently forwarded outside the client
organization, and a member's contact row traveling with it is a disclosure we
cannot pull back.

9.2 Where the plan needs to refer to a record, refer to it by the characteristic
that matters, such as the band it falls in or the data-quality condition it
illustrates. Aggregate counts are always publishable; individual records are not.

9.3 Do not attribute a method to this standard, or a requirement to the client,
that neither states. Where the design needs a rule that is absent from both,
raise it and have it agreed, because a plan resting on an invented rule will not
survive the client's own review.
