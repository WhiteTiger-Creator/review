# Engineering Change Notice ECN-26-047, Revision C

**Facility:** Northline Water Authority, East Intake Pump Station, Erie, Pennsylvania  
**System:** Raw-water vertical turbine pump vibration monitoring  
**Effective:** 2026-07-18, 17:00 ET  
**Authorized engineering reviewer:** Mira Solano, PE, rotating equipment  
**Document owner:** Eli Mercer, maintenance engineering  
**Release status:** Released for the six assets named in Section 2

## 1. Reason for change

The VX-210 transmitters on the east intake pumps have shown intermittent cable-entry moisture and zero drift after maintenance handling. Northline will replace the existing transmitters with VT-8A units during the July and August outage windows. This notice defines the engineered boundaries that the field instruction must carry. It supersedes VX-210 mounting, conductor, shield, orientation, loop-check, and final-verification text in Section 7.4 of OMM-EIP-17. The legacy manual remains usable for equipment identification, junction-box location, normal pump start authority, and the existing work-order closeout route.

Revision C incorporates the composite-adapter trial results, corrects the shield termination, and removes two pump trains from the current release. Earlier markup that treated all eight trains alike is void.

## 2. Applicable equipment

This release applies only to P-201A, P-201B, P-202A, P-202B, P-203A, and P-203B at the East Intake Pump Station. Asset tags must be checked at the local disconnect and at the bearing housing before removal begins. The instruction must not group equipment solely by pump number because A and B trains do not all share the same mounting base.

P-201A, P-201B, and P-203A have welded carbon-steel pedestals. P-202A, P-202B, and P-203B have GFRP adapter plates installed under work order NW-25-1186. P-204A and P-204B are outside this change. Their bearing housings will be replaced under a separate capital package, and neither the VT-8A kit nor any step in the resulting instruction is released for those trains.

## 3. Approved material and retained items

Use kit KT-VT8A-442 for each applicable train. Each sealed kit contains one VT-8A transmitter, one BR-442 stainless saddle, one IS-9 isolation pad, one GSK-18 cable-entry seal, two M8 x 30 A4-70 bolts, two SPW-8 spherical washer pairs, two PTN-8 prevailing-torque nuts, one cabinet ferrule set marked VT8, and one yellow shield-insulation sleeve. Confirm the kit label, seal, and part count before the existing transmitter is disturbed. Mixed parts from open kits are not acceptable. For a steel-pedestal installation, Planning issues two clean M8 flat washers and TL-243 separately; neither item is part of the sealed kit. If the kit seal is broken or any kit part is missing or mixed, do not disturb the existing transmitter. Preserve the kit and label, keep the train unavailable, and contact maintenance engineering.

Retain the existing JB-21 junction box, field cable, local disconnect, and welded pedestal or GFRP adapter plate when inspection shows no damage. Replace the old saddle, isolation pad, cable-entry seal, ferrules, fasteners, and transmitter. Do not reuse the VX-210 saddle or its split lock washers. The BR-442 saddle has a 4 mm offset that is necessary for guard clearance.

## 4. Work controls and hold points

The maintenance supervisor opens the asset work order and confirms the train is available. A qualified electrical worker opens the local disconnect, applies the site lock and danger tag, proves the tester on a known live source, verifies absence of voltage at JB-21 terminals 3 and 4, and proves the tester again. The pump start permissive remains inhibited until final release. Mechanical stored energy is controlled by closing and securing the discharge isolation specified on the work order. No one may rely on the control-room stop indication as evidence of zero energy.

Four hold points are mandatory. At HP-1, the supervisor and electrician record the asset tag, base material, kit number, kit seal, zero-energy check, and pre-removal condition. At HP-2, the maintenance supervisor checks the isolation pad, washer stack, saddle orientation, fastener method, torque, cable-entry angle, and guard clearance before wiring starts, using the temporary guard-position method in Section 5. At HP-3, the electrician checks conductor landing, device-end shield isolation, cabinet ferrule, gland compression, and loop values before the coupling guard is installed. At HP-4, operations witnesses the guarded run comparison and accepts or rejects the returned signal. Each hold point needs the printed name, initials, date, and ET time of the person making the check; a blank signoff means the work remains held.

## 5. Mechanical installation

Clean the retained mounting surface with lint-free cloth and 70 percent isopropyl alcohol. Do not grind, drill, or enlarge the existing holes. Reject a surface with a crack, lifted laminate, rotating insert, elongated hole, heavy corrosion scale, or more than 0.25 mm feeler-gauge gap under the BR-442 saddle after hand seating.

Place the IS-9 pad directly on the mounting surface and the BR-442 saddle on the pad. The transmitter sensing-axis mark faces radially toward the pump shaft centerline. The cable entry points downward at 180 degrees, with a permitted installed range from 150 through 210 degrees when viewed from the outboard side. Confirm at least 12 mm clearance from the cable gland and lead to the coupling guard through the full visible routing.

For the HP-2 clearance check, keep the electrical lock, mechanical hold, and start-permissive inhibition in place. The mechanic temporarily holds the original coupling guard in its normal seated position without installing its fasteners. The maintenance supervisor uses a graduated nonconductive clearance gauge to measure the minimum distance from the guard to the cable gland and lead through the full visible routing. Record the actual minimum, which must be at least 12 mm. Remove the guard after the measurement and keep it off through wiring, the controlled loop check, and HP-3. This temporary positioning and measurement is the released HP-2 method; the legacy visual-only clearance judgment is not an alternate method. Section 7 requires a second clearance check after final guard installation.

For welded carbon-steel pedestals, use the supplied A4-70 bolts with a clean flat washer beneath each bolt head and medium-strength TL-243 threadlocker on the final four engaged threads. Tighten each fastener in alternating increments to 18 N·m, permitted final range 16 through 20 N·m. Record both final readings. Allow ten minutes after final torque before the guarded run.

For GFRP adapter plates, do not use threadlocker. Install one SPW-8 spherical washer pair beneath each bolt head with the convex washer against the bolt head and the mating concave washer against the GFRP side. Use the supplied PTN-8 nuts below the plate. Tighten in alternating increments to 11 N·m, permitted final range 10 through 12 N·m. Mark the nut and exposed bolt with one witness line after torque. Any laminate whitening, crack, insert movement, or washer imprint that remains visible after unloading is a stop-work condition.

## 6. Electrical connection and loop setup

At JB-21, land the field cable white conductor on VT-8A terminal 1 for +24 Vdc and the black conductor on terminal 2 for return. Fit the VT8 ferrules before landing. The bare drain and foil shield must not contact the transmitter body, gland, saddle, or device terminal. Cut the drain flush with the device jacket, cover it with the yellow insulation sleeve, and verify more than 1 megohm from drain to the transmitter body at the device end. Terminate the shield only at the control-cabinet ground bar, retaining the existing cabinet bond.

Fit the GSK-18 seal with its tapered lip toward the cable entry. Tighten the gland until the cable cannot turn by hand, then confirm the seal is not extruded. Route a drip loop below the transmitter without pulling the bend radius tighter than 35 mm. The device-end shield treatment in OMM-EIP-17 is superseded.

With the guard still removed and the train mechanically held, clear the electrical lock only for the controlled loop check. At the zero simulator point, accepted current is 3.92 through 4.08 mA. At the full-scale simulator point, accepted current is 19.88 through 20.12 mA. Return the disconnect to the open state and reapply the electrical lock before installing the guard. A loop value outside either range is corrected and repeated; it is not rounded into acceptance.

## 7. Guarded operational verification

After HP-3, reinstall the original coupling guard with every original fastener. The supervisor measures the minimum clearance again and confirms that no cable or gland is within 12 mm of the installed guard. Record both clearance measurements and enter the lower result as the minimum guard clearance in closeout. Operations then clears the start permissive and starts the pump under the normal station sequence. Do not bypass an interlock for this check.

After ten minutes at steady operation, take three VT-8A overall-velocity readings at 60-second intervals and three handheld reference readings at the marked outboard bearing point at the same intervals. Each paired difference must be no more than 0.25 mm/s, and the spread between the highest and lowest VT-8A reading must be no more than 0.10 mm/s. Record all six readings. A value outside either limit holds the train out of service pending troubleshooting.

## 8. Stop-work, restoration, and records

Stop work for the damage conditions in Section 5, an unidentified base material, missing or mixed kit parts, stripped threads, an unachievable torque, shield continuity at the device end, loop current outside the stated ranges after one correction attempt, guard clearance below 12 mm, or operational readings outside Section 7. Preserve the condition, keep the train unavailable, and contact maintenance engineering.

Do not automatically reinstall the removed VX-210. Reinstallation is permitted only through separate written direction from maintenance engineering after the removed unit, old seal, cable, and mounting surface are inspected. The field instruction must distinguish this controlled restoration path from ordinary troubleshooting.

Close the work order with the asset tag; base material; kit and transmitter serial numbers; removed-transmitter serial number; both torque readings; cable-entry angle; minimum guard clearance; shield-isolation result; zero and full-scale loop currents; six operational readings; four hold-point signoffs; stop-work or deviation reference if used; and the final in-service or held status. Attach before-and-after photographs showing the tag, washer arrangement, witness marks where applicable, cable entry, and restored guard. The document owner enters the released instruction revision in the station document register before the first crew copy is issued.

## Revision record

| Revision | Date | Change | Authorized engineering reviewer |
| --- | --- | --- | --- |
| A | 2026-06-12 | Initial six-train field trial basis | Mira Solano, PE |
| B | 2026-07-09 | Added loop limits and kit controls | Mira Solano, PE |
| C | 2026-07-18 | Localized GFRP fasteners, defined the HP-2 clearance check, corrected shield treatment, excluded P-204 trains | Mira Solano, PE |
