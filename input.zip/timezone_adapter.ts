export type OffsetChoice = 'EARLIER' | 'LATER';

export type LocalResolution =
  | { kind: 'NONEXISTENT'; candidates: [] }
  | { kind: 'UNIQUE'; candidates: [string] }
  | { kind: 'AMBIGUOUS'; candidates: [string, string] };

type LocalParts = {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  second: number;
};

const formatters = new Map<string, Intl.DateTimeFormat>();

function formatter(zone: string): Intl.DateTimeFormat {
  const existing = formatters.get(zone);
  if (existing) return existing;
  const created = new Intl.DateTimeFormat('en-CA', {
    timeZone: zone,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    hourCycle: 'h23',
  });
  formatters.set(zone, created);
  return created;
}

function parseLocal(value: string): LocalParts {
  const match = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/.exec(value);
  if (!match) throw new Error('Local date-time must omit an offset');
  return {
    year: Number(match[1]), month: Number(match[2]), day: Number(match[3]),
    hour: Number(match[4]), minute: Number(match[5]), second: Number(match[6] ?? 0),
  };
}

function partsAt(epochMs: number, zone: string): LocalParts {
  const values: Record<string, number> = {};
  for (const part of formatter(zone).formatToParts(new Date(epochMs))) {
    if (part.type !== 'literal') values[part.type] = Number(part.value);
  }
  return {
    year: values.year, month: values.month, day: values.day,
    hour: values.hour, minute: values.minute, second: values.second,
  };
}

function same(a: LocalParts, b: LocalParts): boolean {
  return a.year === b.year && a.month === b.month && a.day === b.day &&
    a.hour === b.hour && a.minute === b.minute && a.second === b.second;
}

function offsetAt(epochMs: number, zone: string): number {
  const local = partsAt(epochMs, zone);
  const representedAsUtc = Date.UTC(
    local.year, local.month - 1, local.day,
    local.hour, local.minute, local.second,
  );
  return representedAsUtc - Math.floor(epochMs / 1000) * 1000;
}

export function resolveOfficeLocal(localValue: string, zone: string): LocalResolution {
  const wanted = parseLocal(localValue);
  const naive = Date.UTC(
    wanted.year, wanted.month - 1, wanted.day,
    wanted.hour, wanted.minute, wanted.second,
  );
  const offsets = new Set<number>();
  for (let hours = -36; hours <= 36; hours += 6) {
    offsets.add(offsetAt(naive + hours * 3_600_000, zone));
  }
  const candidates = [...offsets]
    .map((offset) => naive - offset)
    .filter((epoch, index, all) => all.indexOf(epoch) === index)
    .filter((epoch) => same(partsAt(epoch, zone), wanted))
    .sort((a, b) => a - b)
    .map((epoch) => new Date(epoch).toISOString());

  if (candidates.length === 0) return { kind: 'NONEXISTENT', candidates: [] };
  if (candidates.length === 1) return { kind: 'UNIQUE', candidates: [candidates[0]] };
  return { kind: 'AMBIGUOUS', candidates: [candidates[0], candidates[1]] };
}

export function chooseCandidate(
  resolution: LocalResolution,
  choice?: OffsetChoice,
): string {
  if (resolution.kind === 'NONEXISTENT') throw new Error('NONEXISTENT_LOCAL_TIME');
  if (resolution.kind === 'UNIQUE') return resolution.candidates[0];
  if (!choice) throw new Error('OFFSET_CHOICE_REQUIRED');
  return choice === 'EARLIER' ? resolution.candidates[0] : resolution.candidates[1];
}

export function formatInZone(instant: string, zone: string): string {
  return formatter(zone).format(new Date(instant));
}

export function toIcsUtc(instant: string): string {
  return new Date(instant).toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');
}
