# Consolidation of Claims Back-Office Operations - Engagement Brief for Selwyn Advisory

Halbrook Insurance | Claims Operations | Prepared for the Selwyn Advisory kickoff, 20 August 2026

## Why we are doing this

Halbrook processes claims at three back-office sites that were never designed as one operation.
Riverton is our original site and still handles intake, adjustments and correspondence for the
legacy policy book. Dunmoor came with the regional carrier we acquired in 2022 and kept its own
intake and adjustments teams; it also runs the escalations desk that takes kicked-back cases from
either site. Castlebridge opened last year for the new product line and runs claims review and
compliance. Each site has its own service leads, its own way of logging work, and its own staffing
plan, drawn up at different times on different assumptions. Reconciling the three ourselves has not
worked; that is why we have engaged Selwyn.

## What the board has already seen

Finance presented a consolidated headcount of 60.2 FTE at the July board meeting as the target for
the combined operation. That figure came from the site leads' draft plan, summed. It has not been
checked queue by queue against volumes, handle times or the role-level detail underneath it, and
the board has been told it is a target, not a certified number. We would rather find out now if it
does not hold than at the October meeting.

## Current position

The three sites together carry 66.0 FTE today, including duplicated site-level administration that
consolidation is meant to remove. The draft plan was prepared by the outgoing site leads as part of
the handover and reflects their local practice, including three different vintages of our
productive-time assumptions: Riverton's plan was built on the 2023 figure, Dunmoor's on the one the
acquired carrier used, and Castlebridge's on the current one.

## Planning basis

Halbrook's productive-time standard for workforce planning is 2,100 productive minutes per FTE per
week. It was revised in 2025 from the earlier 2,000, when the personal and administrative allowance
that used to be applied separately was folded into the base figure; nothing is applied on top of
it. It is the figure designated as current for this engagement and every queue is to be sized on
it, whatever assumption the site plan happened to use. Workforce Planning publishes it in the
annual planning letter and it does not change mid-year.

## What we need from Selwyn

A queue-by-queue requirement built from the role-level detail and the volume and handle-time data,
not from the summary. A plain answer on whether 60.2 holds, and if not, by how much and where. A
plan for what moves, from which queue to which, that respects the staffing floors and the
certification tiers, and that states any addition to headcount as an addition rather than
absorbing it into a total. We would also like the recurring administrative work at Castlebridge
looked at properly; the site has been carrying it informally since the product line launched and
the pilot-week service figures suggest it is not sustainable.

## Who is involved

- Selwyn Advisory: Naomi Ferris (engagement lead), Callum Bristow, Imogen Sato.
- Halbrook: the VP of Claims Operations is the accountable executive and signs the certification.
  Each queue's service lead (named in the staffing summary) is the contact for that queue. Workforce
  Planning holds the role-level detail. Employee Relations handles any open case. Site Operations
  (Dev Rourke) runs the shared Operations Support pool and will staff whatever the plan assigns to it.

## Dates

- Certification due: 5 October 2026.
- Board presentation: 12 October 2026.
- No slip has been agreed. If the certification is a HOLD, it must say what has to be true before
  it can be revisited, so the board can be given a date.

## Service commitment

Our claims-service agreement requires 90% of claims to be actioned within each queue's posted
turnaround window. Three consecutive weeks under 90% on any queue triggers a service-credit review
with the carrier. That review is a commercial matter for the account team and is not, on its own,
a reason to change a queue's staffing outside the certification process.
