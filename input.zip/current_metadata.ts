type Locale = 'en-us' | 'de-de' | 'en-ca' | 'en-gb';

type CmsPage = {
  locale: Locale;
  path: string;
  contentType: 'home' | 'listing' | 'category' | 'product' | 'article' | 'vertical' | 'legal' | 'form';
  modelId?: string;
  familyId?: string;
  published: boolean;
};

type Metadata = {
  alternates: {
    canonical: string;
    languages: Record<string, string>;
  };
  robots?: { index: boolean; follow: boolean };
};

const ORIGIN = 'https://www.atlasindustrial.com';

function stripLocale(path: string): string {
  return path
    .replace(/^\/de-de(?=\/|$)/, '')
    .replace(/^\/en-ca(?=\/|$)/, '')
    .replace(/^\/en-gb(?=\/|$)/, '') || '/';
}

function languageCode(locale: Locale): string {
  return locale === 'en-us' ? 'en-US'
    : locale === 'de-de' ? 'de-DE'
    : locale === 'en-ca' ? 'en-CA'
    : 'en-GB';
}

export function buildMetadata(page: CmsPage, allPages: CmsPage[]): Metadata {
  const basePath = stripLocale(page.path);
  const canonical = `${ORIGIN}${basePath}`;
  const languages: Record<string, string> = {};

  for (const candidate of allPages) {
    if (!candidate.published) continue;

    const sameSlug = stripLocale(candidate.path) === basePath;
    const sameProduct = page.modelId && candidate.modelId === page.modelId;
    const sameFamily = page.familyId && candidate.familyId === page.familyId;

    if (sameSlug || sameProduct || sameFamily) {
      languages[languageCode(candidate.locale)] = `${ORIGIN}${candidate.path}`;
    }
  }

  languages['x-default'] = `${ORIGIN}${basePath}`;

  return {
    alternates: { canonical, languages },
    robots: { index: page.published, follow: true },
  };
}
