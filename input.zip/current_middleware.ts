import { NextRequest, NextResponse } from 'next/server';

const PUBLIC_FILE = /\.[^/]+$/;
const LOCALE_COOKIE = 'site_market';

const redirectTable: Record<string, string> = {
  '/de': '/de-de',
  '/ca': '/en-ca',
  '/products/precision-pumps/ax-420': '/products/precision-pumps',
  '/products/precision-pumps/ax-430': '/products/precision-pumps',
  '/industries': '/solutions',
  '/industries/food-beverage': '/solutions/food-and-beverage',
  '/industries/pharmaceutical': '/solutions/pharma',
  '/resources': '/learning-center',
  '/resources/cavitation-guide': '/learning-center/avoiding-pump-cavitation',
  '/resources/pump-sizing-tool': '/tools/pump-selector',
  '/company': '/about',
  '/company/about': '/about',
  '/company/locations': '/about/locations',
  '/ca/resources/cavitation-guide': '/learning-center/avoiding-pump-cavitation',
  '/de/ressourcen/kavitationsleitfaden': '/de-de/wissen/pumpenkavitation-vermeiden',
};

function preferredMarket(request: NextRequest): 'US' | 'DE' | 'CA' {
  const cookieMarket = request.cookies.get(LOCALE_COOKIE)?.value;
  if (cookieMarket === 'DE' || cookieMarket === 'CA' || cookieMarket === 'US') {
    return cookieMarket;
  }

  const language = request.headers.get('accept-language')?.toLowerCase() ?? '';
  if (language.includes('de')) return 'DE';
  if (language.includes('en-ca')) return 'CA';
  return 'US';
}

function stripTracking(url: URL): URL {
  const keep = new URLSearchParams();
  for (const [key, value] of url.searchParams.entries()) {
    if (key.startsWith('utm_') || key === 'gclid' || key === 'fbclid') {
      keep.append(key, value);
    }
  }
  url.search = keep.toString();
  return url;
}

export function middleware(request: NextRequest) {
  const url = request.nextUrl.clone();
  const rawPath = url.pathname;

  const market = preferredMarket(request);
  if (market === 'DE' && !rawPath.startsWith('/de-de')) {
    url.pathname = `/de-de${rawPath === '/' ? '' : rawPath}`;
    return NextResponse.redirect(stripTracking(url), 307);
  }
  if (market === 'CA' && !rawPath.startsWith('/en-ca')) {
    url.pathname = `/en-ca${rawPath === '/' ? '' : rawPath}`;
    return NextResponse.redirect(stripTracking(url), 307);
  }

  if (
    rawPath.startsWith('/_next') ||
    rawPath.startsWith('/api') ||
    PUBLIC_FILE.test(rawPath)
  ) {
    return NextResponse.next();
  }

  const normalized = rawPath !== '/' && rawPath.endsWith('/')
    ? rawPath.slice(0, -1)
    : rawPath;
  const destination = redirectTable[normalized];
  if (destination) {
    url.pathname = destination;
    return NextResponse.redirect(stripTracking(url), 308);
  }

  return NextResponse.next();
}

export const config = {
  matcher: '/:path*',
};
