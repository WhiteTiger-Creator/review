Ozark Ridge County
Public Works / Facilities - Lease Administration SOP
Document: ORC-LA-SOP-2026
Last revised: 4 January 2026
Owner: Facilities fiscal clerk
Distribution: Public Works, Sheriff, Assessor, IT, Health

1. Purpose
This SOP tells departments how to post rent to the general ledger so 173-lease-liability and 573-lease-expense stay in the same place every month. It is an operations posting guide. Field staff should not wait on Accounting to enter a vendor invoice.

2. Account
All rent, including copiers, portable toilets, radio space, and hosted software, posts to 173-lease-liability. Do not use 573-lease-expense for the monthly invoice. The fiscal clerk reverses and reclasses at year-end if Accounting asks.

3. Rate
Departments use 6.00 percent on every contract. That rate is in the Munis lease screen as a default. Do not look up a different rate by remaining term. If Accounting later uses another table, that is an ACFR entry. It is not a change to this SOP.

4. Copiers and other equipment under one year
If a copier or portable unit will be gone in 12 months, still capitalize it. The Assessor’s Ricoh units and the fairgrounds toilets have been posted this way since FY2024. A remaining term under 12 months is not a reason to leave the item off 173.

5. Sheriff mileage
Sheriff fleet invoices include a per-mile charge. Add that variable amount to the capitalized base in the same month. Do not park miles in 573. The FY2026 estimate on the fleet contract is the number to load if the invoice is late.

6. Hosted software
If IT pays a vendor to host an application, treat it as a building lease. Load it at 6.00 percent for the remaining term on the quote. The tax-roll system is posted this way.

7. Missing commencement
If the contract file has no commencement date, use the first invoice date in Munis. If there is no invoice yet, use the purchase-order date. Do not leave the lease screen blank. A blank date breaks the 173 rollforward that Public Works sends to the Auditor.

8. Amendments
Keep the original monthly rent on the abstract until Facilities rekeys Munis. A PDF in the contract folder is not a Munis change. Do not rekey L-12 until Hale’s invoice shows the new rent for two consecutive months.

9. Year-end
Send Accounting a screenshot of the Munis lease screen and the SOP rate. That is the support for 173. If Accounting wants a different rate or wants an item off the ledger, they will book it. Departments do not change this SOP for the ACFR.

10. Who signs the Munis screen
The department fiscal clerk prints the lease screen on the last working day of June. The department head initials the printout. Public Works scans it to the year-end folder named 173-support. If a clerk is out, the backup clerk in Facilities signs. Accounting will not accept a screen with no initial.

11. What to do when a vendor changes rent
If an invoice shows a new monthly amount, keep posting the old Munis rent until Facilities rekeys. Put the difference on a balancing line in 573 so cash still clears. Do not invent a new 173 record. Hale’s clinic annex is the current example. Two consecutive invoices at the new rent is the trigger in section 8.

12. Radio tower and docks with no start date
Emergency Management and Parks still send invoices with no commencement on the contract file. Post them to 173 using the invoice date per section 7. Do not hold the payment. Accounting can hold the ACFR row. Operations cannot hold a vendor payment.

Revision history
4 Jan 2026  Rate left at 6.00 percent; hosted software language added.
12 Jul 2025  Sheriff mileage added to the capitalized base.
3 Feb 2024  Copiers under 12 months capitalized.
