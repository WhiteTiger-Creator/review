# Workforce Sizing Standard for Consolidation Engagements

Selwyn Advisory - Workforce Planning practice
Document WP-STD-04, revision 4, effective 1 August 2026
Applies to: any engagement that produces a staffing certification for a client operation

## 1. Purpose and scope

1.1 This standard sets the method Selwyn analysts use to size a processing operation and the
conditions under which a staffing plan may be certified to a client. It applies whether the
engagement is a consolidation, a re-baselining after an acquisition, or an annual review.

1.2 The standard does not set client-specific figures. Productive-time assumptions, credential
schemes and contractual constraints are taken from the client's own current records for the
engagement in hand.

## 2. Definitions

2.1 *Productive minutes per FTE* - the weekly minutes one full-time equivalent can spend on case
work after paid breaks, meetings, training and expected absence have been removed. The figure is
set per client and per engagement and is already net of those allowances.

2.2 *Requirement* - the FTE a queue needs to work its expected weekly volume at its measured
average handle time.

2.3 *Role-level detail* - the record listing, for each queue, the roles assigned to it and the FTE
in each. The staffing summary is a roll-up of this record for presentation; the detail is the
record of truth.

2.4 *Non-volume work* - work that recurs on a schedule (daily, weekly, monthly) rather than arriving
per case. Reconciliations, sign-offs, log reviews and similar.

2.5 *One-off work* - work tied to an event that will not repeat on a schedule: a system cutover, a
training cohort, an audit visit.

## 3. Sizing

3.1 A queue's requirement is its weekly volume multiplied by its average handle time in minutes,
divided by productive minutes per FTE.

3.2 Requirements are rounded up to the next 0.1 FTE. Fractions are not rounded down; a queue that
computes to 8.03 is planned at 8.1.

3.3 Do not apply a second shrinkage or allowance factor on top of the productive-minutes figure.
The figure already contains them. Applying them again double-counts.

3.4 Where the client has more than one productive-minutes figure on record (for example an older
figure from a previous engagement), use the figure the client has designated as current for this
engagement. Record which figure was used.

## 4. The role-level record

4.1 Every certification is checked against the role-level detail, not the summary. A queue whose
summary total looks reasonable can still be built from role lines that are wrong.

4.2 A person is counted once. A role that serves more than one queue is assigned a single home
queue in the detail and appears there only. If the same role appears against more than one queue
at the same FTE, treat it as one position recorded twice until the client confirms otherwise. Ask
the client to confirm before certifying; where the confirmation is still outstanding at
certification, the certification states the assumption made, carries the confirmation as a
condition, and says what changes in the plan if the confirmation goes the other way.

4.3 Non-volume work is not part of a queue's requirement under 3.1 and is not added to a queue's
Processor line. It is staffed separately, through the client's shared support arrangement
(at Halbrook, the Operations Support pool), and sized the same way: scheduled minutes per week
divided by productive minutes per FTE, rounded up per 3.2. The reason is practical - a daily task
worked by queue processors takes them off case work at the same time every day and shows up as
missed turnaround on those days, which a weekly average hides.

4.4 One-off work is excluded from the weekly requirement. It is costed as a project item when it
happens.

## 5. Moving staff between queues

5.1 A plan may move Processor FTE from a queue that has more than its requirement to one that has
less, subject to 5.2 to 5.4.

5.2 The receiving queue's certification tier must be the same as or lower than the sending queue's,
unless the specific people moving already hold the receiving queue's credential. Tiers and
credentials are taken from the client's certification registry.

5.3 A queue subject to an active staffing floor is not reduced below the floor, whatever its
computed requirement. Floors that have been lifted or that are recorded as notes only do not
constrain.

5.4 A move changes where people sit, not how many there are. If the plan needs more people in
total than it started with, or fewer, that is a net addition or reduction and the certification
says so in those words. It is not presented as a reallocation.

## 6. Employee relations matters

6.1 A grievance or complaint about workload is referred to Employee Relations and handled there.
It is not evidence about the queue's requirement in either direction. The requirement comes from
3.1; the grievance follows its own process.

## 7. Prior engagements

7.1 A staffing plan from an earlier engagement, for this client or another, is background. It is
not carried into the current plan unless every assumption it rested on - productive minutes, site
count, the support arrangement for non-volume work - is confirmed unchanged for the current
engagement.

## 8. Certification

8.1 Certify GO when every queue's planned FTE meets or exceeds its requirement, every active floor
is honoured, every scheduled non-volume task is staffed through the support arrangement, and any
net addition or reduction is stated as such.

8.2 A GO may carry conditions that do not by themselves block the plan - an open employee-relations
case, a credential check to complete before a move takes effect, a duplicate-record confirmation
under 4.2 where the certification states what changes if it goes the other way.

8.3 Certify HOLD when a queue remains below requirement in the plan as written, or when a move
depends on a credential that has not been confirmed.

8.4 The certification states the requirement per queue and the corrected total on the same basis,
and shows the before-and-after headcount so that a queue running short cannot be hidden inside a
total that happens to balance.

## 9. Records and sign-off

9.1 The certification cites the client records it relied on by name. Where a figure was corrected,
the certification shows the original and the correction.

9.2 Workforce Planning owns the corrected detail and the plan. Employee Relations owns any open
case. The client's operations owner for the shared support arrangement staffs any non-volume work
the plan assigns there. The client's accountable executive signs the certification.

9.3 Engagement records are retained for seven years under the practice's retention schedule.
