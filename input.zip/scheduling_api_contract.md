# Scheduling API contract — v6.2

## Slot response

`GET /v6/slots` returns server-created slot records. Each record contains:

```text
slot_id
office_id
office_tz
office_local_start
start_utc
end_utc
availability_revision
capacity_remaining
offset_choice (null, EARLIER, or LATER)
```

The client may format `start_utc` in another zone for display, but it must retain and submit the unchanged `slot_id` and `availability_revision`. The UI may not create a slot ID from a timestamp.

## Create booking

`POST /v6/bookings` accepts:

```json
{
  "slot_id": "SLOT-BOS-20270315-0900-R12",
  "availability_revision": 12,
  "idempotency_key": "client-generated UUID",
  "client_display_zone": "America/Los_Angeles"
}
```

`client_display_zone` is optional presentation context. It does not participate in booking identity or time resolution.

Success is HTTP 201 with the accepted booking, including `booking_id`, `booking_version`, `start_utc`, `end_utc`, `office_tz`, and `availability_revision`. Repeating the same idempotency key with the same command returns HTTP 200 and the same booking. Reusing the key with different command fields returns HTTP 422 `IDEMPOTENCY_KEY_CONFLICT`.

The service returns HTTP 409 `STALE_AVAILABILITY` when the supplied availability revision is not current, `HOLD_ACTIVE` when another hold owns the slot, and `CAPACITY_FULL` when no capacity remains. The UI must refresh slots after any 409 and must not automatically retry a different slot.

## Direct local-time resolution

The administrative recovery endpoint accepts an office IANA zone, ISO local date-time without an offset, and optional `offset_choice`. It returns one of:

- HTTP 200 with one accepted UTC instant for a unique local time;
- HTTP 409 `NONEXISTENT_LOCAL_TIME` with no candidate for a gap;
- HTTP 409 `OFFSET_CHOICE_REQUIRED` with two ordered UTC candidates for an overlap without a choice;
- HTTP 200 with the selected candidate when `EARLIER` or `LATER` is supplied.

Clients may not choose the first candidate automatically.

## Reschedule and cancellation

`POST /v6/bookings/{booking_id}/reschedule` requires `booking_version`, `slot_id`, `availability_revision`, and a new idempotency key. Success increments `booking_version`. HTTP 409 `STALE_BOOKING_VERSION` leaves the existing booking unchanged.

`DELETE /v6/bookings/{booking_id}` requires the current `booking_version`. A stale cancellation returns HTTP 409 and leaves the booking confirmed. A successful cancellation increments the version and returns the authoritative cancelled record.

## Calendar handoff

Calendar generation receives the accepted booking response, not the form state. It must use the response `start_utc`, `end_utc`, and `booking_version`. A replacement delivery for a reschedule supersedes prior invite versions; it does not modify the old attachment in place.

## Error and audit fields

Every create, reschedule, cancellation, and invite request records `request_id`, `idempotency_key` where present, `booking_id`, `booking_version`, `slot_id`, `availability_revision`, and the resulting status. The browser may show a friendly message, but the audit result code must remain unchanged.
