# Ashworth Advisory Partners
# Engagement planning memorandum

Client: Locklear Instrument Company
Engagement: pre-issuance revenue review, quarter ended June 30, 2026
Engagement code: LIC-26-Q2
Partner: Gail Ashworth
Prepared: 2026-07-06

## Nature of the engagement

Locklear reports quarterly to its lender and to its board under a credit agreement that requires a
revenue schedule with each quarterly reporting package. Locklear has asked us to review the
quarter's revenue on the contracts most exposed to judgment before that package is issued.

This is an agreed-upon pre-issuance review of one account balance. It is not an audit, it is not
a review of financial statements under the attestation standards, and no opinion, conclusion or
assurance is expressed on Locklear's financial statements as a whole. Our report is a memorandum
to the Locklear controller and to this engagement partner. Nothing in it may be described as an
audit or an audit opinion.

## Scope

In scope: the ten contracts in the quarter that carry more than one performance obligation or a
contract modification, listed in contract_register.csv as C-2401 through C-2410. For each, we
recompute revenue for the quarter ended June 30, 2026 under Locklear's board approved policy
RP-04, compare it with the amount Locklear recorded, and quantify the difference.

Out of scope, and referred back to Locklear where affected: cost of sales, inventory, income
taxes, receivable credit loss allowances, contracts with a single performance obligation and no
modification, and periods other than the quarter ended June 30, 2026.

## Thresholds

Locklear's forecast revenue for the year ending December 31, 2026 is 23.4 million dollars.

- Materiality applied to this review: 164,000 dollars, being 0.7 percent of forecast
  annual revenue.
- Performance materiality: 115,000 dollars, 70 percent of materiality,
  used to scope procedures.
- Clearly trivial threshold: 5,750 dollars, 5 percent of performance materiality.

A difference below the clearly trivial threshold is documented in the memorandum but is not
accumulated in the summary of differences. Differences at or above that threshold are
accumulated. The aggregate is taken net, that is gross overstatements less gross
understatements, and the net figure is compared with materiality of 164,000 dollars.
Where the net accumulated difference exceeds materiality, the quarter's revenue cannot be
reported as recorded and the differences have to be corrected before the reporting package is
issued.

## Approach

Recompute from the source records rather than from Locklear's revenue subledger. Transfer of
control is evidenced by the field service and logistics export, not by the invoice register.
Allocation is recomputed from the current price list. Modifications are read from the amendment
file and classified under section 6 of RP-04 before any arithmetic.

Every difference in the memorandum has to name the record it rests on so Locklear's controller can
re-perform it. We do not have authority to accept, waive or pass any difference; that decision
belongs to Locklear's management and, above materiality, to its audit committee, and no such
decision has been taken as at the date of this memorandum.
