# Checkout SDK change and deprecation policy

Effective 2026-07-01. Supersedes the 2025 revision. Approved by Engineering Leadership and
Contracts. Questions to Platform Delivery.

This policy governs any change to a published SDK build, a delivery channel, or a record the
SDK persists in a shopper's browser. It applies to every merchant on the hosted checkout,
whether or not their contract names it.

## 1. Release train

Storefront-affecting promotions ship on the release train only: Tuesdays and Thursdays at
15:00 UTC. There is no third slot and no same-day promotion. A change that misses its slot
waits for the next one. Hotfixes for an active severity-1 incident are exempt and require the
on-call director's approval in the incident channel.

## 2. Seasonal freeze

No storefront-affecting promotion may be released between 2026-11-24 00:00 UTC and
2026-12-02 23:59 UTC inclusive. This window is written into every tier 1 agreement.

A promotion also may not be scheduled so that its propagation window runs into the freeze. The
propagation window is the interval between the promotion and the point at which the slowest
browser on that delivery path can still be running the previous build. A build that is still
arriving at shoppers when the freeze opens is a change inside the freeze, and Contracts has
been explicit that they read it that way.

## 3. Written notice

Tier 1 merchants receive 60 days of written notice before a breaking change reaches an embed
they use. The clock starts on the date the notice is sent, not the date it is drafted, and not
the date the change is planned. `deprecation_notice_sent` in the embed registry is the system
of record for that date. Tier 2 merchants receive notice as a courtesy with no contractual
period attached.

## 4. Build retirement

A published build is treated as retired on the first date on which its share of that
integration's non-synthetic sessions, averaged over the trailing seven days including that
date, falls below 0.5 percent.

Two things follow from the wording and both have caused arguments before. The measure is a
seven-day trailing mean, not a single day's reading, because app rollouts in particular
produce a day that dips under the line and then comes back. And synthetic traffic is excluded
before the share is computed. Monitors, smoke checks, and probes registered in
`synthetic_monitor_register.csv` are not shoppers and never keep a build alive.

Retiring a build means we stop treating it as a compatibility obligation. It does not mean the
immutable pin is deleted; pins stay published.

## 5. Persisted browser records

The SDK writes records into the shopper's browser storage. Those records are the shopper's
work, not ours, and the following rules are absolute.

A migration may not delete, clear, or overwrite the record belonging to an older schema
version while any non-retired build still reads that version. Until then the SDK writes both
representations on every save. This is the dual-write window, and it exists because two tabs
can be open on two different builds at the same time, and because a shopper who was served a
cached older build after being served a newer one has to find their cart where the older build
looks for it.

A migration may not discard a field it cannot interpret. If a value does not fit the target
shape it is carried across unchanged and flagged, and the shopper or a later build decides
what it means. Inventing a structured value from an unstructured one is prohibited outright.

Once every build that reads the older schema version is retired, the older record may still be
holding a cart that a returning shopper has not seen yet. The read path for the older version
therefore stays in place for the full cart retention window, measured from the date the dual
write stops. See `storage_schema_v1.md` for the retention window.

Payment instruments, payment session tokens, and shopper email addresses are never persisted to
browser storage and never written to a client log line. This has been a finding in two
consecutive assessments and is not negotiable.

## 6. Rollback

Every promotion must be revertible for 14 days after release with no loss of shopper data.
A change that cannot be reverted without dropping a persisted record is not eligible for the
train and goes back to design.

## 7. Merchant-side dependencies

Where a merchant's own caching, bundling, or release process controls when they receive a
build, the change plan names the merchant, the dependency, and the action we are asking them
to take, with an owner and a date. A plan that assumes a merchant will simply pick up a
channel promotion when their integration cannot is not an approved plan.
