export function startReceiptWorker(pathname: string): Worker {
  const source = `self.onmessage=async(e)=>{const r=await fetch(e.data.url);postMessage(await r.arrayBuffer())}`;
  const workerUrl = URL.createObjectURL(new Blob([source], { type: "text/javascript" }));
  const worker = new Worker(workerUrl);
  worker.postMessage({ pathname });
  return worker;
}
