# Verification Summary - Novotny Conveyor Interlock Controller, firmware IC-4.1.1

Kilbride Verification Partners
Document KVP-NOV-VS-411, revision A
Filed 2026-07-02

Build verified: BLD-2277 (IC-4.1.1), built 2026-06-29
Client: Novotny Industrial Systems, attention M. Halloran, Controls Engineering
Verification lead: Priya Osei

## Scope

This summary reports the verification of firmware build BLD-2277 against the sixteen requirements
of the IC-4.x requirement specification, revision 3, and the six hazard controls in the hazard
analysis dated 2026-04-14. Evidence was taken from the ic411-regression suite executed on
ci-runner-02 on 2026-06-30 and from the defect register as of 2026-07-01. Bench observations that
were not captured by the runner are not counted.

## Result

All sixteen requirements had passing evidence against BLD-2277. The six safety-critical
requirements, REQ-H01 through REQ-H06, were each supported by at least one passing run of a test
case declared against them. REQ-H05 was supported by three consecutive passes of TC-110 following
the closure of DEF-0007 as not reproducible. REQ-H06 was supported by TC-112 following the DEF-0009
lockout timer correction.

## Items open at filing

1. The fault display latency measurement for REQ-F07 (TC-121) produced one out-of-tolerance
   result during the run before passing on repeat. Test Automation is reviewing the measurement
   method. DEF-0011 remains open.
2. Novotny raised a belt telemetry continuity question against REQ-F01 at the 2026-06-24 review.
   It was not reproduced during this campaign and no defect was opened.

## Recommendation

Release IC-4.1.1, with the two items above tracked in the defect register and reported at the
next quarterly review.

## Approvals

Verification lead: P. Osei, 2026-07-02
Practice review: H. Lindqvist, 2026-07-02
Client acceptance: pending. Novotny has not yet reviewed the IC-4.1.1 package.

Distribution: Novotny Industrial Systems (Controls Engineering); Kilbride project file NOV-2026-03.
