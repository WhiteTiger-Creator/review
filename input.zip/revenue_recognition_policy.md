# Locklear Instrument Company
# Revenue recognition policy RP-04
# Approved by the board of directors 2025-08-19. Supersedes RP-03.
# Owner: Corporate Controller. Applies to all customer contracts in every reporting period.

## 1. Framework

Revenue is recognized when control of a promised good or service transfers to the customer, in
the amount of consideration the Company expects to be entitled to. Every contract is worked
through the same five steps: identify the contract, identify the performance obligations,
determine the transaction price, allocate the transaction price to the performance obligations,
and recognize revenue as each obligation is satisfied.

## 2. Performance obligations

An analyzer, an installation and calibration service, a software subscription, a coverage service
plan, a block of onsite training days, and a reagent kit are each capable of being distinct and
are separately identifiable in the Company's contracts. Each is a separate performance
obligation. A validation and integration project is a single performance obligation: the
individual work packages are inputs to one integrated system and are not separately identifiable
from each other.

## 3. Transaction price

The transaction price is the consideration stated in the contract, adjusted for variable
consideration. Variable consideration includes volume rebates, price concessions and refund
obligations. It is estimated using the expected value or the most likely amount, whichever
better predicts the outcome, and is included only to the extent a significant reversal is not
expected.

Where a customer rebate is earned retrospectively across a program year, the Company estimates
the rebate percentage the customer is expected to reach and applies that percentage as a
reduction of the transaction price of every contract and amendment entered into during the
program year. The reduction is recorded against revenue in the period the related revenue is
recognized and is carried as a refund liability until settled. The rebate is estimated on the
purchase activity known at the reporting date; it is not deferred until the program year closes.

## 4. Allocating the transaction price

The transaction price is allocated to the performance obligations in proportion to their
standalone selling prices. The standalone selling price is the observable price in the current
price list when the Company sells that item separately.

The residual approach may be used for one performance obligation in a contract, and only where
the observed range of standalone transaction prices for that item over the trailing twelve
months exceeds 25 percent of its list price, so that the price is genuinely highly variable. The
residual amount must fall inside the observed range for the item; if it does not, the residual
approach is not an acceptable measure and the relative standalone selling price method applies.
The residual approach may not be used merely because an item is sold as part of a bundle, and it
may not be used for an item whose price the Company publishes and holds firm.

Allocated amounts are recorded in whole dollars. Each obligation is rounded to the nearest
dollar and the last obligation listed on the contract absorbs the rounding so the allocated
amounts equal the transaction price.

A discount is allocated proportionately to all performance obligations unless the Company has
observable evidence that the discount relates to only some of them.

## 5. Recognizing revenue

Analyzers and reagent kits are recognized at a point in time. For a contract carrying FOB
shipping point terms, control transfers on the carrier pickup scan. For a contract carrying FOB
destination terms, control transfers on the consignee signature scan at the customer site.
Issuing an invoice does not transfer control and does not support recognition on its own.

Installation and calibration is recognized when the field service report closing the installation
is filed.

Onsite training is recognized as each training day is delivered, at the allocated amount for the
block divided by the number of days in the block.

Software subscriptions and coverage service plans are recognized ratably on a daily basis. Where
the contract also contains an installation obligation, recognition begins on the later of the
service start date stated in the contract and the date installation is completed, because the
customer cannot use the service before the instrument is installed. Where the contract contains
no installation obligation, recognition begins on the stated service start date. The allocated
amount is spread evenly over the days from the recognition start date through the service end
date stated in the contract, counting both endpoints.

Validation and integration projects are recognized over time using an input measure. Progress is
measured as cumulative costs incurred divided by the current estimate of total costs at
completion. The estimate at completion is revised whenever the scope changes, and the revised
estimate is used from the period of the change onward.

## 6. Contract modifications

A modification that adds distinct goods or services, priced at their standalone selling prices,
is accounted for as a separate contract. Nothing in the original contract is remeasured.

A modification that adds distinct goods or services at a price that does not reflect their
standalone selling prices is accounted for prospectively. The consideration not yet recognized
under the original contract is combined with the modification consideration and allocated across
the remaining performance obligations.

A modification whose added goods or services are not distinct from a partially satisfied
performance obligation is accounted for as part of the existing contract. The transaction price
and the measure of progress are both updated, and the effect on revenue already recognized is
recorded as a cumulative catch up in the period of the modification.

## 7. Collectability

Collectability is assessed once, at contract inception, when the Company decides whether a
contract exists. Where that assessment was satisfied, later payment difficulty, a service credit
claim or a customer dispute over performance does not defer, suspend or reverse revenue.
Amounts at risk are evaluated as credit losses on the receivable and, where a concession is
expected to be granted, as variable consideration. Revenue is never held back merely because an
invoice is unpaid at the reporting date.

## 8. Cutoff

Revenue is recorded in the reporting period in which control transfers, measured from the
shipping, delivery and field service records, not from the order date, the invoice date or the
cash receipt date.
