# Vendor field observations

These notes were taken during joint visits on May 26-29 and remain observational evidence, not approval.

- At **LOCK-3ZHHEW** on route N-18, build 4.18.7 accepted a package traced to LIN-RC-24B. The same package was rejected by the adjacent K3-only controller.
- At **LOCK-DWQT5E**, the audit export showed LIN-RC-25E in the trusted set after a February firmware maintenance visit. Forty-nine devices in that group reported the family during the sample.
- The west-hospital group **LOCK-RSGAQB** cannot be tested after 18:00 without the hospital access desk. The local contact asked for a 30-minute arrival notice.
- **LOCK-7ES8LG** and **LOCK-RCC4F3** use different firmware branches even though both are on southern routes. Their results should not be combined for closure.
- The controller at **LOCK-C7PEZG** retained a stale vendor manifest, but its observed trust list still included both incident lineages. The manifest correction is open under CASE-PNSBNN.
- **LOCK-KQFPC6** produced the longest estimated route window, 96 minutes, because the central depot has five attended doors and a split courier shift.
- No test at **LOCK-MWFMZ2** accepted either incident lineage. Its row stays in the fleet denominator because it was reviewed, but it does not enter the accepting-device total.

Devon Hale reviewed the device observations. Jonah Reed retained the exported trust lists. Operations supplied the route and attended-access constraints.
