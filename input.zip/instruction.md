# Workforce planning task

## Workplace request
A U.S.-based animal-care organization wants a better understanding of the day-to-day work handled by Veterinary Assistants and Laboratory Animal Caretakers. The manager will use the brief to think through staffing, training, and work assignment.

## Source evidence
Use only these supplied O*NET files:
- Tasks.xlsx
- Detailed Work Activities.xlsx
- Work Context.xlsx

Do not use external research or invent employer-specific statistics.

## Required analysis
1. Integrate task importance, detailed activities, and work context rather than writing three isolated summaries.
2. Address animal handling/care, preparation/sanitation, observation/documentation, veterinary procedure support, and routine facility/administrative work.
3. Explain work conditions such as physical demands, contact with animals/people, concentration/accuracy, schedules, environmental conditions, and work structure.
4. Distinguish direct source facts from interpretation. Use explicit markers such as:
   - O*NET-SUPPORTED FINDING
   - MANAGEMENT INTERPRETATION
   - LOCAL VALIDATION GAP
5. Recommend exactly three realistic workforce actions. For each, state the evidence, implementation, roles/resources, and what management should observe afterward.
6. Compare the three actions on usefulness, effort, resources, and disruption. Identify one action to explore first.
7. Provide a practical review plan over a stated timeframe, with participants, measures, and a decision after each stage.
8. State what employer-specific information is missing from O*NET and must be collected locally.

## Deliverable
The primary deliverable must be named:
veterinary_assistant_workforce_planning_brief.docx

A professional PDF and presentation may accompany the DOCX, but the DOCX is the required primary deliverable.
