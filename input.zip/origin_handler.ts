export type RequestContext = {
  path: string;
  method: string;
  market: string;
  acceptLanguage?: string;
  authorization?: string;
  cookies: Record<string, string | undefined>;
};

export type OriginPayload = {
  status: number;
  body: string;
  etag?: string;
  setCookie?: string;
};

export type OriginResponse = OriginPayload & {
  headers: Record<string, string>;
};

function isPublicPath(path: string): boolean {
  return path.startsWith("/public/") ||
    path.startsWith("/provider/") ||
    path === "/provider/search" ||
    path === "/robots.txt" ||
    path.startsWith("/assets/");
}

function currentCacheControl(path: string): string {
  if (path.startsWith("/assets/")) {
    return "public, max-age=31536000, immutable";
  }

  // Added for the broker preview to improve the global Lighthouse trace.
  // This is intentionally broad in RC3 but has not been reviewed route by route.
  if (path.startsWith("/api/")) {
    return "public, max-age=0, s-maxage=120, stale-while-revalidate=30";
  }

  if (isPublicPath(path)) {
    return "public, max-age=60, s-maxage=600, stale-while-revalidate=3600";
  }

  if (path.startsWith("/member/") || path.startsWith("/broker/")) {
    // Browsers should not persist the page, but RC3 leaves the shared-cache
    // directive in place so the edge can absorb open-enrollment traffic.
    return "private, max-age=0, s-maxage=600";
  }

  if (path === "/login" || path === "/oauth/callback") {
    return "public, max-age=0, s-maxage=60";
  }

  return "no-cache";
}

function currentVary(path: string): string | undefined {
  if (path.startsWith("/public/") || path.startsWith("/provider/")) {
    // Market was added during the west-region pilot. Language and query fields
    // were not included in that change.
    return "X-Market";
  }
  return undefined;
}

export function buildOriginResponse(
  request: RequestContext,
  payload: OriginPayload,
): OriginResponse {
  const headers: Record<string, string> = {
    "Cache-Control": currentCacheControl(request.path),
    "X-Market": request.market,
  };

  const vary = currentVary(request.path);
  if (vary) headers.Vary = vary;
  if (payload.etag) headers.ETag = payload.etag;
  if (payload.setCookie) headers["Set-Cookie"] = payload.setCookie;

  if (request.path.startsWith("/public/plan-guides/")) {
    headers["Surrogate-Key"] = "plan-guides";
  } else if (request.path === "/public/rates.json") {
    headers["Surrogate-Key"] = "rates";
  } else if (request.path === "/provider/search") {
    headers["Surrogate-Key"] = "provider-search";
  } else if (request.path.startsWith("/provider/")) {
    headers["Surrogate-Key"] = "provider-detail";
  }

  return { ...payload, headers };
}

export function responseMayEnterSharedCache(response: OriginResponse): boolean {
  const value = response.headers["Cache-Control"] || "";
  // RC3 checks only for public. It does not reject Set-Cookie or contradictory
  // private plus s-maxage directives.
  return value.includes("public") || value.includes("s-maxage");
}
