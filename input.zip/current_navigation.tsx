import Link from 'next/link';

type Locale = 'en-us' | 'de-de' | 'en-ca' | 'en-gb';

type NavItem = {
  label: string;
  href: string;
  locales?: Locale[];
  state?: 'published' | 'draft';
  children?: NavItem[];
};

const desktopItems: NavItem[] = [
  { label: 'Products', href: '/products' },
  { label: 'Solutions', href: '/solutions' },
  { label: 'Learning Center', href: '/learning-center' },
  { label: 'Pump Selector', href: '/tools/pump-selector' },
  { label: 'Support', href: '/support' },
  { label: 'Request a Return', href: '/support/request-return' },
  { label: 'About', href: '/about' },
];

const mobileItems: NavItem[] = [
  { label: 'Products', href: '/products' },
  { label: 'Learning Center', href: '/learning-center' },
  { label: 'Support', href: '/support' },
  { label: 'About', href: '/about' },
];

const localeBase: Record<Locale, string> = {
  'en-us': '',
  'de-de': '/de-de',
  'en-ca': '/en-ca',
  'en-gb': '/en-gb',
};

const labels: Record<Locale, Record<string, string>> = {
  'en-us': {},
  'en-ca': {},
  'en-gb': {},
  'de-de': {
    Products: 'Produkte',
    Solutions: 'Lösungen',
    'Learning Center': 'Wissen',
    Support: 'Support',
    About: 'Über uns',
    'Request a Return': 'Rücksendung',
    'Pump Selector': 'Pumpenauswahl',
  },
};

function localize(item: NavItem, locale: Locale): NavItem {
  const base = localeBase[locale];
  return {
    ...item,
    label: labels[locale][item.label] ?? item.label,
    href: `${base}${item.href}`,
  };
}

function ItemList({ items, locale }: { items: NavItem[]; locale: Locale }) {
  return (
    <ul>
      {items.map((item) => {
        const localized = localize(item, locale);
        return (
          <li key={`${locale}:${localized.href}`}>
            <Link href={localized.href}>{localized.label}</Link>
          </li>
        );
      })}
    </ul>
  );
}

export function DesktopNavigation({ locale }: { locale: Locale }) {
  return <ItemList items={desktopItems} locale={locale} />;
}

export function MobileNavigation({ locale }: { locale: Locale }) {
  return <ItemList items={mobileItems} locale={locale} />;
}

export function MarketSelector() {
  return (
    <ul aria-label="Market selector">
      <li><Link href="/">United States</Link></li>
      <li><Link href="/de-de">Deutschland</Link></li>
      <li><Link href="/en-ca">Canada (English)</Link></li>
      <li><Link href="/en-gb">United Kingdom</Link></li>
    </ul>
  );
}
