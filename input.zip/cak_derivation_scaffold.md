# CAK Line-Force Derivation Notes and Working Scaffold

Working notes for implementing a modified (finite-disk) Castor, Abbott & Klein (1975, CAK) radiation-driven wind module. Some derivation steps are incomplete and marked with `[GAP]`. Complete these algebraic steps and ensure the resulting Python module reproduces the target observations in `survey_linelist.csv` and evaluates the line force point-by-point against the tabulated flows in `wind_profile_*.csv`.

---

## 1. Physical Context and Literature Background

In early-type stars (O-type dwarfs/supergiants, B supergiants, and early A supergiants), radiation pressure on thousands of metal absorption lines drives high-velocity supersonic outflows. The classical point-star formulation was developed by Castor, Abbott & Klein (1975, ApJ 195:157), while the finite-disk geometric correction factor $C_{\text{fd}}$ was introduced by Pauldrach, Puls & Kudritzki (1986, A&A 154:86; PPK86) and Kudritzki et al. (1989, A&A 219:205).

The wind model operates under the following standard assumptions:
- **Steady, Spherically Symmetric Outflow:** Radial 1-D flow where $\partial/\partial t = 0$ and non-radial motions are neglected.
- **Sobolev Approximation:** The velocity gradient $dv/dr$ in supersonic wind acceleration is sufficiently large that line resonance occurs over a narrow spatial layer $\Delta r \sim v_{\text{th}} / (dv/dr) \ll R_*$.
- **Power-Law Line Distribution:** The statistical distribution of dimensionless line strengths $\kappa_0 \equiv \kappa_L / \kappa_e$ follows $dN/d\kappa_0=A\kappa_0^{\alpha-2}$, where $0<\alpha<1$. Map the distribution normalization and any gamma-function factor onto the operational CAK coefficient $k$ only after completing the integral below.
- **Eddington-Reduced Gravity:** Continuum radiation pressure on free electrons reduces the stellar mass to an effective value $M_{\text{eff}} = M(1 - \Gamma_e)$, where $\Gamma_e = \kappa_e L / (4\pi G M c)$ and $\kappa_e = 0.20(1 + X)\,\text{cm}^2/\text{g}$.

---

## 2. Radiative Line Acceleration Derivation

### Single-Line Sobolev Force
For an isolated spectral transition with line opacity $\kappa_L = \kappa_0 \kappa_e$, the radial optical depth through the resonance zone is:
$$t = \frac{\kappa_L \rho v_{\text{th}}}{|dv/dr|} = \kappa_0 \frac{\kappa_e \rho v_{\text{th}}}{|dv/dr|}$$
The frequency-integrated radiative acceleration contributed by this transition is:
$$g_{\text{line}}^{(1)}(\kappa_0) = \frac{\kappa_e L}{4 \pi r^2 c} \cdot \kappa_0 \cdot \left[ \frac{1 - e^{-t}}{t} \right]$$

### Integration over the Line Ensemble
Integrating $g_{\text{line}}^{(1)}$ over the power-law opacity distribution $dN/d\kappa_0$:
$$g_L = \int_0^\infty g_{\text{line}}^{(1)}(\kappa_0) \left( \frac{dN}{d\kappa_0} \right) d\kappa_0$$

`[GAP]` Evaluate this integral using substitution $u \equiv \kappa_0 t_{\text{eff}}^{-1}$ where $t_{\text{eff}} \equiv \frac{dv/dr}{\kappa_e \rho v_{\text{th}}}$. Carry out integration by parts to evaluate the resulting $\Gamma$-type integral. Work out for yourself what power the Sobolev optical depth bracket $t_{\text{eff}}$ must carry and what normalization prefactor comes along with it — do not assume the exponent in advance. Then read the legacy PLUTO C module in `boulder_cak_force.py`, note which exponent it uses on its velocity-gradient term, and decide whether it survives comparison with your derivation.

---

## 3. Finite-Disk Geometry Correction (PPK86 / m-CAK)

The classical CAK 1975 formulation treats the star as a point source of radiation at the origin. Close to the stellar surface ($r \sim R_*$), incoming rays from the extended stellar disk strike the gas at non-zero angles $\theta$ relative to the radial direction ($\mu \equiv \cos\theta \in [\mu_* \equiv \sqrt{1 - (R_*/r)^2}, 1]$), reducing the net radial momentum transfer.

`[GAP]` For this task, adopt the constant m-CAK finite-disk approximation $C_{\text{fd}}(\alpha) = (1 - \alpha)/(1 + 2\alpha)$ as given in the task statement (Pauldrach, Puls & Kudritzki 1986; Kudritzki et al. 1989). Do not present it as derived from CAK 1975 alone: the 1975 paper gives a radius-dependent angular correction, not this constant rational form. Show why an angular reduction over the subtended disk yields a multiplicative factor $< 1$ that depends only on $\alpha$ in the supersonic near-critical zone, and verify $C_{\text{fd}}(\alpha) < 1$ for physical values $\alpha \in [0.4, 0.7]$.

---

## 4. Critical-Point Regularity and Mass-Loss Rate

Neglecting gas pressure in the supersonic expansion, the 1-D radial equation of motion is:
$$v \frac{dv}{dr} = -\frac{G M_{\text{eff}}}{r^2} + g_L^{m\text{CAK}}$$

Using mass continuity $\rho = \dot{M} / (4 \pi r^2 v)$ and defining the inertial acceleration variable $Z \equiv v \frac{dv}{dr}$, the momentum equation becomes an algebraic relation $F(r, Z) = 0$ at each radius.

`[GAP]` Apply the critical-point singularity conditions:
$$F(r_c, Z_c) = 0, \quad \frac{\partial F}{\partial Z}\Big|_{(r_c, Z_c)} = 0$$
Solve for the critical acceleration $Z_c$, substitute back to eliminate the critical radius $r_c$, and derive the closed-form mass-loss rate $\dot{M}$. Keep $C_{\text{fd}}$ as a symbol throughout the algebra, then record what power $k$ and $C_{\text{fd}}$ ultimately enter $\dot{M}$ with — that scaling feeds the sensitivity section of the report.

---

## 5. Terminal Velocity and Survey Calibration

Point-star CAK predicts $v_\infty = v_{\text{esc},\text{eff}} \sqrt{\alpha / (1-\alpha)}$. When finite-disk and multi-line ionization effects are included, the terminal velocity scales with the effective escape speed via spectral-class dependent coupling factors $q(\text{SpT}) \equiv v_\infty / v_{\text{esc},\text{eff}}$:
- O-type stars: Strong UV resonance lines drive fast winds exceeding effective escape velocity ($q > 2.0$).
- B-type supergiants: Intermediate ionization and moderate optical depths lead to intermediate scaling ($1.0 < q < 2.5$).
- A-type supergiants: Lower ionization stages and high optical depths near the bistability jump lead to sub-escape terminal speeds ($q < 1.0$).

`[GAP]` Determine the empirical spectral-class ratio table $q(\text{SpT})$ by calibrating against the observed $v_\infty$ and stellar parameters in `survey_linelist.csv` for each spectral class (O-dwarfs/giants, B-supergiants, A-supergiants). Implement the validation routine in `cak_force.py` to compare computed $\dot{M}$ and $v_\infty$ against `survey_linelist.csv` across all 12 survey stars. Separately, read `wind_profile_S01.csv` through `wind_profile_S12.csv` directly and evaluate, for every tabulated row, $v\,dv/dr$, $g_{\text{grav,eff}}$, $g_L^{m\text{CAK}}$, and the momentum residual $v\,dv/dr - [g_L - g_{\text{grav,eff}}]$; quantify the mismatch where the reduced pressure-free momentum equation does not close rather than assuming it must.
