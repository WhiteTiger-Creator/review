# Draft permit terms for August 2026 comment response packet

Permit file: Meridian Surface Coatings, synthetic minor renewal
Draft date: August 7, 2026
Prepared for public hearing response review

These excerpts are the draft conditions most often referenced in comments received after the public notice. The excerpts are not the full permit. They preserve the current draft wording so response staff can decide whether comment resolution needs a limited edit.

## Source inventory excerpt

The renewal covers the following stationary emission units and control devices:

1. Coating line CL-1, controlled by wet scrubber WS-2.
2. Baghouse stack S-01 serving dry sanding and finishing booths.
3. Emergency generator EG-1, 285 brake horsepower, compression ignition.
4. Natural gas make-up air heater H-1.
5. Solvent storage room vents V-2A and V-2B.

The draft permit does not list fleet trucks, public road segments, neighborhood routes, school walk routes, or the loading dock as permitted emission units. Comments about those activities may still appear in the hearing record.

## Condition 2.1 Particulate matter from baghouse stack S-01

The permittee shall not emit particulate matter from baghouse stack S-01 at a rate greater than 0.015 gr/dscf, corrected to standard conditions. Compliance with the limit is demonstrated by the most recent agency-accepted three-run stack test unless the agency requires a later test under the testing provisions of the permit.

The permittee shall operate and maintain the baghouse whenever dry sanding or finishing booth exhaust is routed to S-01. The permittee shall keep differential pressure readings, maintenance entries, bag replacement records, and visible-emission observation notes for agency review.

Routine visible-emission observations do not replace a required performance test. If the agency requires a later stack test, the permittee shall submit a protocol at least 30 days before testing and shall report each valid test run and the three-run average.

## Condition 3.4 Emergency generator EG-1 routine testing

EG-1 may be operated for routine readiness testing only Monday through Friday between 8:00 AM and 5:00 PM. Routine testing shall not exceed 50 hours per calendar year. Routine testing shall not be scheduled on ozone action days announced by the agency.

The permittee shall keep the date, start time, stop time, reason for operation, and total run time for each EG-1 operation. Emergency use and routine readiness testing shall be recorded separately. The annual routine testing total shall be calculated from the operating log.

The permittee shall maintain fuel purchase records showing use of ultra-low sulfur diesel or another fuel approved in writing by the agency.

## Condition 4.1 Wet scrubber WS-2 operation

The wet scrubber shall be operated whenever coating line CL-1 is operating. Operators shall record scrubber liquid flow and pH once per operating shift. The permittee shall maintain the scrubber in accordance with the manufacturer maintenance instructions and the site maintenance plan.

The current draft operating range for liquid flow is 118 to 136 gallons per minute. The current draft operating range for recirculation pH is 6.5 to 8.2 standard units. Excursions from either operating range shall be recorded in the shift log with the operator initials, corrective action taken, and the time the parameter returned to range.

Maintenance activities that remove WS-2 from service shall be entered in the maintenance log with the date, work order number, work performed, and the time CL-1 returned to normal operation.

## Condition 6.1 Baghouse opacity and bag leak detector response

The draft sentence reads: Report all opacity excursions and all bag leak detector system alarms to the agency with the quarterly deviation report. Corrective action for bag leak detector system alarms must be documented within 30 minutes.

The bag leak detector system shall be operated during dry sanding and finishing booth operation. The permittee shall keep alarm date, alarm start time, alarm clear time, corrective action, and operator initials. Alarm records shall be retained with the quarterly deviation report support file.

The visible-emission observation method referenced elsewhere in the draft permit is six-minute average opacity. The draft visible-emission standard for S-01 is 20 percent opacity, except for startup and shutdown allowances that are not part of these excerpts.

## Condition 8.2 Permit scope and local operating issues

This draft permit establishes stationary-source emission limits, monitoring, testing, recordkeeping, and reporting requirements for the emission units listed in the source inventory. It does not establish public road routing rules, off-site traffic controls, school walk-route controls, or local loading dock operating rules.

The permittee remains responsible for any separate state or local requirements that apply outside this air permit. The hearing officer may note comments about traffic, access, or site operations in the response-to-comments record and may route them to the relevant local process when the air permit record does not provide an enforceable stationary-source condition.

## Condition 9.3 Record retention

The permittee shall keep records required by this permit for at least five years. Records shall be made available to the agency upon request. Electronic logs may be used if they preserve the original entry date, the name or initials of the person making the entry, and any later correction.

## Condition 10.1 Deviation reporting

The permittee shall submit a quarterly deviation report when a permit limit, operating parameter, monitoring requirement, testing requirement, recordkeeping requirement, or reporting requirement is not met. The report shall identify the condition, date, duration, cause if known, corrective action, and whether the deviation was resolved during the reporting quarter.
