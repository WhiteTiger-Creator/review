# Draft permit terms for comment response packet

## Condition 2.1 Particulate matter from Baghouse stack S-01
The facility shall not emit particulate matter from Baghouse stack S-01 at a rate greater than 0.015 gr/dscf. Compliance is demonstrated by the July 2026 three-run stack test average unless the agency requires a later test.

## Condition 3.4 Emergency generator EG-1 routine testing
Routine readiness testing for EG-1 may occur only Monday through Friday between 8:00 AM and 5:00 PM. Routine testing shall not exceed 50 hours per calendar year and shall not be scheduled on ozone action days announced by the agency.

## Condition 4.1 Wet scrubber WS-2 operation
The wet scrubber shall be operated whenever the coating line is operating. Operators shall record pH and liquid flow once per shift. The draft does not yet specify a post-maintenance restart check.

## Condition 6.1 Baghouse opacity and bag leak detector response
The draft sentence reads: Report all opacity excursions and all bag leak detector system alarms to the agency with the quarterly deviation report. Corrective action for BLDS alarms must be documented within 30 minutes.

## Condition 8.2 Non-air-permit topics
The draft permit does not regulate public road truck routes or off-permit loading dock idling. The hearing officer may route those concerns to local planning or site operations, but the air permit record does not contain an enforceable condition for those topics.
