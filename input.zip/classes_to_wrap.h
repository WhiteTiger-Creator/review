#ifndef CLASSES_TO_WRAP_H
#define CLASSES_TO_WRAP_H

class wrapped_class {
private:
	int m_value;
public:
	wrapped_class();
	wrapped_class( const int value );
	
	void set_value( const int value );
	int  get_value( ) const;
};

#endif