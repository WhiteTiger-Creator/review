# Reservation baseline and the placement ledger

Sable Ridge Systems, Platform Operations
runbook RB-0114 · owner: fleet-capacity@sableridge · last reviewed 2026-05-19 (M. Okafor)

Standing notes for how the admission controller (`fleetd`) tracks reserved
capacity and how to read the placement ledger it exports. This is background for
on-call; it is not the incident procedure.

## Reserved capacity

Every node carries one number, `reserved_mib`, the memory `fleetd` holds back on
that node for the workload instances resident on it. It is the sum of the `mib`
of those instances, nothing else. The scheduler will not admit a new instance to
a node unless the node's free memory still covers its own reservation after the
placement.

The baseline is exported per node as `node, region, reserved_mib`. Capacity
planning reads it straight, so a node that reads high is treated as full when it
is not, and the memory behind the overstatement sits idle.

## Ports and workloads

Each workload owns a reserved port block. The primary instance listens on the
block's base port and takes the same base port on every node it runs on, so a
port maps to one workload for as long as the fleet has run it. A workload that
runs two instances on one node puts the second on the next port up in its own
block. Blocks do not overlap and a port is never shared between workloads.

`fleetd` holds one instance per node and port at a time. To move a port to a
different workload it drains the instance on it first, then admits the new one.

## The placement ledger

`fleetd` appends a row to the ledger for every instance it places:

    placement_id, workload, node, port, mib, started_at, ended_at

`started_at` is when the placement was committed. `ended_at` is when the
instance was drained; an empty `ended_at` means no stop was recorded for it. The
first line of the export is a comment carrying the time the ledger was pulled.

Placement is break-before-make. When `fleetd` replaces the instance on a port it
writes the incoming row at the moment it commits the decision, and only then
drains the instance currently holding the port. In steady state the drain and
the new start land within seconds of each other, so a succession on a port reads
as one row closing and the next opening a breath later.

## Reading what is resident

Residency at a given instant is read from the ledger: the instances resident on
a node are the ones with a placement open at that instant. For the current
picture that is the rows with no `ended_at`, taken as of the export time in the
header. Totals per node reconcile against the baseline on any node `fleetd`
finished writing.
