# Leak reports, May 2 and May 3, 2027
## Compiled by the Olathe facility manager from shift reports and the maintenance line

Recorded as they came in, not tidied up afterwards.

May 2, 6:40 pm. First call. Water coming through over aisle 14, which is under
zone B near the middle of the building. Described as a steady drip, then heavier
within the hour. Two pallets of packaged goods wrapped and moved.

May 2, 7:15 pm. Second location in zone B, over aisle 17, about ninety feet from
the first. Same character. Racking covered with sheeting.

May 2, 9:30 pm. Zone C, over the returns staging area. This one came in fast and
the night supervisor described it as running rather than dripping. Cardboard on
the floor ruined, roughly forty cartons.

May 2, 11:50 pm. Zone E, over the northeast dock line. Light, intermittent.
Nothing under it at the time.

May 3, 2:20 am. Zone B again, third location, over aisle 11. By this point the
night crew reported standing water visible on the roof from the mezzanine window
across most of the north half.

May 3, 6:05 am. Zone F, over the battery charging bay. Light. Stopped by mid
morning.

May 3, 8:40 am. Zone C, second location, over the returns office. Ceiling tile
collapse, no injuries, area closed off.

May 3, 1:10 pm. Zone E, second location, near the northeast corner column line.
Light and intermittent again.

Nothing was reported in zone A or zone D at any point, and the crew was looking.
The facility manager walked the roof late on May 3 and reported water still
standing in B and C, ankle deep near the parapet in B, and mostly gone in E and
F by then.

Total recorded damage claim as filed: $214,600, of which $186,000 is inventory
under zones B and C.
