# Workbook calculation notes

This note records the arithmetic expected in the promotion workbook. It is
written for the reviewer building the file and for the second person checking
cell references.

## Join first

Use run_id to bring run_status from run_status_log.csv onto both measurement
tables. Do not infer validity from whether a metric cell is populated. The three
invalid jobs all wrote at least one measurement before stopping.

If the workbook carries copied raw sheets, add a status column with XLOOKUP (or
an INDEX/MATCH equivalent) against the RunStatus sheet. AVERAGEIFS can then
restrict each method/workload mean to status equal to complete. Keep the copied
status and metric rows visible rather than deleting failures.

## Per-workload throughput

For workload i:

static_mean_i = arithmetic mean of complete static throughput rows

adaptive_mean_i = arithmetic mean of complete adaptive throughput rows

lift_i = adaptive_mean_i / static_mean_i - 1

This is a ratio of means. It is not the mean of seed-level ratios. The methods
were not run as paired trials, despite sharing seed labels. Display four decimal
places for lift, but retain full cell precision for the weighted sum.

## Composite

Read the weight from workload_mix_weights.csv only where
include_in_composite=yes. Inactive historical rows have zero weight and should
remain outside the scored A-D table. Weighted lift is weight multiplied by the
workload lift. The composite is the sum of the four weighted lifts; active
weights already sum to one, so there is no further normalization for the
general promotion calculation.

If the limited-promotion path is ever evaluated, remove the excluded workload,
then divide each remaining weight by the remaining weight sum before multiplying
by lift. Do not use that alternate composite when the board override requires a
HOLD.

## Tail latency

Compute complete-run static and adaptive p99 means independently, then:

p99_delta_i = adaptive_p99_mean_i / static_p99_mean_i - 1

The p99 gate passes when delta is less than or equal to 0.05. Use the underlying
formula result in the IF test, not a rounded display value. Every active
workload in this packet is subject to the gate because all weights are at least
0.15.

## Counts and exclusions

Show complete-run counts for each method and workload. Because the invalid jobs
are not symmetric, counts will differ in B, C, and D. That is expected and is
one reason a formula-driven workbook is useful. ExcludedRuns should list run_id,
workload, method, seed, and status note from the status log.

## Suggested references

One workable layout is RawThroughput, RawP99, RunStatus, MixData,
PerWorkload, MixScore, Decision, ExcludedRuns, and Notes. The presentation
sheets may use other names, but calculations should remain inspectable. Means
can use AVERAGEIFS over the copied data; complete counts can use COUNTIFS; the
Decision composite should reference MixScore rather than repeat a typed number.

The final label itself may be typed after reviewing the formulas. The
analytical values leading to that label should not be hard-coded. At minimum,
method means, lifts, p99 deltas, weighted contributions, and composite must be
formulas.

## Sanity checks

Weights for A through D should total 1.00. No other workload should have a
positive scored weight. The status lookup should return no missing run IDs.
The three incomplete records should appear in the exclusion list. Workload C is
the one the board asked reviewers to examine closely; do not assume that means
it fails, but make sure its tail result is generated from complete runs.

The ablation table uses a different harness tag and answers a parameter question.
It should not be appended to the default-configuration seed data. Hardware and
bench-hour files likewise document the campaign without becoming terms in the
score.
