# STL-ECM-26-041 chiller-plant measurement and verification basis

## Decision and observation boundary

This basis governs the technical savings review for the chilled-water plant retrofit at the municipal civic center on Noland Avenue in St. Louis, Missouri. The review supports the owner's decision on whether the measured post-retrofit period clears the performance contract's chiller-electric savings guarantee. It is not an authorization to pay an invoice, an equipment safety waiver, an annual utility budget, or approval to change operating limits. The owner retains commercial approval after the engineering record is complete.

Use the June 1 through September 30, 2025 baseline and the same dates in 2026 for the post-retrofit observation period. The electric meter records chiller-plant kilowatt-hours. The chilled-water meter records delivered cooling ton-hours. The weather record uses daily mean dry-bulb temperature and base-65 Fahrenheit cooling degree days from the issued station export. Treat Central Time as the record time zone and U.S. dollars as the cost basis.

## Record precedence and daily population

The date is the analytical key. Preserve every issued source row. A superseded plant or weather row is history and cannot contribute to a fit, total, chart, savings value, or acceptance gate. Ordinarily, one CURRENT plant row and one CURRENT FINAL station row control each date. If the weather export has more than one CURRENT FINAL candidate, do not choose by row order or average them. Resolve that date only when one VERIFIED weather-reissue entry in the operating log names the controlling `weather_id`; otherwise place the review on hold and identify the unresolved date.

A baseline or post-retrofit day is eligible when its controlling plant row has VERIFIED meter quality, its controlling weather row is resolved, electricity and ton-hours are positive, and no decision-bearing operating condition exceeds the daily limits below. A routine alarm, ordinary occupied-hour variation, holiday schedule, or short closed intervention is not automatically a reason to remove a day. Weekends and holidays remain unless their evidence independently meets an exclusion rule.

The `event_type` field is the shop or commissioning team's label, not a final M&V classification. Read the narrative effect, timestamps, evidence status, and work reference together. Treat loss or active isolation/calibration of the plant-electric or chilled-water measurement chain as a measurement interruption; it becomes disqualifying only when the actual overlap on a calendar day exceeds six hours. Treat a deliberate bypass, forced command or set point, or functional/startup sequence that displaces normal automatic operation as a control intervention; it becomes disqualifying only when its overlap on a calendar day exceeds four hours. The boundary is strict: an overlap equal to the limit remains eligible. Observation without forced points, ordinary alarms, and scheduling notes have no decision-bearing effect unless the narrative supports one of those functional classes.

Use Central Time timestamps to allocate a multi-day event to the hours that actually overlap each calendar day. Do not repeat the event's full logged duration on every affected date. When several disqualifying entries overlap one date, exclude the date once and retain the separately traceable hours and references.

## Baseline model

Calculate each eligible baseline day's specific chiller energy as plant kilowatt-hours divided by delivered cooling ton-hours. Fit ordinary least squares with specific chiller energy as y and base-65 cooling degree days as x. Use every eligible baseline day once. Carry the available calculation precision through the daily ratios, fitted values, residuals, post-period predictions, and aggregates; use number formats, not rounded intermediate operands, for the reader-facing precision. Report the slope, intercept, R-squared, coefficient of variation of root mean square error, and normalized mean bias error.

Use the usual residual standard error for a two-parameter line. Report CV(RMSE) relative to the arithmetic mean of eligible baseline specific energy and NMBE from the signed residual sum, the residual degrees of freedom, and that same mean. Residual means actual specific energy less fitted specific energy. Carry its sign; only the NMBE gate uses an absolute value.

The baseline model is usable only when at least 90 eligible baseline days remain, R-squared is at least 0.70, CV(RMSE) is no more than 15.0 percent, and absolute NMBE is no more than 5.0 percent. A failed model gate places the review on hold. Do not replace the specified model with a monthly ratio, an unadjusted year-over-year comparison, or a regression on the excluded records merely to improve fit.

## Post-period adjustment and savings

For each eligible post-retrofit day, apply the fitted baseline slope and intercept to that day's CURRENT FINAL cooling degree days. Multiply the predicted baseline specific energy by that day's delivered ton-hours to obtain adjusted baseline electricity. Daily savings equal adjusted baseline electricity minus actual post-retrofit electricity. Aggregate from the daily values; do not average the daily percentages.

Adjusted savings percent is total eligible savings divided by total eligible adjusted baseline electricity. Observation coverage is eligible post-retrofit days divided by the 122 calendar days in the issued June-through-September period. At least 90 eligible post days and 95.0 percent observation coverage are required.

Construct the lower edge of a central 80 percent normal interval. Derive the corresponding standard-normal quantile, round that contract operand to three decimals, and show the derivation in the workbook rather than treating the allowance as typed. Carry full precision through the remaining propagation. Assume the baseline residual error is independent and homoscedastic; scale it by each eligible post day's ton-hours, combine those daily absolute-error contributions in quadrature, and normalize by total eligible adjusted-baseline electricity. Subtract that allowance from adjusted savings percent. This is a contract screen, not a general confidence interval for annual facility savings.

The technical guarantee is cleared only when the baseline model gates pass, post observation count and coverage pass, adjusted savings are at least 20.0 percent, and the lower edge of the interval is also at least 20.0 percent. State the disposition in ordinary engineering language. If a gate fails, name the first evidence or calculation needing resolution. If all gates pass, state the supported technical conclusion while making clear that owner commercial approval is still unrecorded.

## Cost and closeout communication

Apply the issued avoided-energy rate of $0.1127 per kilowatt-hour only to eligible post-period savings. Show the rate and the resulting avoided cost separately from the engineering acceptance result. Do not claim annual savings, total building savings, demand savings, maintenance savings, or a payment amount from this record.

The decision view must show the complete gate set, the controlling margin above the 20.0 percent lower-bound requirement, the excluded dates with source event references, and the evidence still needed for commercial closeout. Preserve a daily baseline fit and post-period audit, the raw source rows, the model method, and a five-file source crosswalk. Use ordinary energy-engineering language in reader-facing decisions rather than unexplained code strings.

Before the owner relies on the result, archive the signed meter calibration certificates associated with the closed meter and flow-sensor events and retain the post-period raw exports. Extend monitoring through at least one shoulder-season month before using the summer result for a forward annual utility budget. Never bypass chiller safeties, low-flow protection, condenser limits, alarms, or manufacturer operating limits to increase measured savings.
