# STL-ECM-26-041 chiller-plant measurement and verification basis

## Decision and observation boundary

This basis governs the technical savings review for the chilled-water plant retrofit at the municipal civic center on Noland Avenue in St. Louis, Missouri. The review supports the owner's decision on whether the measured post-retrofit period clears the performance contract's chiller-electric savings guarantee. It is not an authorization to pay an invoice, an equipment safety waiver, an annual utility budget, or approval to change operating limits. The owner retains commercial approval after the engineering record is complete.

Use the June 1 through September 30, 2025 baseline and the same dates in 2026 for the post-retrofit observation period. The electric meter records chiller-plant kilowatt-hours. The chilled-water meter records delivered cooling ton-hours. The weather record uses daily mean dry-bulb temperature and base-65 Fahrenheit cooling degree days from the issued station export. Treat Central Time as the record time zone and U.S. dollars as the cost basis.

## Record precedence and daily population

The date is the analytical key. Preserve all source rows, but use only the row marked CURRENT when an export contains both CURRENT and VOID records for the same date. A VOID row is retained history and never contributes to a fit, total, chart, savings value, or acceptance gate. For weather, use the CURRENT row marked FINAL. A provisional or sensor-check row that was replaced is not averaged with its replacement.

A baseline day is eligible when it has one CURRENT plant record, VERIFIED meter quality, one CURRENT FINAL weather row, positive chiller electricity and ton-hours, and no disqualifying operating event. A post-retrofit day uses the same tests. A routine alarm, holiday schedule, ordinary occupied-hour variation, or a closed adjustment lasting no more than the limits below remains in the population.

Exclude a day when the operating log shows any of the following: more than six hours of CHILLER_METER_OUTAGE, more than six hours of CHW_FLOW_SENSOR_CAL, more than four hours of MANUAL_BYPASS, or more than four hours of PLANT_STARTUP_TEST. Apply an event to every calendar day from its start date through end date. If more than one disqualifying event applies, retain one excluded day and show the combined event hours. Do not exclude a day solely because it is a weekend or holiday.

## Baseline model

Calculate each eligible baseline day's specific chiller energy as plant kilowatt-hours divided by delivered cooling ton-hours. Fit ordinary least squares with specific chiller energy as y and base-65 cooling degree days as x. Use every eligible baseline day once. Carry the available calculation precision through the daily ratios, fitted values, residuals, post-period predictions, and aggregates; use number formats, not rounded intermediate operands, for the reader-facing precision. Report the slope, intercept, R-squared, coefficient of variation of root mean square error, and normalized mean bias error.

Use STEYX as the residual standard error. CV(RMSE) is STEYX divided by the arithmetic mean of eligible baseline specific energy. NMBE is the sum of eligible residuals divided by the baseline degrees of freedom, n minus two, and then divided by that same mean. Residual equals actual specific energy minus fitted specific energy. Keep the signs; the absolute-value gate applies only to the NMBE acceptance test.

The baseline model is usable only when at least 90 eligible baseline days remain, R-squared is at least 0.70, CV(RMSE) is no more than 15.0 percent, and absolute NMBE is no more than 5.0 percent. A failed model gate places the review on hold. Do not replace the specified model with a monthly ratio, an unadjusted year-over-year comparison, or a regression on the excluded records merely to improve fit.

## Post-period adjustment and savings

For each eligible post-retrofit day, apply the fitted baseline slope and intercept to that day's CURRENT FINAL cooling degree days. Multiply the predicted baseline specific energy by that day's delivered ton-hours to obtain adjusted baseline electricity. Daily savings equal adjusted baseline electricity minus actual post-retrofit electricity. Aggregate from the daily values; do not average the daily percentages.

Adjusted savings percent is total eligible savings divided by total eligible adjusted baseline electricity. Observation coverage is eligible post-retrofit days divided by the 122 calendar days in the issued June-through-September period. At least 90 eligible post days and 95.0 percent observation coverage are required.

Quantify the one-sided 80 percent uncertainty allowance as 1.282 times the baseline residual standard error times the square root of the sum of squared eligible post-period ton-hours, divided by total eligible adjusted baseline electricity. The lower-bound savings percent is adjusted savings percent minus that allowance. This is a contract screen, not a general confidence interval for annual facility savings.

The technical guarantee is cleared only when the baseline model gates pass, post observation count and coverage pass, adjusted savings are at least 20.0 percent, and the one-sided lower bound is also at least 20.0 percent. If any gate fails, use HOLD FOR CORRECTION and name the first evidence or calculation that needs resolution. If every gate passes, use TECHNICAL ACCEPTANCE SUPPORTED and state that owner commercial approval is still unrecorded.

## Cost and closeout communication

Apply the issued avoided-energy rate of $0.1127 per kilowatt-hour only to eligible post-period savings. Show the rate and the resulting avoided cost separately from the engineering acceptance result. Do not claim annual savings, total building savings, demand savings, maintenance savings, or a payment amount from this record.

The decision view must show the complete gate set, the controlling margin above the 20.0 percent lower-bound requirement, the excluded dates with source event references, and the evidence still needed for commercial closeout. Preserve a daily baseline fit and post-period audit, the raw source rows, the model method, and a five-file source crosswalk. Use ordinary energy-engineering language in reader-facing decisions rather than unexplained code strings.

Before the owner relies on the result, archive the signed meter calibration certificates associated with the closed meter and flow-sensor events and retain the post-period raw exports. Extend monitoring through at least one shoulder-season month before using the summer result for a forward annual utility budget. Never bypass chiller safeties, low-flow protection, condenser limits, alarms, or manufacturer operating limits to increase measured savings.
