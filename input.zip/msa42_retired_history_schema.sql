-- MSA-42 retired source history structures
-- Extracted definitions only. The source platform was retired 2026-06-30.

CREATE TABLE retired_contract_header (
    contract_key            varchar(24) NOT NULL,
    account_no              varchar(18) NOT NULL,
    location_no             varchar(18) NOT NULL,
    start_dt                date NOT NULL,
    end_dt                  date,
    status_cd               char(1) NOT NULL,
    modified_ts             timestamp NOT NULL,
    PRIMARY KEY (contract_key)
);

CREATE TABLE retired_contract_term (
    contract_key            varchar(24) NOT NULL,
    term_seq                integer NOT NULL,
    plan_cd                 varchar(12) NOT NULL,
    priority_mins           integer NOT NULL,
    coverage_cd             varchar(12) NOT NULL,
    effective_dt            date NOT NULL,
    entered_ts              timestamp NOT NULL,
    superseded_term_seq     integer,
    term_status             varchar(10) NOT NULL,
    PRIMARY KEY (contract_key, term_seq)
);

CREATE TABLE retired_amendment_inbox (
    inbox_seq               bigint NOT NULL,
    contract_key            varchar(24) NOT NULL,
    amendment_no            varchar(20) NOT NULL,
    revision_no             integer NOT NULL,
    executed_ts             timestamp,
    effective_dt            date,
    received_ts             timestamp NOT NULL,
    status_cd               varchar(12) NOT NULL,
    plan_cd                 varchar(12),
    source_document_ref     varchar(60),
    PRIMARY KEY (inbox_seq),
    UNIQUE (contract_key, amendment_no, revision_no)
);

CREATE TABLE retired_ticket_contract_audit (
    ticket_no               varchar(24) NOT NULL,
    contract_key            varchar(24) NOT NULL,
    location_no             varchar(18) NOT NULL,
    opened_ts               timestamp NOT NULL,
    plan_cd_at_link         varchar(12),
    linked_ts               timestamp NOT NULL,
    linked_by               varchar(18) NOT NULL,
    PRIMARY KEY (ticket_no, linked_ts)
);

CREATE INDEX retired_term_effective_idx
    ON retired_contract_term (contract_key, effective_dt, entered_ts);

CREATE INDEX retired_amendment_arrival_idx
    ON retired_amendment_inbox (contract_key, received_ts, revision_no);

-- Source behavior notes retained with the DDL export:
-- 1. received_ts is the first timestamp at which support could see an amendment.
-- 2. effective_dt is contract time and can precede received_ts.
-- 3. replacement revisions share amendment_no and increment revision_no.
-- 4. the retired term table retained rows, but the consolidated target kept only
--    one current row per agreement.
