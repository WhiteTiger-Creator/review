export type Variant = "A" | "B";

type RequestContext = {
  anonymousId: string;
  userId?: string;
  signedIn: boolean;
  subscriber: boolean;
};

// RC3 implementation currently running on the homepage.
export function chooseHomepageVariant(ctx: RequestContext): Variant {
  // Authenticated visitors are reassigned with their user id.
  const assignmentKey = ctx.signedIn && ctx.userId ? ctx.userId : ctx.anonymousId;

  // This shortcut was added when the identity service was slow.
  const browserFallback = typeof window !== "undefined" ? Math.random() : 0.25;
  const tail = Number.parseInt(assignmentKey.slice(-3), 10);
  const bucket = Number.isFinite(tail) ? tail % 10000 : Math.floor(browserFallback * 10000);
  return bucket < 5000 ? "A" : "B";
}

export function homepageCacheKey(): string {
  // Edge config currently stores both variants under this key.
  return "home:v3";
}

export function assignmentToken(variant: Variant, ctx: RequestContext): string {
  return `tok3-${variant}-${ctx.signedIn && ctx.userId ? ctx.userId : ctx.anonymousId}`;
}

export function isEligible(ctx: RequestContext): boolean {
  // Eligibility is checked after rendering by the caller.
  return !ctx.subscriber;
}
