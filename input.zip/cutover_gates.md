# Greenfield Community College — Banner 9 + Azure AD SSO cutover gates
Version locked: 2026-07-18
Owner: College Information Systems (cutover working group)
Status: baseline change-control (see later amendments)

Purpose
-------
Decide whether the Labor Day weekend 2026 hard cutover from Banner 8 / legacy
CAS to Banner 9 with Azure AD SSO may proceed for production traffic. This is
an operational go/no-go for the CIO steering packet, not a vendor scorecard.

In-scope modules
----------------
Score only these four Banner functional areas (module_code):
- STU  Student / registration / records
- FIN  Finance / A/R / cashiering
- FAID Financial aid packaging / disbursement
- HR   HR / payroll / leave

Standby or shadow modules listed in module_catalog.csv are out of scope for
this gate.

Filters on integration_test_runs.csv (apply before module scores)
-----------------------------------------------------------------
1) build_tag must equal rc-24.2 (the freeze candidate). Older rc-24.1 and
   scratch hotfix tags stay in the export for lineage but do not score.
2) test_phase must equal regression. dry_run, smoke, and vendor_demo rows are
   rehearsal traffic and do not enter gate math.
3) operator_role must equal college_qa. vendor_se rows are assisted demos.
4) Drop any case_id with disposition=exclude in exclusion_cases.csv.

Do not weight rows by severity_weight. Research notebooks use that column
offline; the cutover board does not.

Module PASS (checked in order)
------------------------------
For retained rows in a module:
- retained test count >= 25
- pass_rate (passed / retained) >= 0.920
- mean duration_sec <= 45.0

First failed rule is the one that fails earliest in the list above.

IdP / SSO latency gate
----------------------
From idp_latency_log.csv keep probe_type=auth_code and env=prod_pilot.
Drop timeout_flag=Y. Compute nearest-rank p95 of latency_ms:
index = ceil(0.95 * n) - 1 on the ascending sorted list.
IdP CLEARS when p95 <= 800.0 ms.

Training floor (July 18 baseline)
---------------------------------
From training_roster.csv, overall completion_rate across all required seats
must be >= 0.85. Completion_rate = completed / required for the population
you are measuring.

Overall cutover status (July 18 baseline)
-----------------------------------------
Overall GO when at least three of four in-scope modules PASS AND IdP CLEARS
AND overall training floor clears. Otherwise NO-GO.

Required board contents
-----------------------
Chosen status (GO / NO-GO); blocking reason if NO-GO; per-module retained
counts, pass_rate, mean duration, status, first failed rule; IdP n and p95;
training figures used for the controlling floor; filter drop reconciliation;
methods / source-control note stating which packet document controlled when
clauses disagreed; live-formula workpaper tabs that recompute module metrics
from retained case_id lists.

Conflict handling
-----------------
Other packet notes may describe hallway practice, vendor preference, or later
freeze amendments. When clauses conflict, reconcile using document date,
document status (baseline vs freeze amendment vs historical), and explicit
change-control language. Untouched clauses in this file still apply unless a
controlling amendment expressly replaces them.

Operating context
-----------------
The shared QA export mixes college regression with vendor-assisted demos
because Ellucian SE laptops write into the same results share. Cutover math
has to separate those. Severity weights exist for risk heatmaps, not for the
pass_rate denominator. Timeout rows on the IdP log are infra blips during the
Azure AD conditional-access pilot and are excluded rather than imputed.
