# Ashmont gradual typing FP taxonomy

## False positive definition
Join `typed_diagnostics.csv` to `gold_labels.csv` on `file_id`.

A row is a **false positive (FP)** when:
- `tool_label` = `error`, and
- `gold_label` = `clean`.

A row is a **true negative (TN)** when:
- `tool_label` = `clean`, and
- `gold_label` = `clean`.

Exclude any `file_id` listed in `exclusion_files.csv` before computing rates.

## FP rate
Overall and per category: `FP / (FP + TN)` on retained gold=`clean` rows only.
Report the overall rate to **three decimal places** (final rounding only).

## Category naming
Join `category_id` to human-readable `category_name` and `guideline_fix_id` using `category_map.csv`.
Only `status=active` categories are eligible for ranking. Retired rows are historical.

## Guideline fixes (recommend top 2 by FP count)
| Fix ID | Category | Guidance |
|--------|----------|----------|
| FIX-A | optional_none | Narrow Optional[] unions before strict none checks |
| FIX-B | narrow_union | Split union branches before assignability test |
| FIX-C | protocol_stub | Defer protocol conformance until stub complete |
| FIX-D | generic_alias | Expand TypeVar aliases in generic functions |
| FIX-E | overload_match | Match overload order to runtime dispatch |

If two categories share the same FP count, keep both fix IDs in the top-two list and break the "highest category" name tie by lower `category_id` (e.g., CAT-02 before CAT-03).
