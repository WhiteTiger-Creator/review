# Voss Community Health Plan - 837P Companion Guide, version CG-4.2
# Effective 2026-01-01. Narrows the national implementation guide for claims submitted to payer
# PAY-VOSS. Where this guide and the national guide disagree, this guide governs for Voss traffic
# only; it does not narrow or widen requirements for any other payer.

## Line item control number (REF*6R)

Required on every service line for every claim submitted to Voss, regardless of claim type. This is
stricter than the national default, which treats the element as situational absent a payer request.
Voss is making that request through this guide.

## Paperwork segment (PWK)

Voss does not accept unsolicited paperwork segments under any circumstance. A claim carrying a PWK
segment is rejected at intake regardless of whether supplemental records exist. Do not send PWK on any
claim routed to Voss.

## Billing provider tax identification (REF*EI)

Where Voss has contracted a provider-specific tax identification number that differs from the
provider's default, the contracted number governs for claims submitted to Voss and must be used in
place of the provider's default REF*EI. This applies only to the specific provider-payer pairing on
file; it has no effect on that provider's claims to any other payer, and it has no effect on other
providers' claims to Voss.

## Diagnosis coding and referral numbering

Voss follows the national implementation guide sections 3.4 and 3.5 without further narrowing. This
guide does not restate the ABK qualifier requirement or the referral number format; both apply to Voss
traffic because they apply nationally.
