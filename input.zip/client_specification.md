# Manufacturing Wage and Benefits Survey 2026 — what the Alliance needs

Upper Midwest Manufacturers Alliance (UMMA)
Prepared for Northlake Research Group
Contact: R. Vandermeer, Director of Member Research

## 1. Background

UMMA has published the Manufacturing Wage and Benefits Survey every year since
2011. Members use it to set pay bands, and our board uses the alliance-wide
figure when it testifies on workforce policy. The 2025 wave was fielded by our
own staff and the board has asked us to bring in a firm this year, partly for
capacity and partly because we were challenged last year on whether the
published figure was precise enough to support the claims we made with it.

## 2. What we need estimated

The headline estimate is the mean hourly production wage across the alliance
membership. We also publish the same figure for each employee-size band, which
is how members actually use the report: a twelve-person shop does not benchmark
against a thousand-person plant.

## 3. Membership and stratification

Stratify the sample by employee-size band, using the four bands in the frame
file. Do not stratify by state. We report by size band and alliance-wide, and we
have never reported a state-level figure, so state is carried in the frame for
contact management only.

## 4. Precision

Two requirements, and the board set both after last year's challenge.

The alliance-wide mean hourly wage must carry a margin of error no wider than
plus or minus 45 cents at 95 per cent confidence. This is the number we were
challenged on and the board has fixed it as a requirement rather than an
aspiration.

Any size band we publish on its own must carry a margin of error no wider than
plus or minus one dollar forty-five cents at 95 per cent confidence. A band we
do not publish on its own is not caught by this, since the combined figure is
what carries the precision in that case.

If the funded sample cannot reach either requirement, we need to know that
before the field period opens rather than after the report is drafted, and we
need to know what it would take to reach it.

## 5. Budget

The board has funded 600 completed responses. That is a hard ceiling on
completes, not a target to be exceeded. Invitation volume is not separately
capped, because the invitation itself costs us very little, but we cannot field
to an establishment that is not in the membership.

## 6. Publication rule for size bands

A size band is published on its own only if at least 50 establishments in that
band complete the survey. Below that, our disclosure policy treats the cell as
too thin to stand alone, and the band is reported combined with the adjacent
band, with the combination disclosed in the report. This rule is not
negotiable and it has cost us a band before.

## 7. Field period

The field period opens 12 October 2026 and closes 20 November 2026. Our field
operations manager has written to you separately about how the last two waves
were run and what the 2026 budget funds, because the two waves in the outcomes
file were not fielded the same way for every band. Please take the planning
rates from that note rather than assuming the most recent wave applies
everywhere.

## 8. The frame, and the correction to it

Membership stood at 4,180 establishments across Minnesota, Wisconsin, Iowa and
North Dakota when our membership team verified the frame at the end of July.
Those are the counts in the frame file.

That verification is no longer current. Through August the membership team
worked through the directory against the eligibility rule below and produced a
reconciliation, which is the second data file we have sent. It does two things.
It removes establishments that should not be in the frame at all, and it moves
establishments between bands where a verified employee count turned out to sit
on the other side of a band boundary. Please size the design from the reconciled
counts. We would rather you carried the July figures in the plan as well, so the
board can see what changed, but the design has to be built on the corrected
numbers.

An establishment is in scope if its membership is active at the open of the
field period and it employs production workers at a site in one of the four
states. Lapsed members are out of scope, as are members whose only operation in
the region is a sales or distribution office, and so are records that turned out
to duplicate an establishment already listed.

We have also included a thirty-record extract from the member directory so you
can see the shape of a member record and the condition it is in. Treat it as an
illustration of the fields and the data-quality conditions the reconciliation
deals with, not as a frame and not as a second source of counts.

## 9. What we want from you

The sampling and weighting plan, before anything is fielded. Our board reviews
methodology in advance, and the questions they ask are always the same: how many
we are contacting, why the sample is split the way it is, what the weights are,
and what we can and cannot say from the result. Write it so it answers those.

We do not need the questionnaire, the field procedures, or the analysis plan for
the wave itself. Those are separate deliverables and separate approvals.
