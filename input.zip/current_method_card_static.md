# EdgeKV method card: StaticWindow

Status: shared default for pilot planning
Owner: Solstice KV runtime team
Last operational review: 2026-01-22

StaticWindow is the conservative read-ahead policy shipped in the current EdgeKV
pilot image. It does not try to predict arbitrary access patterns. A reader must
observe a short sequential run before the policy begins issuing low-priority
prefetches, and the requested distance then stays at 32 blocks until that run
breaks.

## Configuration

The card assumes 4 KiB logical blocks, a maximum of 128 KiB outstanding
read-ahead per reader, and the standard low-priority NVMe queue. Sequential
detection requires four monotonic adjacent accesses. Two non-adjacent accesses
reset the detector. Random reads remain demand-only.

These defaults came from the P4610 campaign and were rechecked on P5520 nodes
when the lab image moved to EdgeKV 4.8. StaticWindow does not allocate a
per-shard stride histogram and adds no timer beyond the existing reader timeout.
That simplicity is the main reason it remains the comparison baseline.

## Where it works well

Update-heavy and read-mostly mixes generally tolerate the fixed window. A window
opened for a short run tends to be consumed before the hot region changes. The
policy is also easy to diagnose: the trace records whether sequential detection
was active and how many prefetched blocks were used.

Read-latest traffic is less predictable, but the fixed cap keeps a moving hot
region from pulling too far ahead. For that workload the method is not always
the throughput leader; it is the stable tail reference.

## Known limits

Cold-cache read-only scans are the uncomfortable case. StaticWindow begins
slowly because it waits for sequential evidence, so it can leave throughput on
the table. Raising the window improves some scans but can increase p99 when
foreground misses and speculative reads overlap. Previous attempts to use 64
blocks as the general default were rolled back after that effect appeared during
compaction.

The policy also misses repeated non-unit strides. Column families that jump by
two or four blocks look random to the detector even when the sequence is
perfectly regular. AdaptivePrefetch was started in part to handle those patterns.

## Operational procedure

Operators do not tune the window per tenant in the shared pilot. A special
configuration requires a workload owner, a rollback note, and its own staged
run. The method card is therefore deliberately narrower than what the code can
accept.

When comparing a challenger, use the same block size, cache warm-up, client
thread count, and ten-minute measurement interval. Runs that crash, time out, or
load the wrong window are invalid even if a metric file was written. The
run-status record controls inclusion.

## Replacement rule

A challenger must pass promotion_criteria.md before this card changes. A
throughput improvement alone is not sufficient; the weighted mix and every
applicable p99 check matter. PROMOTE_LIMITED is a separate card state, not a
verbal caveat added after a failed general promotion.

If AdaptivePrefetch is held, this document remains the shared default without an
edit. The notebook branch may continue, and its next campaign can cite the
failed workload from the promotion workbook. If it is promoted later, preserve
this card as the rollback reference and record the exact challenger commit and
harness tag.

## Current environment

The March comparison used sol-kv-11 and sol-kv-12. Both are EPYC 7543 systems
with 256 GiB DRAM and P5520 3.84 TB devices. The broader hardware file includes
inventory entries that are not comparable campaign hosts. No result from those
other machines should be averaged into the method-card decision.
