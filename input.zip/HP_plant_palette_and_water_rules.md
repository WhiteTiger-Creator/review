
# Harbor Point planting recovery basis

Issued by: Brickshore Landscape Architecture, Norfolk studio  
Record date: 2026-08-12  
Applies to: Harbor Point mixed-use warranty tree review, Norfolk, Virginia  
Currency: U.S. dollars  
Measurement basis: feet, cubic feet, caliper inches, and gallons per peak summer week

## Record order and scope

Use all forty-eight issued tree positions in the current inventory. A position remains in the schedule even when the present direction is removal without replanting; deleting the row would hide a live coordination item. The site-constraint register is the controlling source for planter volume, clear width, utility restriction, drainage, salt exposure, design role, and the last coordinated physical limit. The current issued field coordination record is later than both registers and controls when it names a revised condition, overhead limit, hydrozone, or location disposition. The nursery availability file controls only the stock, quoted size, lead time, and unit price shown as current on 2026-08-14. It does not change site compatibility.

Do not treat an observed condition as a planting recommendation. First settle the current record for the location, then make the tree call, then choose a compliant replacement where replacement is required. Leave an unresolved physical conflict as a hold rather than assuming that civil work, irrigation work, or utility relocation will occur.

## Existing-tree recovery calls

RETAIN applies to GOOD trees and to FAIR trees when canopy loss is no more than 25 percent and trunk damage is no more than 20 percent. WATCH applies to FAIR trees with canopy loss from 26 through 45 percent or trunk damage from 21 through 35 percent. WATCH also applies when the current issued field record expressly keeps a tree under warranty observation. The schedule must state the next field evidence needed for a WATCH position.

REPLACE applies to DEAD or POOR trees, any tree with canopy loss greater than 45 percent, any tree with trunk damage greater than 35 percent, or a location the current issued field record directs to replacement. REMOVE - NO REPLANT applies only when the current issued field record says the issued tree position is occupied by a permanent coordinated feature. Do not turn that condition into a replacement allowance elsewhere.

For installation priority, Phase 1 covers DEAD trees, trees with trunk damage of at least 36 percent, and any current field direction describing instability. Phase 2 covers the remaining replacement positions. RETAIN and WATCH positions are not procurement quantities. The owner warranty cap for replacement plant material in this recovery cycle is $49,870.00, before tax and installation labor.

## New-tree site gates

Every proposed species must pass all of the location gates. Available soil volume must equal or exceed the species minimum. The location's mature-spread limit and mature-height limit must equal or exceed the species dimensions. A HIGH salt-exposure location accepts only a HIGH-tolerance species. A MED location accepts MED or HIGH. A LOW location accepts any listed tolerance. Drainage D means well drained, M means mesic, and W means seasonally wet; the location code must appear in the species drainage range.

HZ-P1 and HZ-G1 accept only LOW water-class species. HZ-L2 and HZ-C1 accept LOW or MOD. SMALL_TREE_ONLY limits mature height to 25 feet. NO_LARGE_ROOT limits the species minimum soil-volume requirement to 500 cubic feet. VAULT_CONFLICT is not a species gate; the current issued direction decides whether the position remains plantable. NONE adds no utility restriction. Clear walking width has already been coordinated into the mature-spread limit and is retained as supporting evidence.

When more than one species passes, use the design-role preference order below, then the current nursery lot with the shortest lead. If two current lots for the selected species have the same lead, use the lower unit price. A lower-ranked species may be used only when a higher-ranked species fails a stated site gate or lacks enough unreserved current stock. Do not split one tree across lots. Preserve the reason a higher preference was rejected.

| Design role | Preference order |
| --- | --- |
| CANOPY | QVI, UPA, NSY, TDI, JVI, ILA |
| STREET | UPA, LST, ILA, MAG, JVI |
| ACCENT | ILA, MAG, LST, NSY, JVI |
| SCREEN | JVI, ILA, MAG, LST |

## Approved species data

| Code | Botanical name | Minimum soil volume (cf) | Mature spread (ft) | Mature height (ft) | Salt tolerance | Drainage | Water class | Peak gallons/week | Issued size |
| --- | --- | ---: | ---: | ---: | --- | --- | --- | ---: | --- |
| QVI | Quercus virginiana | 900 | 55 | 50 | HIGH | D/M | LOW | 38.0 | 3.5in cal B&B |
| UPA | Ulmus parvifolia 'Allee' | 650 | 35 | 45 | MED | D/M | MOD | 33.0 | 3.5in cal B&B |
| NSY | Nyssa sylvatica | 700 | 28 | 42 | MED | M/W | LOW | 30.0 | 3in cal B&B |
| TDI | Taxodium distichum | 750 | 26 | 52 | MED | M/W | LOW | 32.0 | 3in cal B&B |
| ILA | Ilex x attenuata 'East Palatka' | 320 | 18 | 24 | HIGH | D/M | LOW | 18.0 | 2.5in cal B&B |
| JVI | Juniperus virginiana 'Burkii' | 380 | 17 | 34 | HIGH | D/M | LOW | 20.0 | 8ft ht B&B |
| MAG | Magnolia virginiana 'Moonglow' | 480 | 20 | 26 | MED | M/W | MOD | 24.0 | 2.5in cal B&B |
| LST | Lagerstroemia indica x fauriei 'Sioux' | 260 | 15 | 20 | MED | D/M | MOD | 22.0 | 2.5in cal B&B |

## Water and procurement controls

Carry the issued species demand for RETAIN and WATCH positions. Use the selected species demand for REPLACE positions. Use zero for REMOVE - NO REPLANT. A REPLACE - HOLD position without a selected species has PENDING proposed demand; its zone and the site total remain HOLD rather than treating the current tree demand as a proposed design value. Sum resolved position values by zone. The peak weekly caps are 428 gallons for Promenade, 340 for Plaza, 300 for Courtyard, and 240 for Garage Edge. Each resolved zone must stay at or below its cap. The site total is the sum of the four zone values only after all zones are resolved.

Procurement quantity is one only for a REPLACE position. Summarize quantity, current unreserved stock, selected lot, unit price, extended plant-material cost, and longest lead by species. Quantity may not exceed current unreserved stock. The schedule must reconcile position quantities to the procurement summary and show remaining stock, the recovery-cycle budget, committed plant-material cost, and unused allowance. Nursery prices exclude tax, freight, installation, staking, soil amendment, and irrigation adjustment; do not invent those costs.

## Closeout evidence

Each row must identify the source records used for its condition, physical limits, and any current field override. A replacement row needs a traceable site-compatibility result, species, size, nursery lot, quantity, unit price, extended cost, peak weekly water demand, and phase. WATCH rows need the next inspection evidence; replacement rows need delivery and installation verification; the vacant vault-conflict position needs civil/owner confirmation that the issued planting location is permanently closed. No line in this record constitutes owner approval or nursery reservation.
