## Draft results paragraph under review

Across the workload suite, PowerBalance reduced energy per completed job by at least 8% relative to FIFO while keeping the p95 turnaround penalty below 3%. The benefit was consistent across power caps and insensitive to run order, suggesting that the policy's gain is not a thermal-history artifact. These results support using PowerBalance as the energy-efficient default scheduler for the evaluated GPU batch workloads.

### Figure caption draft

Figure 6. Paired replay comparison of PowerBalance and FIFO on the A100 test node. Negative values indicate lower energy per completed job under PowerBalance; positive turnaround values indicate slower completion. Each point is a matched replay unit at the same workload trace, power cap, and block.

### Internal note from the last manuscript meeting

The PI asked the team not to promote the scheduler as a default unless the family-level results support the same language as the overall result. If the aggregate claim is real but one workload family clearly misses the stated envelope, the preferred fix is to narrow the sentence rather than hide the family result in an appendix. The wording should distinguish what is true overall from what is true for every family.

The same caution applies to the order language. The node is warmer on second runs by design. We only want to call the energy result insensitive to order if the paired energy effect is similar in the FIFO-first and PowerBalance-first sequences. A small difference is fine; a sign change or a large swing is not.

The power-cap statement is intended as a robustness statement, not as a separate optimization claim. We are not saying one board cap is best. We are saying the direction and rough size of the paired policy effect should remain recognizable at 250 W, 300 W, and 350 W if the paper is going to call the scheduler benefit general across the tested envelope.
