# Persisted cart record, schema v2 (draft 4)

Drafted by A. Steckler for the 4.0.0 SDK. Reviewed by Catalog on 2026-10-19. Not yet built.

The 4.0 checkout resolves a line against a specific variant before it prices anything, so the
persisted record has to carry the variant rather than leaving the bundle to re-derive it from
the SKU string on every read. That re-derivation is where the cart and the order have been
disagreeing on colorways since the spring.

## Shape

Key: `sdk.cart.v2`

    {
      "cartId": "c_8f31a2",
      "schemaVersion": 2,
      "updatedAt": "2026-10-21T14:07:52.114Z",
      "lines": [
        {
          "sku": "SKU-4412-BLU-M",
          "variantId": "BLU-M",
          "quantity": 2,
          "addedAt": "2026-10-21T13:58:01.702Z",
          "variantResolved": true
        },
        {
          "sku": "SKU-9004",
          "variantId": null,
          "quantity": 1,
          "addedAt": "2026-10-21T14:07:52.101Z",
          "variantResolved": false
        }
      ],
      "currency": "USD"
    }

`cartId`, `updatedAt`, `currency` and the per-line `addedAt` carry across from v1 unchanged.
`items` becomes `lines`, and the quantity field is `quantity` on every line.

## variantId

`variantId` is populated only from the suffixed SKU form, by taking the two trailing segments
of `SKU-<base>-<color>-<size>`. Any SKU that does not match that form gets `variantId: null`
and `variantResolved: false`, and 4.0 resolves it against the merchant catalog at checkout
time, where the mapping actually exists. Catalog's review comment was blunt about this: a
guessed variant is worse than an absent one, because an absent one gets resolved and a guessed
one ships.

`schemaVersion` is stamped on the record so a reader can tell the two apart without inferring
from which keys are present. v1 records carry no such field.

## Open questions from the draft review

Steckler flagged three, and only the first has an answer written down.

1. Whether the v2 write is the only write during the transition, or whether v1 keeps being
   written alongside it. Answered by section 5 of `sdk_deprecation_policy.md`.
2. What a 4.0 reader should do when both keys exist and their `updatedAt` values disagree.
   The draft does not say. Steckler's note reads: "two tabs, two builds, the older one saves
   last. Whose cart is it?"
3. Whether the 45-day retention clock is per key or per cart. The draft assumes per key, which
   means the two representations can expire on different days.

## Read path as drafted

4.0 reads `sdk.cart.v2`. If that key is absent it reads `sdk.cart.v1` and converts in memory.
The draft says nothing about the case where both keys are present, which is question 2 above.
Conversion is a pure function of the v1 record: no network call, no catalog lookup, and no
merchant configuration, because it has to run before the first checkout step mounts and
before `resolve` has necessarily returned.

Conversion has to accept both generations of the v1 record. The quantity arrives as `qty` on
records last written by 3.7.0 or later and as `count` on records last written by anything
earlier, and a record that carries neither is malformed rather than empty. The draft's
reference conversion treats a missing quantity as a dropped line, which Fenwick disagreed
with in review on the grounds that a dropped line is invisible to the shopper and a zero is
not.

## Rollout expectations

4.0 is a major version and goes to the `/sdk/v3` channel's successor. Merchants who embed the
loader or the channel move when delivery moves them. Merchants on an exact pin do not move at
all until they change their embed, and that includes the app integration whose document ships
inside a binary.

The build itself is not started. The estimate is four days of implementation and two of test
once the plan is signed, which is why the schedule and not the code is the thing blocking.

## Test fixtures wanted

Steckler's list, unchanged since draft 2. A v1 record from a 3.6.x build, a v1 record from a
3.8.x build, a record whose SKUs are all bare, a record with a mix of suffixed and bare SKUs,
a cart large enough to force a quota rejection on a storefront that is already near the
limit, and a pair of records where the v1 key carries a later `updatedAt` than the v2 key.

## Storage budget

The v2 record is about 18 percent larger than v1 for a typical three-line cart. Holding both
representations during the transition roughly doubles the footprint. Merchant storefronts also
write their own keys into the same origin's storage and we do not control how much. The 3.x
SDK has never handled a quota rejection; it throws out of the save path and the surrounding
checkout step goes with it. Two of the tickets in the integration thread are that failure.
