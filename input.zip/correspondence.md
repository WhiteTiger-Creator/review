# Correspondence received
## Two letters, reproduced as received

### From the design engineer of record, May 22, 2027

We are in receipt of Northline's notice and we do not accept that the drainage
design is implicated.

The roof was designed to the criteria in force at the time of permit and every
drainage zone was sized against the 100 year one hour intensity for Johnson
County. Our calculation package was reviewed and stamped and the permit was
issued without comment on drainage. The building performed for seven and a half
years through storms that we would expect to have exposed an undersized system.

What has changed in that period is who maintains the roof. We understand the
cleaning contract changed hands in 2024 and that the scope was reduced. A drain
that is not cleaned is not a drain, whatever size it is. We would direct your
attention there before you direct it at us.

We have not been given the as built survey and we reserve the right to comment
once we have it.

### From Bergstrom Roofing, May 26, 2027

We installed this roof to the drawings and the drawings were followed.

Drain sumps were built out of tapered insulation in the locations shown and to
the elevations shown. Our sumps were inspected by the architect's field
representative and signed off at the time. We have the sign off sheets and we
will produce them.

If the roof is holding water now, the question is what has happened to the
insulation and the deck since 2019, and whether the drains have been kept clear.
We had no callback on this roof between the warranty inspection and a seam
repair this February, and that seam repair had nothing to do with drainage.

We would add that we did not design the drainage and we did not set the scupper
elevations, which were dimensioned on the architectural sheets. Whoever set
three inches between the drain and the overflow set the amount of water this
roof was always going to hold.
