# KMS Materials Control Standard MC-17

## High-strength electroplated fasteners: fracture response and lot release

**Owner:** Materials and Supplier Quality  
**Approver:** Director, Product Integrity  
**Effective date:** 2025-11-03  
**Revision:** 6  
**Applies to:** Property-class 12.9 carbon-steel fasteners used at palletizer mast joints in Keystone Motion Systems equipment assembled in Pennsylvania.

## 1. Purpose and boundary

MC-17 sets the evidence and release rules used after a delayed fracture, a laboratory fracture, or a processing excursion involving an electroplated high-strength fastener. The controlled population is the manufacturing lot shown on the container label and certificate. A shared plating batch is a linked population for containment because fasteners on different racks may share surface-preparation, plating, transfer, and post-plate bake conditions.

This standard does not authorize a supplier deviation, repair, or field release. Supplier concessions require written approval from Product Integrity after the lot has met the applicable verification path. Production schedule pressure, replacement-part availability, and a supplier's verbal assurance cannot change a technical disposition.

## 2. Evidence order and record handling

Use evidence in this order when records conflict:

1. Controlled laboratory records tied to specimen and lot traceability.
2. Time-stamped process historian or furnace records tied to the plating batch.
3. Material certificates and shipment records tied to the lot.
4. Installation and field notes.
5. Recollections or opinions that are not backed by a controlled record.

Only laboratory rows marked `REPORTABLE` count toward a required sample set. A row marked `RAW_DUPLICATE` repeats an instrument transmission and is excluded. A row marked `VOID` is excluded when a laboratory nonconformance record identifies the interruption and authorizes a named replacement specimen. The replacement row then counts in the set. Do not average a duplicate or voided row into a lot result.

## 3. Required material and mechanical checks

Each lot must remain traceable to a steel heat, fastener manufacturing lot, plating batch, and shipment container. Loss of any link results in `HOLD` until the link is restored.

The controlled room-temperature mechanical limits for the M12-1.75 by 55 mm property-class 12.9 socket-head fastener are:

- ultimate tensile strength: at least 1,220 MPa;
- elongation after fracture: at least 8.0 percent;
- core hardness: 39.0 through 44.0 HRC, inclusive, for every reportable specimen;
- chemistry identity window: carbon 0.34-0.41 percent, manganese 0.60-0.90 percent, phosphorus no more than 0.025 percent, and sulfur no more than 0.025 percent.

A tensile or chemistry pass confirms identity and basic strength. It does not overrule a valid sustained-load fracture, a delayed field fracture with consistent morphology, or a post-plate bake excursion.

## 4. Plating and post-plate bake controls

The total acid activation dwell must not exceed 12 minutes. The elapsed time from the plating `PLATE_OUT` time stamp to the `BAKE_LOAD` time stamp must not exceed 60 minutes.

The relief bake uses production thermocouple readings from the loaded basket. Count bake duration from the first reportable basket reading at or above 190 degrees C through `BAKE_UNLOAD`. The temperature must stay within 190-230 degrees C during that counted interval, and the interval must be at least 4 hours. Furnace air setpoint, supplier certificate duration, and time before the basket reaches 190 degrees C do not count toward the minimum.

A late transfer, an under-temperature reading, or a short counted interval is a process nonconformance. Passing baseline tensile tests cannot clear that nonconformance.

## 5. Sustained-load screen

The hydrogen-assisted-fracture screen consists of six reportable specimens from each fastener lot. Each specimen is loaded at 75 percent of the controlled proof load for 200 hours. The lot passes only when all six specimens complete 200 hours without fracture. One valid fracture is a failed screen. A second screen may support cause confirmation, but it cannot erase a valid first-screen fracture.

When a fixture interruption occurs without specimen fracture, the laboratory may void that row and substitute one named specimen if the nonconformance record gives the interruption time, confirms the specimen remained intact, and links the replacement to the original position. Undocumented substitution results in `HOLD`.

## 6. Fracture-mechanism confidence

Classify hydrogen-assisted delayed fracture as `PROBABLE` when the record contains both of the following:

- a delayed field fracture or valid sustained-load fracture; and
- predominantly intergranular fracture with secondary cracking, together with either a post-plate process nonconformance or a second linked fracture.

Classify it as `POSSIBLE` when only one evidence family supports it or the morphology is mixed. Ductile microvoid coalescence at the tensile specimen's final overload region is not, by itself, evidence of hydrogen-assisted delayed fracture.

Installation torque is a primary cause only when controlled records show torque outside the approved 61-65 N-m shop window and the fracture has torsional shear lips or another torque-consistent origin. A delayed break after an in-window torque reading, without torsional morphology, does not support torque as the primary cause.

## 7. Lot dispositions

Use one of these states:

- `RELEASE`: traceability is complete; chemistry, tensile, elongation, and every hardness result pass; the plating route passes; and the six-specimen sustained-load screen has zero fractures.
- `HOLD`: the evidence is incomplete, invalid, or contains an unresolved isolated nonconformance without a valid fracture. Material remains segregated and cannot be installed.
- `QUARANTINE`: a valid sustained-load fracture exists, or a field delayed fracture has morphology consistent with hydrogen-assisted fracture. Material cannot be installed or released by concession while the fracture response remains open.

When a quarantined lot shares a plating batch with another lot, quarantine the sibling lot when that sibling has either the same post-plate process excursion or a valid sustained-load fracture. Document the basis separately for each lot.

## 8. Containment and return-to-use

For an installed quarantined population, identify affected equipment by serial number, stop operation, and replace the fasteners before returning equipment to service. For loose inventory, physically segregate and reconcile the quantity by lot and container. Do not use a post hoc re-bake of completed fasteners as the sole basis for release because it does not reverse an already observed fracture.

A lot held only for an isolated hardness exceedance may return to the release path after eight new specimens, split across at least two container positions, each measure within 39.0-44.0 HRC. The original high result remains in the record. All other release requirements must already pass.

Supplier corrective action for a probable hydrogen-assisted fracture must address acid exposure, transfer timing, basket-temperature capture, bake duration, and lot segregation. Product Integrity closes the response only after it reviews objective evidence for the corrective actions and one conforming verification batch.

## 9. Required decision record

The signed lot record identifies the evidence cutoff, each lot's disposition, valid and excluded specimen counts, process timing calculations, fracture-mechanism confidence, affected inventory, field containment, and the exact verification needed for any held population. It also separates established facts from remaining questions so production does not treat an open question as permission to use material.

