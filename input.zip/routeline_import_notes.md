# Routeline import notes

What I have confirmed about the target, from the vendor docs, the sales engineer, and two runs against their staging importer. Where this file and the marketing PDF disagree, this file wins; I tested these.

## Matching semantics

Routeline evaluates an ordered rule list, first match decides, evaluation stops there. Same model we run today, which is most of why it won the eval.

- A request is caller identity, HTTP method, path. Header and body conditions exist in their enterprise tier; we did not buy it and the port must not assume it.
- caller matches the named group exactly, or ANY matches everything. Groups are declared to Routeline separately; ours map one to one, I have already loaded them in staging.
- method is a single verb or ANY. No comma lists. Our current config already conforms, but if anyone hand-edits between now and September, importer run number two taught me it rejects GET,POST with a parse error that names the wrong line.
- path is an exact string, or a prefix wildcard written as a trailing /*. The wildcard is segment-aware: /billing/* matches /billing/statement and everything deeper, and does not match /billing-archive/anything. No mid-path wildcards, no regex. Ours conforms.
- Anything no rule matches is denied. Implicit, not configurable, same as the current box. Do not add a catch-all deny at the bottom; their lint flags it as unreachable-adjacent clutter and support will tell you to delete it.

## The importer

This is the part that forces the cleanup rather than politely suggesting it.

- The importer runs a reachability pass before it will accept a config. Any rule that cannot fire, because an earlier rule fully covers its caller, method, and path space, fails the import. Hard fail, whole file, with the covering rule cited. It found the same coverings both times I fed it our current config, and refused the file both times. There is no override flag; I asked.
- Duplicate rule ids fail the import.
- Order is taken from row order in the import sheet. There is no separate priority number. Whatever order the workbook carries is the order that ships.
- Rule ids are free text up to 24 characters. Keeping the TR and MB ids through the port is fine and I want them kept; three years of runbooks reference them.
- The importer does not read our registry and does not care whether a route exists. Dead-route rules import cleanly if they are reachable. Whether they come along is our call, and my call is they do not; the registry is the source of truth on what exists, and the port is the one chance to make the config agree with it.

## What I could not confirm

- Their docs describe a shadow-warning mode that reports partial overlaps, an earlier rule that covers some but not all of a later rule. Staging did not emit any such warnings on our config. Either we have none, which I doubt, or the feature is enterprise-tier too. Treat partial overlaps as out of scope for the port; they behave identically under first match on both boxes, so equivalence does not depend on them.
- Cutover rollback timing. The sales engineer says config swap-back is under a minute. Nobody has shown me.

## For whoever builds the port sheet

Keep every surviving rule in its current relative order. The workbook is the artifact of record for the September change; the gateway team regenerates the yaml from the Proposed_Ruleset tab, so that tab has to carry order, action, caller, method, path, and the origin id, nothing implicit. If a removal needs an argument, the argument goes in the removal row, not in a hallway.
