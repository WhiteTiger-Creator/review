import type { NextFunction, Request, Response } from "express";

const WINDOW_MS = 60_000;
const MAX_REQUESTS = 240;

type Bucket = { windowStart: number; count: number };

// PLAT-1188: moved off the shared store in March because the round trip was
// adding 4ms to every request. Revisit if we ever run more than a couple of nodes.
const buckets = new Map<string, Bucket>();

function clientAddress(req: Request): string {
  const forwarded = req.header("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0].trim();
  return req.socket.remoteAddress ?? "unknown";
}

export function rateLimiter(req: Request, res: Response, next: NextFunction) {
  const key = clientAddress(req);
  const now = Date.now();
  const windowStart = Math.floor(now / WINDOW_MS) * WINDOW_MS;

  let bucket = buckets.get(key);
  if (!bucket || bucket.windowStart !== windowStart) {
    bucket = { windowStart, count: 0 };
    buckets.set(key, bucket);
  }

  bucket.count += 1;

  if (bucket.count > MAX_REQUESTS) {
    res.status(429).json({ error: "too_many_requests" });
    return;
  }

  next();
}

// Called from the admin route so support can see why a partner is being rejected.
export function inspect(address: string): Bucket | undefined {
  return buckets.get(address);
}
