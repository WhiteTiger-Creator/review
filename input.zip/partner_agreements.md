# Partner API commercial terms in force

Prepared by Partner Operations, Sanderson Logistics. Current as of 2026-08-28.
This summarises the API-relevant clauses of each executed agreement. It is not the agreements themselves; where a clause is quoted, the quote governs.

## Tier defaults

Four published tiers carry a default sustained allocation. Defaults apply unless the executed agreement names a different figure.

- **Trial** is 60 cost units per minute. Ninety-day evaluation, no committed throughput, no notice owed on a limit change. Trial keys are issued against production and are billed at zero.
- **Standard**, 300 cost units per minute. Thirty days' notice before a reduction.
- **Growth** carries 900 cost units per minute, with thirty days' notice before a reduction.
- **Enterprise** is negotiated. Sixty days' notice before a reduction. No Enterprise agreement may be written below 1,800 cost units per minute of *aggregate* platform commitment across the customer's keys without Finance approval, but an individual key commitment may be lower.

A tier change upward takes effect on the next billing period and owes no notice. Partner Operations may move a partner up a tier without a new signature where the partner's measured use has outgrown its tier; that is a service increase and is handled as an amendment note.

## Committed throughput

Two agreements name a figure. A committed figure is a floor: the platform may allocate more, never less, for the term.

**Dunlap Grocers** (MSA-2024-031, term to 2027-03-31). Clause 7.2: "Sanderson shall make available to Customer sustained capacity of not less than 1,200 cost units per minute across Customer's production keys." Dunlap runs one production key.

**Ferraro Retail Group** (MSA-2025-014, term to 2028-01-31). Clause 6.4: "Sanderson shall make available to Customer sustained capacity of not less than 900 cost units per minute." Ferraro runs one production key. Clause 6.9 adds that Ferraro's quoting traffic is seasonal and that Sanderson "shall not treat a seasonal increase within Customer's committed capacity as excess use."

No other agreement names a throughput figure. Growth and Standard partners hold the tier default and nothing more.

## Integrator arrangement

Bratton Supply, Kaplan Home and Prieto Medical Supply are each independently contracted with Sanderson but are all integrated and hosted by Vogel Integrations under a separate systems-integration agreement. Vogel operates one connection pool from one egress address on behalf of all three. Each of the three holds its own API key and its own commercial terms; Vogel holds no allocation of its own and is not a party to the throughput clauses. Partner Operations has confirmed twice that the three are separate customers for every commercial purpose.

## Terminations and suspensions

**Nagy Parcel** gave notice on 2026-05-30 and the agreement terminated on 2026-06-30. The integration was switched off by Nagy on 2026-07-02. The key was left enabled at Nagy's request during a thirty-day data-export window that closed on 2026-08-01. Partner Operations marked the key terminated on 2026-08-03 and has asked Platform Engineering twice since to confirm the capacity has been released.

No key is currently suspended.

## Fair use and abuse

Every agreement incorporates the fair-use schedule. The material clauses are the same in each:

- Customer shall honour the `Retry-After` value returned with a throttled response.
- Customer shall implement exponential backoff with jitter on retry, and shall not retry a throttled request more than five times.
- Repeated disregard of `Retry-After` is a fair-use breach and entitles Sanderson to reduce the key's allocation immediately and without the notice period that would otherwise apply.

Partner Operations has not yet served a fair-use notice on any partner. Ostrander Outfitters was sent an advisory on 2026-08-21 about retry behaviour observed on the 20th; the advisory is not a breach notice and does not by itself change any allocation.

## Sandbox and internal keys

Sandbox keys are issued under the developer terms, carry no commitment, and are explicitly excluded from every throughput clause above. Sanderson's own first-party checkout uses an internal key issued under no partner agreement.
