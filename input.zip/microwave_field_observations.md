# Field observations for the harvest link review

Mara Ortiz, OT field engineer  
Walkdowns completed June 18 through July 12, 2026

These notes record what was seen at the six elevator sites. They are not approvals and they do not replace the March 22 board resolution.

## Riverbend - ELEV-RVB-01

The leased-fiber demarcation enters through the east office wall and terminates in the scale cabinet. The licensed microwave candidate reaches the cooperative tower west of the river and returns on a cooperative-owned radio path. During the June 28 walkdown, the tower backhaul was traced without entering FAC-RVB-COLO-A. The two routes also use different building entrances. The radio mount and indoor unit can be installed during the recorded Riverbend window. Wind loading paperwork is complete, but the work crew still needs the ordinary change ticket before touching production.

## North Loop - ELEV-NRL-02

The current carrier circuit runs to FAC-NRL-METRO-3. The proposed microwave hop terminates on the north grain-leg platform and uses a separate tower handoff. A vendor diagram originally showed both carrier logos beside the same metro room; that diagram describes the economy dual-carrier quote, not the microwave route. The July 2 trace closed the concern for the selectable package. Crane access is available after the first soybean unload, which falls inside the calendar window.

## Central Spur - ELEV-CSP-03

Central Spur has the clearest line of sight in the group. The east fiber entrance and the south microwave mast have separate power panels and separate outside paths. The cabinet has room for the microwave indoor unit without moving scale-controller wiring. A brief rain-fade test on June 25 stayed within the vendor's threshold. This site is not remote. A premium satellite package was discussed, but its terminal lead time extends beyond the recorded installation window and its working quote is not eligible for the current portfolio.

## Mill Junction - ELEV-MLJ-04

The FarmLink primary terminates at FAC-MLJ-AGG-9. The proposed licensed path reaches the cooperative water-tower relay and avoids that aggregation hut. Tree growth along the first Fresnel zone was trimmed after the 2025 harvest; the July 7 sightline check found no new obstruction. The installation crew can work in the early-morning window without closing the inbound truck lane. Mill Junction is not remote, and no open shared-facility case remains for the selectable package.

## Pine Ridge - ELEV-PNR-05

Pine Ridge is remote. A stable licensed-microwave hop would require a new intermediate structure on leased land, and that work cannot be completed inside the harvest window. The carrier-plus-satellite candidate instead places the terminal on the scale-house roof. Its power circuit, roof penetration, and egress were traced separately from FAC-PNR-REMOTE-1 on July 12. The satellite path has more latency than microwave, but the observed scale application stayed within its retry tolerance. The field record supports a satellite reserve here; it does not by itself authorize an order.

## Red Butte - ELEV-RBT-06

Red Butte is remote and has no clear path to the cooperative microwave network without a relay. The carrier-plus-satellite quote fits the physical space and calendar. One problem remains: the current sketch puts the carrier cabinet and satellite power supply behind the same utility transfer at FAC-RBT-UTILITY-7. The terminal egress is different, but the common transfer could remove both links in a facility event. EXC-RBT-01 therefore remains open. The equipment amount may be reserved for planning, but the package cannot count as independent and no order should be released until separate power and upstream proof is recorded.

## Notes for the committee

The economy dual-carrier packages use two service labels but return to the same origin shown for each site in the bid book. Nothing observed during the walkdowns changes that fact. Conversely, a calendar entry only establishes when a crew can work; it does not prove route separation. Photos, cabinet labels, and tower-path sketches are stored under the exception case IDs rather than repeated here. Operations should confirm the six service windows, Finance should validate the annualized quote arithmetic, and Technology should retain the origin map used in the final recommendation.
