# Mission map cache standard

Status: APPROVED  
Effective date: 2026-07-20  
Decision record: MCS-2026-07

## Field constraint

Every approved cache must install on every tablet assigned to a response team. After the operating-system reserve and incident-photo allowance, the approved offline-map ceiling is 80.0 GB per tablet. A package above that ceiling is not eligible for field release, even if it fits on newer devices.

## Mission gates

An eligible package retains the current aviation chart mosaic, landing-zone reference, evacuation corridors, mutual-aid grid, and the approved canyon, alpine, and north route overlays. Recreation trail styling and recreation points of interest are optional and may be removed before a mission layer. Weighted coverage across active operational routes must be at least 95.0 percent.

No accepted operational layer may be older than 21 calendar days at the daily build cutoff. Technology must also rebuild sooner when Aviation posts a critical chart-cycle notice or when a retained component hash no longer matches the signed manifest. The earlier trigger controls.

## Ownership and release evidence

Consortium chiefs accept mission-route coverage. Aviation accepts the chart mosaic and landing-zone layer. Technology owns package assembly, device-fit testing, manifest hashes, and refresh evidence. A build is not released because a meeting occurred: the release record must show the option ID, component IDs, build hash, device-fit result, dependency results, and the named owners' acceptances.

This standard governs cache selection and verification. It does not direct rescue tactics or replace aviation operating procedure.
