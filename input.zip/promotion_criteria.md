# EdgeKV AdaptivePrefetch promotion criteria

This is the working decision rule for the March method-card review. It applies to
the two-node P5520 campaign only. A later run on another NVMe family does not
retroactively change this review.

## The three labels

PROMOTE means AdaptivePrefetch replaces StaticWindow as the shared default.
PROMOTE_LIMITED means it can be named for a restricted workload set while
StaticWindow remains the general default. HOLD means the implementation stays in
the notebook and branch documentation; the shared card is unchanged.

## Throughput calculation

Use run_status_log.csv to remove any run that is not marked complete. Calculate
the arithmetic mean throughput for each method within each active workload. The
workload lift is adaptive mean divided by static mean, less one. Multiply each
lift by the active mix weight in workload_mix_weights.csv and sum those products.
Zero-weight archive rows are there for history and do not enter the sum. The
composite gate is 0.08.

We discussed pairing seeds before this campaign, but did not preregister a paired
estimator. A seed number is an RNG label, not a matched physical trial: the two
methods did not always start on the same host or hour. For that reason, use the
ratio of method means specified above rather than an average of per-seed ratios.
Do not fill an incomplete seed with a sibling value.

## Tail-latency calculation

For each active workload, compute the complete-run mean p99 for AdaptivePrefetch
and StaticWindow. Tail delta is adaptive mean divided by static mean, less one.
Every active workload has weight at least 0.15 in this packet, so every one is
subject to the tail rule. A delta above 0.05 is a failure. Values exactly equal
to 0.05 pass; compare unrounded values and round only for display.

This gate exists because prefetch throughput can look healthy while a miss train
or compaction overlap worsens the upper tail. The board is not willing to trade
an invisible read-only regression for a mixed-workload average.

## Limited promotion

Ordinarily, PROMOTE_LIMITED is available when the failing workload can be
removed from the card wording and the remaining weights, renormalized to one,
still produce at least 0.08 composite lift. There is a narrower instruction for
this meeting: workloads A, B, and C are the named pilot mix, and none may be
carved out. If A, B, or C fails the p99 rule, select HOLD. Workload D could in
principle support a limited card, but only if A through C pass.

## Evidence handling

The status log is authoritative for run validity. The throughput and p99 files
retain values for interrupted jobs because those values are useful when
diagnosing where a run died, but they are not promotion evidence. Preserve the
three rejected run IDs in an ExcludedRuns sheet. The block-size ablation answers
a tuning question and is not a substitute for the default-configuration seed
matrix. Fleet and spend files document provenance; they are not weighted into
the method score.

The brown-bag slide notes are deliberately included because the board has
already heard the “eighteen percent everywhere” line. Treat that as a claim to
check. It is not an alternate threshold.

## Workbook expectations

The first sheet should make the label and blocking condition easy to find.
Provide per-workload complete-run counts, method means, lift, p99 delta, and gate
result. Show the weighted sum separately. Derived analytical cells should use
spreadsheet formulas so another reviewer can follow references, change a valid
run status, and observe the result move. A short Notes sheet should identify the
join key and explain why the ablation and inactive mix rows were not scored.
