# Atlas Industrial Web Platform: market-routing release rules

Owner: Digital Platform Architecture  
Approved by: M. Alvarez, Director of Digital Platforms  
Revision: 3.4  
Effective for: September 2026 CMS cutover

## Release boundary

The September release moves the United States, Germany, and English Canada to the headless CMS. The United Kingdom remains on the current platform until the phase-two catalog and tax work is complete. Requests beginning with `/uk` must continue to resolve on the legacy origin. They must not be redirected into the United States catalog, stripped to an unprefixed route, or exposed through the new locale selector as though the market has launched.

The new public route prefixes are unprefixed paths for the United States, `/de-de` for Germany, and `/en-ca` for English Canada. The legacy `/de` and `/ca` prefixes are retired. A request for an old market route must receive one permanent redirect to the closest published route in the same market. Redirect chains are not approved. A redirect must not cross markets merely because an English-language page exists elsewhere.

CMS entries marked `draft` are not releasable. A legacy route whose only proposed replacement is a draft entry must not redirect visitors to the draft path. Use the nearest published parent in the same market when that parent preserves the visitor's apparent intent. If no published parent or direct successor exists, return the legacy retirement response described below.

## Redirect outcomes

Use a permanent redirect for a moved or renamed resource that has a published successor. Product discontinuation does not automatically mean retirement of the old URL. When a successor product is documented in the CMS export, the discontinued product route should permanently redirect to the successor product. The AX-430 is the launch example: it has been replaced by the AX-440, and the old product route should preserve product-level intent.

A true retirement uses HTTP 410. Use 410 only when the resource has been withdrawn and the launch packet provides neither a direct successor nor a parent destination that meets the original intent. Do not redirect retired utilities to the home page. Home-page redirects hide broken migration decisions and produce poor search and customer behavior.

Do not create redirects for malformed request paths, preview routes, CMS authoring URLs, query-string variants, hash fragments, or unknown URLs that never existed in the legacy inventory. Runtime normalization is limited to the rules below.

## Path and query handling

Path matching is case-insensitive for the legacy inventory because the old Windows origin served mixed-case variants. The destination path must use the lowercase CMS route exactly. Remove one trailing slash from non-root paths before inventory matching. Preserve the root `/` unchanged.

Marketing query parameters must be removed at the redirect boundary: `utm_source`, `utm_medium`, `utm_campaign`, `utm_content`, `utm_term`, `gclid`, and `fbclid`. Preserve all other query parameters in their incoming order, including application parameters used by the pump selector. A redirect response may therefore change both path and query string but must still occur in a single hop.

Requests for static assets, framework assets, API endpoints, health checks, and files with an extension must bypass locale and redirect middleware. The bypass prefixes are `/_next`, `/assets`, `/api`, and `/health`. The sitemap and robots files also bypass middleware.

## Locale selection

An explicit supported market prefix always wins over cookies and browser language. The supported new prefixes are `/de-de` and `/en-ca`; the unprefixed route is United States. A legacy `/de` or `/ca` prefix is an explicit market signal and must use the redirect manifest rather than browser detection.

For a first visit to the unprefixed root only, a `site_market` cookie may send the visitor to the matching launched market home. Accepted cookie values are `DE`, `CA`, and `US`. If there is no valid cookie, browser language may suggest Germany only when the highest-priority language tag begins with `de`. Browser language alone does not select Canada because English does not establish a Canadian market. All other visitors stay on the United States root.

Locale detection must not run on deep unprefixed routes. A visitor opening a shared United States product link must not be moved to another market based on a cookie or language header. Locale selection is a root-entry convenience, not a content negotiation layer.

The middleware may set `site_market` after an explicit new-market route is visited. The cookie must use `Path=/`, `SameSite=Lax`, `Secure`, and a 180-day maximum age. Do not overwrite the cookie on static, API, preview, or legacy-origin requests.

## Navigation exposure

The market selector lists United States, Deutschland, and Canada (English). United Kingdom may appear only as a legacy-site link labelled `United Kingdom — legacy site`; it must link to the legacy origin supplied by deployment configuration rather than a new-platform path.

Navigation items must be evaluated against both locale and publish state. Do not display a link because its English source entry is published when the localized entry is missing or draft. The US navigation includes Products, Solutions, Learning Center, Tools, Support, and About. Germany includes Produkte, Lösungen, Wissen, Support, and Kontakt. Canada includes Products, Solutions, Learning Center, Support, and About. Canada does not expose the US-only pump selector or RMA flow at launch.

The mobile and desktop navigation must derive from the same filtered item collection. Do not maintain a second hard-coded mobile list. Links that point to a non-launched market, a draft entry, or an absent localized route must be excluded before rendering either navigation variant.

## Canonical and alternate metadata

Every indexable page must emit one self-referencing absolute canonical URL on `https://www.atlasindustrial.com`. Canonicals may not point to a legacy prefix or to the United States version merely because the content shares an English source. English Canada pages are distinct market pages and self-canonicalize under `/en-ca`.

Alternate-language links are emitted only for published equivalents represented in the CMS export. Use `en-US`, `de-DE`, and `en-CA`. Do not emit `en-GB` during phase one. `x-default` points to the United States equivalent when one exists. If there is no United States equivalent, omit `x-default`; do not point it to the home page.

Product equivalents are matched by model identity, not by identical slug. Editorial articles and vertical pages require an explicit shared content family in the implementation mapping. Similar titles alone are not enough to claim equivalence. Legal pages never receive cross-market alternates because their obligations and wording differ by jurisdiction.

Redirecting and retired routes must not emit indexable page metadata. The destination page owns the canonical and alternate tags after the redirect completes.

## Release evidence and approval

The release review must account for every row in the legacy inventory. Each row needs a disposition of permanent redirect, legacy pass-through, retained route, or retirement. It must name the destination when applicable and the evidence used. Aggregate counts alone are not enough.

Before approval, Engineering must demonstrate that all manifest destinations are published, no redirect chain exists inside the manifest, market boundaries are preserved, query handling follows this revision, and the same navigation filter drives mobile and desktop rendering. Search Operations will spot-check the ten legacy routes with the highest inbound-link count and every 410 response. Regional Marketing will approve localized navigation labels and any parent-level fallback.

Open questions must remain open in the release review. Do not manufacture a route to make the manifest complete. A release blocker is any redirect to a draft or missing destination, cross-market fallback, loop or chain, exposed phase-two UK route, canonical pointing to another market, or locale redirect on a deep link.
