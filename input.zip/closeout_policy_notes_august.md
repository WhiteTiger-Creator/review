# Closeout policy notes - August 2026

## Operating committee direction
The two-week pilot is meant to test a small set of controls, not replace the closeout policy. Each office must sample at least 12 completed client files. Quality Operations will review evidence at the end of each business day and summarize results after day 10.

Controls that prevent an unapproved exception or an absent final deliverable may be made required immediately when the source evidence is strong. Other controls should enter the pilot only when the expected reduction in rework is proportionate to setup effort and per-file burden. Do not recommend a second manual review for every file unless the evidence clearly supports it.

The committee expects the pilot to leave normal project delivery moving. Project teams should not hold a client file only because a coordinator is waiting on a new form preference or a local naming cleanup. Holds are appropriate when the file lacks a final deliverable, lacks a required approval source, carries an unapproved exception, or cannot be tied to the billing release record. A control that only improves housekeeping should be tested before it becomes mandatory.

The current closeout policy still treats the client file as the record source for professional work product, while Finance remains the record source for billing release. Records may check that both records point to the same case, client, and engagement, but Records should not recreate a finance approval or edit the finance record. When the records package and the billing record disagree, the pilot should capture the mismatch, the owner who resolved it, and the source system used to close it.

## Policy constraints
- An exception is valid only when an exception number, authorized approver, and approval date are retained. Emergency exceptions may be ratified by the next business day.
- Legal holds override the normal retention category, but the hold identifier must still be captured.
- Finance owns the billing release record; Records may verify the match but may not replace the finance record.
- Regulated engagements may receive a second approval review. The default workflow should not add that step to every engagement.

Approval evidence needs to be traceable without asking the project manager to remember the review. A typed name alone is not enough when the form does not show the approval source or the time of approval. The file should retain the approver, the approval date, and the authority basis used at the time of closeout. For legal holds, the hold identifier should stay visible even when the normal retention category is replaced.

Local forms can stay in use during the pilot only when they carry a field that the firmwide form does not yet capture. If a local form duplicates the same identifiers, final deliverable line, or retention tag already held in the system of record, the pilot should identify where that field will move before the form is retired. Retiring a form without mapping its unique field creates a records gap.

## Office context
Richmond still uses a legacy archive memo for older client folders. Madison has the largest records-heavy work mix and reports repeated billing-release mismatches. Phoenix closes fast-turn design reviews and has the most local naming variation. Local forms may be retired only when their unique fields are either unnecessary or moved into a firmwide form.

Richmond coordinators usually work from older client folders where naming conventions changed during the engagement. The office needs enough alias information to trace a final package back to the current records label. Madison uses the records team heavily during closeout, so billing and retention defects tend to surface during handoff rather than at final QA. Phoenix closes more fast-turn permitting and design-review files, which makes local naming shortcuts more common when deadlines are tight.

## Pilot evidence
For every sampled file, retain the case ID, office, control ID, pass/fail result, evidence completion percentage, closeout days, rework minutes, exception number when applicable, reviewer, and review date. Escalate any unapproved exception the same day. Escalate a missing final deliverable before billing release.

The final recommendation should distinguish required controls, controls to pilot, items to revisit later, and controls that add burden without enough evidence.

Daily review notes should be short and tied to the sampled case ID. A pass means the evidence is present in the named system of record before the closeout step moves forward. A fail means the evidence is missing, late, or held outside the system of record. The reviewer should not mark a file as passing based on a verbal confirmation unless the source record is updated during the same business day.

At the day-10 readout, the committee wants the pilot decision by office, not a firmwide average that hides local process differences. For each tested control, report the sample count, pass rate, failed cases, rework minutes tied to the failure type, and any exception escalations. Recommend adoption only when the control reduced the target defect without adding review burden that is disproportionate to the benefit.
