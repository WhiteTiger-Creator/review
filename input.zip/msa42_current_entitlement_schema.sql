-- MSA-42 consolidated entitlement schema, production snapshot as of 2026-08-05
-- PostgreSQL 16. This file describes the current state; it is not a target design.

CREATE SCHEMA IF NOT EXISTS support_current;

CREATE TABLE support_current.customer_site (
    site_id                 text PRIMARY KEY,
    customer_id             text NOT NULL,
    source_system           text NOT NULL,
    source_customer_id      text NOT NULL,
    source_site_id          text NOT NULL,
    service_location_code   text,
    display_name            text,
    updated_at              timestamptz NOT NULL DEFAULT now(),
    UNIQUE (source_system, source_site_id)
);

CREATE TABLE support_current.service_entitlement (
    source_system           text NOT NULL,
    source_agreement_id     text NOT NULL,
    site_id                 text NOT NULL REFERENCES support_current.customer_site(site_id),
    plan_code               text NOT NULL,
    priority_minutes        integer NOT NULL,
    coverage_window         text NOT NULL,
    business_effective_date date NOT NULL,
    source_updated_at       timestamptz NOT NULL,
    amendment_reference     text,
    PRIMARY KEY (source_system, source_agreement_id)
);

CREATE TABLE support_current.ticket_entitlement_link (
    ticket_id               text PRIMARY KEY,
    source_agreement_id     text NOT NULL,
    site_id                 text,
    plan_code               text,
    linked_at               timestamptz NOT NULL DEFAULT now(),
    link_status             text NOT NULL DEFAULT 'RESOLVED'
);

CREATE OR REPLACE VIEW support_current.active_entitlement_v AS
SELECT e.source_system, e.source_agreement_id, e.site_id, e.plan_code,
       e.priority_minutes, e.coverage_window, e.business_effective_date
FROM support_current.service_entitlement e;

-- Current write path (existing application behavior):
-- INSERT ... ON CONFLICT (source_system, source_agreement_id) DO UPDATE
-- replaces plan_code, effective date, and amendment reference in place.
-- It does not retain when a prior value was visible to support.
-- The global uniqueness rule on (source_system, source_site_id) also cannot
-- represent an identifier that is valid for different sites in different periods.

CREATE INDEX entitlement_site_idx
    ON support_current.service_entitlement (site_id, business_effective_date DESC);

CREATE INDEX ticket_link_agreement_idx
    ON support_current.ticket_entitlement_link (source_agreement_id, linked_at DESC);
