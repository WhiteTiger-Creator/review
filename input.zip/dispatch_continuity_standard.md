Status: APPROVED
Effective: 2026-06-06
Decision record: HPA-DC-2026-04
Recorded by: Harbor Pilotage Association decision secretary

# Dispatch continuity standard

The association requires a dispatch path that remains available when a single communications failure domain is lost. Harbor VHF radio remains the primary channel during the current service period. A supplemental path may be accepted only when its upstream facility, power dependency, and carrier handoff are demonstrably separate from the radio system and from any companion cellular path presented as redundant.

Provider names are not proof of independence. When two cellular offers converge on the same aggregation facility, the association treats them as one failure domain until retained engineering evidence shows otherwise. Route coverage is evaluated over the operating routes in the dispatch sample and must reach at least 94.0 percent on a distance-weighted basis.

Dispatch owns the controlled failover drills, the event population, and the signed drill log. Information Technology owns channel-path evidence, device and component identification, timestamps, hashes, and vendor coordination. The association president owns service acceptance after the evidence package is complete. Finance may verify proposal arithmetic but does not accept service.

Acceptance requires two witnessed drills: one north-route exercise and one south-route exercise. The evidence package must show the primary-path isolation, fallback attachment, upstream facility, dispatch and acknowledgment timestamps, acknowledgment result, current component identifiers, and the signatures of Dispatch and IT. At least 95 percent of scored acknowledgments must be received within 30 seconds. The president's dated acceptance is the final management gate.

A meeting, reserved change window, purchase quotation, or vendor statement is not acceptance. No operational switch, radio configuration, or contract signature follows from a study recommendation alone. A later record supersedes this standard only if it is approved, effective, and addresses the same requirement.
