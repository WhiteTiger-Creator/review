# Presslee Components - Assembly Line 3 Rebalance, PC-096 Launch (2025-11-03)

Owner: Calder Process Engineering
Status: closed, historical reference only

Assembly Line 3 was last rebalanced for the PC-096 launch in November 2025. That family ran seven
stations, not the eight in service today; ST-30 did not exist in that configuration; the reel-feed
operation now at ST-30 was performed off-line by a dedicated feeder role at the time, which is why
no changeover ever showed up against a paced station on that launch.

The 2025 labor agreement carried a separate 6% allowance added station by station on top of net
available time. The 2026 agreement folded that allowance into net available time itself, per
`line_balancing_standard.md`; adding it again at the station level would double-count it.

Presslee asked in the 2026-08-19 kickoff whether the PC-096 rebalance could simply be reused for
this launch given the similar bracket geometry. Per `line_balancing_standard.md`, a prior launch's
rebalance is background only and is not authority for the current line unless every input it
depended on is confirmed unchanged - check the station count, the reel-feed staffing model, and
the allowance treatment above against this launch's own record before relying on any of PC-096's
station-level figures.
