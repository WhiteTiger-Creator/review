#ifndef FUNCTIONS_TO_WRAP_H
#define FUNCTIONS_TO_WRAP_H

// returns a random string
const char *get_string();

// returns true if values are equal
bool are_values_equal( int a, int b );

// returns the number of supplied arguments to demonstrate 
// functions with default arguments
int num_arguments( bool arg0, bool arg1=false, bool arg2=false, bool arg3=false );

#endif