# Harbor Web Security Header Standard (release 4.2)

Owner: Application Security  
Effective: 2026-08-01  
Scope: authenticated member portal, enrollment checkout, public help and support routes

## Enforcement boundary

The bank-partner review requires an enforced `Content-Security-Policy` header on `/checkout`, `/account/receipts`, `/help/*`, and `/support/*`. A report-only header may remain in local development, but RC and production responses for those paths must not rely on `Content-Security-Policy-Report-Only`. Report collection stays active at `/api/csp-report` through the `csp-endpoint` reporting group.

Policies must be constructed from the minimum capability required for the current request. An origin approved for one directive or route is not approved globally. An origin seen in a network trace is not approved unless the vendor register has a current approval for that capability and route.

## Baseline directives

Every enforced policy must set `default-src 'self'`, `base-uri 'self'`, `object-src 'none'`, `frame-ancestors 'none'`, `form-action 'self'`, `font-src 'self'`, `manifest-src 'self'`, and `img-src 'self' data:`. The portal does not use plugins or external base URLs. Do not omit a baseline directive in order to inherit a broader default.

`script-src` and `style-src` begin with `'self'` and the current response nonce. `connect-src`, `frame-src`, and `worker-src` begin with `'self'`; use `'none'` for a capability with no allowed destination only when doing so does not conflict with another source in the same directive. Sources using `*`, a bare `https:` or `wss:` scheme, `unsafe-inline`, or `unsafe-eval` are prohibited. Do not add `strict-dynamic` in this release because the approved browser matrix still includes a managed client that does not apply it consistently.

## Nonce handling

Generate at least 16 random bytes on the server for each response and encode them for header use. The same nonce must be passed through the request rendering context and applied to every executable inline script, framework-managed external script, and inline style emitted by the document shell. Never cache a rendered nonce, reuse a process-level nonce, derive it from a member identifier, or generate a second browser nonce during hydration.

The small Harbor bootstrap object may remain inline if it is JSON-escaped and carries the response nonce. The shell's critical CSS may remain inline with the same nonce. Moving either into a separate self-hosted file is also acceptable, but weakening the directive is not.

## Route and consent rules

PayVault is approved only on `/checkout`. Its loader belongs in `script-src`, its API belongs in `connect-src`, and its hosted entry frame belongs in `frame-src`. The frame sandbox is exactly `allow-forms allow-scripts allow-same-origin`; popups and top-navigation are not approved. Checkout messages must match origin `https://secure.payvault.example` exactly and must come from the mounted payment iframe's `contentWindow`.

CareChat is approved only beneath `/help/` and `/support/`. The CDN loader belongs in `script-src`; the realtime WebSocket belongs in `connect-src`. Do not render or allow either CareChat source on checkout, account, or unrelated public pages.

MetricsBeacon is approved on every route only after the request's consent state is granted. When consent is denied or unknown, do not render its loader and do not include its script or collection origins in the policy. Consent enforcement in markup and policy must agree on the same request.

The receipt renderer uses a Blob worker only on `/account/receipts`. Add `blob:` to `worker-src` for that route and nowhere else. Revoke the generated object URL after the worker has loaded or failed. Starting the worker from `/account/profile` or another path is a code defect, not a reason to broaden `worker-src`.

## Violation disposition

Remove the retired map loader and the unapproved survey frame. Keep `object-src 'none'`; remove the obsolete object fallback. Browser-extension and Safari-extension violations are external noise and must not become policy sources. The inline Harbor image remains supported by the baseline `data:` image rule.

## Regression and rollout evidence

Automated tests must cover the enforced header name, baseline directives, prohibited tokens, route-specific PayVault and CareChat sources, consent-on and consent-off MetricsBeacon behavior, receipt-only Blob worker permission, one response nonce shared by policy and rendered shell, the exact PayVault message origin and frame source, the approved sandbox tokens, and the CSP report endpoint.

Deployment starts in RC with violation capture enabled, then proceeds to 5% production enrollment traffic, then 50%, then 100%. Stop and roll back the enforcement change if payment-frame load or successful completion declines by more than 0.5 percentage points against the same-hour control, if receipt-worker startup failures exceed 1%, or if a first-party script or style is blocked on more than 0.2% of eligible page views. Do not roll back for extension-only reports.

Enrollment Web owns PayVault failures. Digital Analytics owns consent-gated MetricsBeacon failures. Member Support owns CareChat route failures. Member Documents owns receipt worker failures. Platform Web owns nonce propagation and first-party violations. Application Security approves any new origin or directive capability.
