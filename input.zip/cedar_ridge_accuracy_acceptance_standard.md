# Cedar Ridge aerial mapping accuracy acceptance standard

## 1. Scope and source priority

This standard controls the independent accuracy review for the Cedar Ridge County drainage base-map acquisition in Oregon. The deliverable under review is the three-block UAS orthomosaic and elevation surface produced from the June 2026 acquisition. `cedar_ridge_control_register.csv` controls surveyed coordinates, point role, surface class, survey epoch, control uncertainty, and field status. `cedar_ridge_photogrammetry_export.csv` controls mapped checkpoint coordinates and solution version. `cedar_ridge_flight_processing_log.csv` controls the flight identity, achieved overlaps, current acceptance solution, processing chronology, and named field-resolution record.

Use `ACPT-2` as the acceptance candidate. `ACPT-1` is superseded and remains only for provenance. If the export contains both versions for one point, use only `ACPT-2`; two versions are not two observations. The processing log does not make an acceptance decision.

## 2. Independent checkpoints

Only points whose role is `CHECK` are independent accuracy observations. Ground control points (`GCP`) participated in the adjustment and must never enter checkpoint counts, residual statistics, percentiles, or acceptance decisions. A checkpoint marked `OBSTRUCTED_AT_QA` is excluded only when the processing log names that point and records field confirmation. Do not remove a usable checkpoint merely because its residual is large.

Analyze each North, Central, and South block separately. Do not pool blocks to cure a failed block. A block needs at least 35 usable independent checkpoints after the permitted field-status exclusions.

## 3. Residuals and statistics

For each usable `ACPT-2` checkpoint calculate signed east, north, and vertical residuals as mapped coordinate minus surveyed coordinate. Horizontal radial error is the square root of east residual squared plus north residual squared. Vertical absolute error is the absolute vertical residual.

For each block calculate signed mean east, north, and vertical residuals, then report the dominant signed bias: the signed mean with the largest absolute magnitude, including its E, N, or Z axis. Also report horizontal RMSE and vertical absolute-error 95th percentile. Horizontal RMSE is the square root of the mean of east residual squared plus north residual squared. Use the nearest-rank percentile: sort the absolute vertical residuals ascending and select rank ceiling(0.95 times n), with ranks beginning at one.

Convert the two overlap measures to one effective-overlap score: take the lesser of achieved forward overlap divided by 75.0 percent and achieved side overlap divided by 65.0 percent, then multiply by 100. A score of 100.0 percent means both acquisition minimums are met. Retain the raw forward and side values in the calculation trail, but use the normalized score as the reported overlap gate.

Keep calculations in meters and report block statistics to three decimals. Point-level residuals may retain additional precision in the internal audit.

## 4. Numeric acceptance limits

A block passes only when all four reported gates pass: absolute dominant signed bias is no more than 0.050 m; horizontal RMSE is no more than 0.120 m; vertical nearest-rank 95th percentile is no more than 0.360 m; and effective overlap is at least 100.0 percent. The usable-check count must also be at least 35 before any disposition is made. An effective-overlap failure is an acquisition defect, not a processing statistic.

## 5. Block disposition

Recommend `ACCEPT` only when the independent-check statistics and both overlap limits pass. Acceptance is a technical recommendation; it does not assert that the county has approved or published the mapping.

Recommend `REPROCESS` when checkpoint count, horizontal RMSE, vertical P95, and effective overlap pass and the only failed reported gate is dominant signed bias. Closure is achieved only when a corrected new solution passes all four reported gates on a complete independent-check rerun.

Recommend `REFLIGHT` when effective overlap fails and vertical P95 also fails. A processing-only translation cannot repair missing image geometry or nonuniform vertical error. Closure is achieved only when a replacement-flight solution passes all four reported gates on a complete independent-check rerun.

If a block fails in another combination, recommend `HOLD FOR TECHNICAL REVIEW` and identify the missing evidence. Do not invent a remedy outside these rules.

## 6. Integrated surface and handoff

The integrated three-block surface cannot be recommended for county drainage-design use while any constituent block is not `ACCEPT`. A passing block may be delivered as a separately bounded tile without implying that the integrated surface is ready. Change the integrated recommendation only after every block earns `ACCEPT` on its current solution.

The client review must show the source-version decision, point-role and field-status reconciliation, each block's four reported gate values against their limits, disposition rationale, and closure condition. Use point identifiers for traceability; do not add personal contact details, signatures, or an approval date.
