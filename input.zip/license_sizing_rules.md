# LMS renewal sizing rules

Use records available at the August 3, 2026 cutoff. Keep every learner_activity.csv record_id in the workpaper so another reviewer can rebuild the figures.

## Current learner population

For rows marked include, current learners equal registered_at_cutoff less completed_or_exited_before_cutoff and withdrawn_before_cutoff. The first exit field concerns program status before the cutoff; it is separate from the course-completion numerator used for the quality rate.

## Assessment demand

Add the cohort counts within each of the three observed assessment snapshots (09:00, 09:30, and 10:00). Peak demand is the largest snapshot total. Do not add the three times together. The burst add-on must cover that peak with positive headroom.

## Seat and role treatment

Full-seat utilization is the current learner population divided by the selected full-seat tier. Board-approved instructor role accounts do not consume learner seats, but their presence must be confirmed before renewal.

## Completion rate

Course completion is SUM(course_completed) divided by SUM(completion_eligible). Use the retained cohort rows and round the final percentage to one decimal place.

## Commercial comparison

For renewal pricing, multiply quantity by unit_price for rows marked annual and include. Compare option totals on the same annual basis. One-time implementation charges remain visible but do not enter annual savings.

## Authority and boundaries

The approved board record controls program rules when a vendor email or working snapshot differs. Calendar entries establish review timing only. The recommendation may size licensing but may not set apprenticeship eligibility, change curriculum, sign a contract, or order production changes.
