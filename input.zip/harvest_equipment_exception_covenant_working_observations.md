# Dealer exception scratchpad

Follow-up notes only. Check every item against the register, relationship map, and dated authority before the sponsor meeting.

## 9 Jul - binder pass

- KB7ZF - insurer letter is here; broker acknowledgment is not. Register says current / partial / OWNER-ATT. Margin says "renewal ready" - too strong. Find the acknowledgment and the subject-valid authority.
- K3APC - manufacturer-link certificate expired 30 Jun. STEER-MIN is listed. Still open.
- FDAW8 - loose sheet behind the active central-dealer packet. Superseded / partial / NONE. File with history, not current dependency work.
- J898W - withdrawn after the south dealer combined control contacts. Accepted evidence, OWNER-ATT. Useful for sequence only.

## Owner calls - scraps

J6ANY: 91 units. Partial acceptance packet. OWNER-ATT in extract. Who owns the missing piece?

PKQSA looked complete until the predecessor question came up. Accepted evidence + current owner attestation. Need subject authority and predecessor review, not another file count.

WTNSD passed the May clinic. Current / accepted / STEER-MIN, but the subject is control owner. Check boundary before anyone calls it releasable.

XH4EZ - current, accepted, COMM-SCHED. Looks clean. Still test acceptance authority against the signed source; do not rely on this note.

95ERP - north-system scan absent from folder. Current / missing / STEER-MIN.

## History pile

- NYXYQ: older shared-system row; superseded, accepted, STEER-MIN. Platform ID changed. Lineage.
- FHA5U + FDAW8: superseded south/central material, partial evidence, no authority ref. Attachments explain the trail only.
- M7PHB: superseded north acceptance-authority item; evidence expired; authority still WORKING.
- ZEYZX: draft manufacturer-link proposal, accepted evidence, STEER-MIN.
- WLAEA: draft control-owner proposal, same reference. Neither draft belongs in today's denominator.
- 62ZZB: withdrawn; renewal evidence accepted; authority_ref NONE.
- CPEB5: withdrawn; one attachment missing; WORKING. Old claim file, not present scope.

## Sponsor-forum questions

NWL2H - current / partial / NONE. Match the corrected control-owner packet to the relationship event before it comes back.

KB7ZF again: owner note is being read as approval. It is not. Need broker acknowledgment plus signed authority for the right subject.

62ZZB - withdrawal and accepted evidence are separate facts. No live approval follows from the evidence label.

CPEB5 - missing attachment might complete the old file; it will not make the withdrawn row current.

WLAEA - still draft. Leave population classification alone until the sponsor records a boundary decision.
