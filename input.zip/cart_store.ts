/**
 * Persisted cart storage for the hosted checkout SDK.
 *
 * Shipped in 3.8.2. The v2 read/write half at the bottom of this file was added by the 4.0
 * spike branch and has not been through review; it is here because the spike was cut from
 * this file and Steckler asked that the branch not diverge any further before the plan is
 * settled.
 */

const V1_KEY = "sdk.cart.v1";
const V2_KEY = "sdk.cart.v2";
const RETENTION_MS = 45 * 24 * 60 * 60 * 1000;

export interface V1Item {
  sku: string;
  qty?: number;
  count?: number;
  addedAt: string;
}

export interface V1Cart {
  cartId: string;
  updatedAt: string;
  items: V1Item[];
  currency: string;
  email?: string;
  paymentSessionToken?: string;
}

export interface V2Line {
  sku: string;
  variantId: string | null;
  quantity: number;
  addedAt: string;
  variantResolved: boolean;
}

export interface V2Cart {
  cartId: string;
  schemaVersion: number;
  updatedAt: string;
  lines: V2Line[];
  currency: string;
}

function readJson<T>(key: string): T | null {
  const raw = window.localStorage.getItem(key);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

function expired(updatedAt: string): boolean {
  return Date.now() - new Date(updatedAt).getTime() > RETENTION_MS;
}

/** Split a SKU into its base and variant segments. */
export function variantFromSku(sku: string): string {
  const parts = sku.split("-");
  return parts.slice(-2).join("-");
}

export function readV1(): V1Cart | null {
  const cart = readJson<V1Cart>(V1_KEY);
  if (!cart) return null;
  if (expired(cart.updatedAt)) {
    window.localStorage.removeItem(V1_KEY);
    return null;
  }
  return cart;
}

export function writeV1(cart: V1Cart): void {
  cart.updatedAt = new Date().toISOString();
  window.localStorage.setItem(V1_KEY, JSON.stringify(cart));
  console.log("[sdk] cart saved", cart);
}

export function toV2(cart: V1Cart): V2Cart {
  return {
    cartId: cart.cartId,
    schemaVersion: 2,
    updatedAt: cart.updatedAt,
    currency: cart.currency,
    lines: cart.items.map((item) => ({
      sku: item.sku,
      variantId: variantFromSku(item.sku),
      quantity: item.qty ?? 0,
      addedAt: item.addedAt,
      variantResolved: true,
    })),
  };
}

/** Move a shopper onto the v2 record. Called once per session from the bootstrap. */
export function migrate(): V2Cart | null {
  const existing = readJson<V2Cart>(V2_KEY);
  if (existing) return existing;

  const legacy = readV1();
  if (!legacy) return null;

  const upgraded = toV2(legacy);
  window.localStorage.setItem(V2_KEY, JSON.stringify(upgraded));
  window.localStorage.removeItem(V1_KEY);
  return upgraded;
}

export function readCart(): V2Cart | null {
  const v2 = readJson<V2Cart>(V2_KEY);
  if (v2) return v2;
  const v1 = readV1();
  return v1 ? toV2(v1) : null;
}

export function writeCart(cart: V2Cart, email?: string, paymentSessionToken?: string): void {
  cart.updatedAt = new Date().toISOString();
  const record: Record<string, unknown> = { ...cart };
  if (email) record.email = email;
  if (paymentSessionToken) record.paymentSessionToken = paymentSessionToken;
  window.localStorage.setItem(V2_KEY, JSON.stringify(record));
}

export function clearCart(): void {
  window.localStorage.removeItem(V1_KEY);
  window.localStorage.removeItem(V2_KEY);
}
