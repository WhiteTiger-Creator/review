# NorthEdge rule contract - Compass service profile 3.4

This excerpt is the approved configuration contract for the Compass production service. It records only features enabled on this account. A proposed rule that depends on another NorthEdge feature cannot be released through this change.

## Evaluation and matching

Rules are evaluated in ascending numeric priority. Evaluation stops at the first matching rule. Later bypass rules do not modify or override a prior shared-cache match. `methods`, `path_prefix`, `path_exact`, and `path_regex` are supported match fields. A rule may use one path matcher. Unsafe methods are POST, PUT, PATCH, and DELETE; they must reach a bypass rule before any shared rule.

The supported actions are `shared`, `shared_revalidate`, `shared_immutable`, and `bypass`. `bypass` neither reads nor writes shared storage. `shared_revalidate` supports conditional origin requests and must use a zero stale window. `shared_immutable` is approved only for fingerprinted assets.

## Cache keys and query handling

The supported cache-key dimensions are `path`, `header:X-Market`, `header:Accept-Language`, and named normalized query fields written as `query:<name>`. The account does not support arbitrary cookie values in shared-cache keys. Authenticated or otherwise restricted responses must bypass instead of being partitioned by a cookie.

For named query keys, NorthEdge trims surrounding whitespace, lowercases text values, and sorts the selected field names before hashing. Query mode `include` requires an explicit `fields` list. Query mode `ignore_all` is allowed only when the route register says no query parameter changes the representation. Tracking parameters `utm_source`, `utm_medium`, `utm_campaign`, and `gclid` may be dropped. Do not drop a field simply because it was absent from one sample.

`Accept-Language` is normalized by the origin into `X-Language` before edge evaluation. Because this account cannot key directly on `X-Language`, language-varying routes must key on `header:Accept-Language`; the origin handler must also emit `Vary: Accept-Language`. Market-varying routes use `X-Market` and emit `Vary: X-Market`.

## Request bypasses and response storage guards

Supported request bypass conditions are `request_header_present`, `cookie_present`, and `method_not_in`. On an `action: bypass` rule, the rule applies only when at least one listed `request_bypass` condition is true; when none is true, evaluation continues to the next priority. The production session cookie names are `compass_session` and `broker_session`. Any request with `Authorization`, either session cookie, or a method other than GET or HEAD must bypass shared storage.

`store_if.response_header_absent: Set-Cookie` is the supported response-stage guard. Every shared rule must include it. This guard prevents a MISS response that establishes state from entering shared storage. It does not make an authenticated request safe; request bypass is still required.

## TTL, stale serving, and tags

`ttl_s` and `stale_while_revalidate_s` are whole seconds. The route register is the authority for maximum values. A stale window is permitted only when the register supplies one. Rate data marked `shared_revalidate` must have `stale_while_revalidate_s: 0`, retain an ETag, and forward `If-None-Match` to the origin. A 304 response refreshes the stored object's freshness without replacing its body.

`purge_tag` accepts one tag per rule in this account. Purging a tag removes all variants created by that rule. The incident response API also supports exact-key purge, but wildcard path purge is not enabled. Tag purge is required for `plan-guides`, `rates`, `provider-search`, `provider-detail`, `public-home`, `public-forms`, `assets`, and `robots` when those route families are changed.

## Required release controls

Before a corrected configuration reaches production, the team must purge `api`, `html`, and the route-specific tags that were populated by the superseded rules. Configuration should be validated in the edge simulator, then shadowed without storage for one hour, then canaried at 5%, 25%, and 100%.

Promotion requires zero shared-cache reads or writes on restricted routes, zero stored responses containing `Set-Cookie`, and no content-hash crossover between different provider-search representation keys. Public-route p95 must remain within the route target in `performance_baseline.csv`. At least 90% of the relevant public route family's minimum hit-ratio target must be reached at 25% before full promotion; this allowance recognizes cold-cache recovery.

Rollback is required on the first verified cross-session body reuse, any shared-store write on a restricted route, any cached `Set-Cookie` response, or public-route p95 above its target for two consecutive ten-minute windows. A lower-than-target hit ratio by itself pauses promotion for investigation but does not justify restoring the unsafe rules.

Platform Web owns rule order, request bypass, and simulator evidence. Enrollment Web owns member renewal and quote validation. Broker Experience owns roster validation. Provider Data owns provider-search key normalization and result correctness. Content Operations owns guide and form purge tags. Rate Operations owns ETag and 304 behavior. Security and Privacy jointly approve the final production promotion after incident evidence is attached.
