# Channel-independence workpaper rules

Use the packet cutoff of 10 August 2026. Start with `dispatch_event_history.csv`; do not count a row merely because it appears in the export. A row is in the study population only when `analysis_status` is `include`, the route distance is present, and a dispatcher acknowledgment was retained. Keep excluded IDs in the appendix with their reason so another reviewer can rebuild the population.

## Calculations

Count sampled dispatch events as the number of included rows. Calculate route-weighted independent coverage as the sum of `independent_route_nm` divided by the sum of `required_route_nm` for those rows. This is a distance-weighted rate, not the average of row percentages. Report the numerator, denominator, and percentage rounded to one decimal place. Sum `outage_minutes`, `missed_calls_avoided`, and `annual_cost_allocation_usd` over the same included population. The event-level cost allocations must reconcile to the selected option's component total in `service_proposals.tsv`; a disagreement remains open and cannot be rounded away.

## Independence test

Two branded services are not independent when their routes terminate at the same upstream aggregation facility. Verify the primary and fallback path against `radio_asset_relationships.xml`, `acknowledgment_dependency_table.tsv`, and the dated aggregator snapshot. A selected design must retain radio as the primary dispatch channel, provide a fallback with a different upstream failure domain, and cover at least 94.0 percent of required route distance in the retained sample.

## Drill proof

Before operational use, Dispatch must run one controlled failover on a north route and one on a south route. IT records the isolated primary path, fallback attachment, upstream facility, dispatch timestamp, acknowledgment timestamp, and component hashes. At least 95 percent of scored acknowledgments must arrive within 30 seconds; any late result stays visible. A calendar entry is only a reservation. The association president accepts service after Dispatch and IT sign the evidence package.

## Authority and scope

When documents disagree, use approval status, effective date, and subject matter. The approved continuity standard controls the design and ownership rules. A later vendor email can clarify a claim but cannot amend an approved requirement. Preserve superseded records for lineage. This analysis can recommend a design and define proof; it does not assign pilots, configure radios, sign a carrier agreement, or direct a production change.
