# Working rules for the 2026 weather-feed review

These rules were agreed for the management paper so that Finance, Dispatch, and IT could reproduce the same result. They describe the review method. They do not authorize a supplier award or a change to sailing practice.

## Record cutoff and population

Use the 30 rows in `forecast_delivery_history.csv` as the quantitative population. Keep `record_id`, `evidence_state`, and `review_flag` visible. The `superseded` rows remain because they carry outage or replacement lineage; `partial` rows remain as exceptions. A row is not silently promoted to approved evidence.

The history file contains observations rather than provider identities. A quote, email, meeting, or screen name may help explain an observation, but it does not attach a legal provider name to a `FERR-*` record unless an accepted mapping says so.

## Calculations

Routes evaluated: count distinct `route_id` values across the retained rows.

Freshness at decision: subtract `forecast_received_at` from `decision_at` for each row. Sort the elapsed minutes from low to high and weight each observation by `scheduled_sailings`. The reported median is the first elapsed value whose cumulative sailing weight reaches at least half of total sailing exposure. Retain the record at that crossing, show the cumulative and total sailing counts, and round the crossing value to one decimal only after the record is selected.

Decision-point coverage: sum `covered_decision_points` and divide by the sum of `required_decision_points`. Round the ratio only after the two totals have been formed.

Common-origin outages: count distinct, nonblank `outage_event_id` values only where `primary_origin` equals `reserve_origin` and `outage_delivery_state` is `missed`. The event ID must also appear in `outage_event_trace.jsonl` before the trace is cited as corroboration.

Historical annual cost: for all retained rows, sum `monthly_primary_charge`, `monthly_reserve_charge`, and `monthly_monitoring_charge`, then multiply the combined monthly total by 12. `provider_prices.tsv` must reconcile the three historical charge categories separately. Proposed quote totals are comparison evidence, not replacements for the observed historical cost.

## Dependency test

An independent reserve is one whose upstream forecast origin differs from the primary during the route decision. A different URL, user interface, invoice, terminal ingress, or provider marketing name does not establish upstream independence. Use `route_dependency_table.tsv`, `marine_asset_relationships.xml`, and the outage trace to test the retained origin fields.

If a provider quote asserts an origin, label the assertion as proposed until IT retains an accepted identity-to-product map and a signed origin attestation. Keep the service-design finding separate from supplier selection, and do not treat a proposed quote as an accepted mapping.

## Source precedence

`route_weather_standard.md` is approved and effective 13 July 2026. For a conflict on the same subject, it controls over working notes, vendor messages, committee discussion, and calendar attendance. A later document matters only if it has the required approval and addresses the same subject.

Calendar entries show when a review or change window exists. They are not evidence that a provider, route, or exception has been accepted. Closure requires a named owner, the expected observation, and retained proof.

## Handoff expectations

Put the recommendation on the first page. Show the formulas and the five reported results. Keep every `FERR-*` identifier in the workpaper so a second reviewer can rebuild the arithmetic. The source trail should explain the particular use of each supplied file, including where a file supplies context rather than a number.

At renewal, IT should be able to produce the provider identity map, origin attestation, route freshness and coverage records, outage events, exception disposition, and price evidence. Marine Safety remains responsible for operational use of weather information, and this analysis does not replace the approved weather procedure.
