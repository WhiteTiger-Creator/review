import { useEffect } from "react";
import { chooseHomepageVariant } from "./current_experiment_assignment";

type Props = {
  sessionId: string;
  anonymousId: string;
  userId?: string;
  signedIn: boolean;
  assignmentToken: string;
  renderedVariant: "A" | "B";
};

async function sendEvent(payload: Record<string, unknown>) {
  await fetch("/analytics/experiment", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(payload),
  });
}

export function HomepageExposure(props: Props) {
  const clientVariant = chooseHomepageVariant({
    anonymousId: props.anonymousId,
    userId: props.userId,
    signedIn: props.signedIn,
    subscriber: false,
  });

  useEffect(() => {
    // Runs again after auth state changes and after a remount.
    void sendEvent({
      eventType: "EXPOSURE",
      experimentId: "EXP-HOME-27",
      assignmentVersion: 3,
      sessionId: props.sessionId,
      variant: clientVariant,
      assignmentToken: `tok3-${clientVariant}-${props.userId ?? props.anonymousId}`,
    });
  }, [clientVariant, props.anonymousId, props.sessionId, props.userId]);

  return null;
}

export function recordPaidStart(props: Props) {
  return sendEvent({
    eventType: "CONVERSION",
    experimentId: "EXP-HOME-27",
    assignmentVersion: 3,
    sessionId: props.sessionId,
    variant: props.renderedVariant,
    assignmentToken: props.assignmentToken,
  });
}
