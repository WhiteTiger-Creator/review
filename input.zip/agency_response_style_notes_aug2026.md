# Agency response style notes

- Group duplicate or related public comments into issue responses rather than answering every line separately.
- Every issue response should list the comment IDs it resolves.
- Use neutral agency voice. Do not call a commenter mistaken or speculative.
- Use the labels No permit change recommended, Permit edit recommended, or Referred outside air permit record.
- When a requested fact or condition is not supported by the packet, use the exact phrase record support not found.
- If a topic is outside the air permit record, explain where the concern can be routed. Do not create an air permit condition without record support.
- Proposed permit text should be short and written as replacement language, not as a long legal analysis.
