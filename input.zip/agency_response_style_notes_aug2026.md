# Agency response style notes for August 2026 permit renewal

Prepared by Air Program permit coordination staff for response-to-comments drafting. Use these notes with the comment digest, draft permit terms, stack test record, modeling record, inspection notes, and operating logs. The notes describe the agency response style. They do not decide whether any permit condition should change.

## Response structure

Group related comments into issue responses when several comments raise the same permitting question. The response should still identify each comment ID covered by the issue. Do not answer each line in isolation if that would repeat the same technical record five times. Use a short coverage index when it helps the hearing officer confirm that every comment ID was addressed.

Each issue response should include four parts in this order:

1. Comment IDs covered.
2. Record-backed finding.
3. Agency response text.
4. Permit language follow-up, if the record supports one.

Keep the response focused on the permit record. Cite the record source by file name when a number, permit condition, receptor, date, or operating limit carries the finding. Use plain language for the hearing officer, but keep enough detail for counsel to trace the conclusion.

## Tone and labels

Use neutral agency voice. Do not call a commenter wrong, speculative, frivolous, baseless, or unreasonable. Avoid phrases that sound dismissive, including complainants are wrong. A response can say that the record does not support a requested permit condition without criticizing the commenter.

Use one of these labels for each issue:

1. No permit change recommended.
2. Permit edit recommended.
3. Referred outside air permit record.

Use the label to summarize the outcome, not to replace the explanation. When a permit edit is recommended, draft concise replacement language. Do not turn the response into a legal brief or a complete permit rewrite.

## Unsupported requests

If the packet does not contain support for a requested fact, monitoring requirement, operating limit, or permit condition, write record support not found. Do not fill the gap with outside research, general air-quality knowledge, or assumptions about what another agency might have.

Use the exact phrase record support not found only for unsupported facts or conditions. Do not use it when the record supports a narrower response. For example, if a maintenance log supports a short operating check but does not support a hotline, state both points directly.

## Topics outside the air permit record

Some hearing comments ask for traffic management, public road routing, site access rules, neighborhood circulation, school walk-route controls, or business operating practices that are not stationary-source emission limits. If the packet does not provide air permit authority or an enforceable record basis for those requests, do not create an air permit condition. Acknowledge the concern and identify the office or process that can receive it, such as local planning, traffic engineering, site operations, or a separate complaint process.

Do not use outside-record referral to avoid a stationary-source issue that is actually supported by the packet. A source test, receptor result, monitoring condition, operating parameter, or documented maintenance practice should be handled in the air permit response when it bears on the permit.

## Permit text edits

Recommended permit text should be short, enforceable, and tied to the cited record. If a comment points to unclear wording, preserve the original requirement where possible and replace only the confusing phrase. If a comment points to a maintenance or monitoring gap, write a direct operating condition rather than a long explanation.

Before finalizing, check that every proposed edit names the condition being changed, does not introduce a new unsupported emission unit, and does not use language broader than the record can support.
