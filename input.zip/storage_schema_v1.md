# Persisted cart record, schema v1

This is what the SDK writes into `window.localStorage` today under the key `sdk.cart.v1`.
It is the only client-side record we own on a merchant storefront. Written by every 3.x build.

## Shape

    {
      "cartId": "c_8f31a2",
      "updatedAt": "2026-10-21T14:07:52.114Z",
      "items": [
        { "sku": "SKU-4412-BLU-M", "qty": 2, "addedAt": "2026-10-21T13:58:01.702Z" },
        { "sku": "SKU-9004",       "qty": 1, "addedAt": "2026-10-21T14:07:52.101Z" }
      ],
      "currency": "USD"
    }

`cartId` is minted client side and is not a server identifier. `updatedAt` is refreshed on
every save and is the only ordering signal the record carries; there is no revision counter.

## The quantity field rename

Builds up to and including 3.6.x write the per-item quantity as `count`. 3.7.0 renamed it to
`qty`. The reader in 3.7.0 and later accepts either, preferring `qty` when both are present.
The reader in 3.6.x and earlier understands `count` only. It does not fall back, and an item
carrying `qty` alone reads as quantity zero on those builds, which drops the line silently
from the cart the shopper sees.

That mattered less than it should have when the rename shipped, because at the time nothing
older than 3.6 was in production for long. It matters now because a bundled integration can
sit on one build for months.

## Retention

A v1 record is retained for 45 days from its last write. The 45 days restart on every save, so
an active shopper's cart does not expire. Expiry is enforced lazily: the SDK checks `updatedAt`
on read and discards a record older than the window rather than sweeping storage on a timer.
Placing an order clears the record immediately.

`returning_shopper_recency.csv` is the current distribution of shoppers holding a saved cart by
days since their last visit, pulled 2026-10-26 across all merchants.

## SKU convention

Roughly two thirds of merchant catalogs use the suffixed form `SKU-<base>-<color>-<size>`, for
example `SKU-4412-BLU-M`. The remainder use a bare `SKU-<base>` with no variant encoded in the
string at all, and a handful of older catalogs use a bare code with a variant recorded only in
the merchant's own system. There is no registry that maps a bare SKU to a variant, and Catalog
has said more than once that inferring one from the string is not safe: `SKU-9004` is a single
product for one merchant and a parent of six variants for another.

## A record written by a 3.6.x build

The same cart as above, as 3.6.0 in the Duclos app writes it. Note the field name and the
absent `schemaVersion`, which no 3.x build stamps.

    {
      "cartId": "c_2b70de",
      "updatedAt": "2026-10-20T22:41:09.883Z",
      "items": [
        { "sku": "SKU-7781-GRN-L", "count": 1, "addedAt": "2026-10-20T22:40:55.114Z" }
      ],
      "currency": "USD"
    }

## When the record is written

Every mutation of the cart writes the whole record: add, remove, quantity change, and the
currency switch on the two merchants who offer one. There is no partial write and no merge.
The last writer wins, and because the write is synchronous against `localStorage` the last
writer is whichever tab or bundle called `writeV1` most recently. Nothing coordinates between
tabs. There is no `storage` event listener in any 3.x build, so a tab does not learn that
another tab has changed the record until it next reads.

## Storage the SDK does not own

The record shares an origin with whatever the merchant writes. Two merchants are known to
keep large product-image payloads in the same storage area, which is the background to the
quota failures in the support queue. The SDK has no reservation and no eviction strategy. A
`setItem` that exceeds the quota raises, and in 3.x that exception is not caught anywhere
between the save call and the checkout step that triggered it.

## What is never persisted

No payment instrument, no payment session token, no shopper email address, and no free-text
delivery instruction. This has been the rule since the 2025 assessment. A record that contains
any of those is a finding regardless of how it got there, and client log lines are covered by
the same rule.
