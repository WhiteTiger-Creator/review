# LIMS recovery evidence rules

These rules are for comparing recovery classes after a test. They are not a recovery runbook and do not authorize a production failover.

## Test records

Use `restore_test_results.csv` as the event register. Keep rows whose `review_flag` is `retain`, preserve each `record_id`, and group events by `test_id`. A service-ready timestamp is a technical handoff to validation; it is not business acceptance.

For a test run, calculate restore elapsed time as:

`service_ready event_time_utc - incident_start event_time_utc`

Do not add milestone durations from separate records. The cold and warm exercises are different runs and must be reported separately.

Calculate the observed recovery-point interval for the warm exercise as:

`incident_start event_time_utc - latest_recoverable_backup event_time_utc`

Use the timestamp on the accepted backup-catalogue record. File creation time, vendor commentary, and the date of a later review meeting are not substitutes.

## Dependency acceptance

Join every row in `continuity_dependency_table.tsv` to its `result_record_id` in the restore register. Respect `sequence_order` and retain the predecessor chain. The acceptance numerator is the count of joined rows whose result is `PASS`; the denominator is every row marked `acceptance_required=yes`. A downstream pass does not erase an upstream failure.

Water Quality business acceptance requires all fifteen required jobs to pass. Continuity may approve an exercise only after the results and their lineage have been retained. IT owns the recovery service evidence and the dependency join. A meeting time or a planned retest is not closure proof.

## Time and release tests

The approved service targets are in `recovery_class_decision.eml`: service ready for validation within four hours and a recoverable backup no more than fifteen minutes before the incident. Use the Water Quality cutoff event in `restore_review_windows.ics` to test same-shift usefulness. Report both the service-ready timestamp and the margin before or after that cutoff.

## Commercial comparison

In `service_class_costs.tsv`, use only rows with `quote_status=accepted`. Annualize each line as:

`annual_recurring_cost + one_time_cost / amortization_years`

Sum the annualized lines separately by `service_class`. Keep each `cost_id` in the workpaper. A sensitivity case can describe a possible retest or delay, but a working scenario does not change an observed result.

## Evidence precedence

For service targets, funding ceiling, role ownership, and acceptance authority, the approved decision email controls over the later working ownership exchange. Operational notes and the status page can corroborate timestamps or identify an exception; they do not amend the approved rule. If two records disagree, state the disagreement and keep the lower-authority statement in lineage.

## Boundary

The decision paper may recommend a service class and annual funding level. It may not issue a purchase order, sign a contract, change laboratory release criteria, expose credentials, or direct a production recovery. Those actions remain in the authority's procurement, change-control, and laboratory procedures.
