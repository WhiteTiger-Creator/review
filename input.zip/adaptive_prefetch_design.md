# AdaptivePrefetch implementation notes

AdaptivePrefetch is a client-side read-ahead policy for EdgeKV. The existing
StaticWindow policy watches for sequential keys and, once triggered, asks for a
fixed 32-block window. The adaptive branch replaces that fixed distance with a
small state machine attached to each shard reader.

## State kept by the reader

The reader tracks the last 64 observed key deltas and folds them into sixteen
log-spaced stride buckets. It also keeps an exponentially weighted hit counter
for prefetched blocks. Every 1,024 completed gets, the policy estimates stride
entropy and useful-prefetch ratio. Low entropy plus a useful ratio above 0.7
allows the window to grow. High entropy, a low useful ratio, or a burst of
evictions cuts the window. Distances are bounded between 8 and 64 blocks; the
policy can also turn read-ahead off.

Growth is intentionally slower than shrinkage. One healthy interval moves from
8 to 16 or from 16 to 24, while two bad intervals can return a 64-block reader
to 16. We learned during the January soak that symmetric movement held an
oversized window for too long after a scan changed shape. That behavior was
especially visible on C-like cold-cache reads.

## Interaction with EdgeKV

The branch does not change request routing, the block cache, compaction policy,
or NVMe queue depth. Prefetch requests use the existing low-priority queue and
carry the same cancellation token as StaticWindow. A foreground miss may consume
a block that was already in flight, but it does not wait behind newly scheduled
read-ahead. The implementation meters outstanding bytes per reader rather than
per process, which prevents one long scan from spending the entire client
budget.

The scored binary was built from branch kv/adaptive-prefetch at commit
7d31c2e. Harness tag kv-ap-2026.03.2 records that build plus EdgeKV 4.8.1.
sol-kv-11 and sol-kv-12 used the same operating-system image and P5520 firmware.
The hardware inventory has other machines because it is a lab export; they did
not host the scored runs.

## Expected workload behavior

Update-heavy A tends to contain short stable read sequences around recently
written keys. It should benefit without keeping large windows open for long.
Read-mostly B usually has a reusable hot set, so throughput improvement is
expected to be smaller than A. Read-only C is less forgiving: a long miss train
can make the controller confident just as the cache is filling with speculative
blocks. D changes its hot region as new keys arrive, which should trigger more
frequent shrink decisions.

The design goal was not an eighteen-percent guarantee. Early A runs happened to
land near that number and became the basis of a slide title. The actual card
decision needs the active mix and tail rule.

## Known rough edges

The entropy estimate is updated in batches, so phase changes inside an interval
can be recognized late. Compaction can also distort the useful-prefetch ratio:
background reads compete for device time but do not enter the client hit
counter. The incomplete C adaptive run in the status log died during such an
overlap. Its emitted metrics should not be treated as a pessimistic sample; the
run simply did not meet the validity rule.

Memory use is bounded, but the original branch allocated the stride histogram
from an arena that was reclaimed only when a reader closed. That leak was fixed
before the scored tag. The block-size ablation was run after the main matrix to
check whether a larger request would solve the C tail. It did not provide a
clean reason to replace the default 4 KiB setting.

## What promotion would mean

Promotion changes the shared method card, not production configuration by
itself. Operators would still stage the card through the pilot process. A HOLD
leaves the branch available for investigation and keeps StaticWindow as the
documented default. The implementation team expects the workbook to identify
which workload and metric need work; it should not reinterpret the gate around
the design intent.
