# Locker credential reset workpaper rules

Use the packet cutoff of 2026-08-05. The inventory is a partition of the reviewed fleet, so every retained row enters the locker denominator once.

## Lineage and scope

1. Take the incident lineage codes from the approved directive and vendor image review.
2. Join those codes to `signing_key_lineage` in `locker_key_inventory.csv`.
3. Use `key_family_id` and the K-family values in `firmware_trust_list` to confirm which exposed family each joined row accepts.
4. Preserve rows whose `signing_key_lineage` contains neither incident code in the reviewed-fleet denominator, but do not count their devices as accepting exposed keys.

## Calculations

- Lockers reviewed = sum of `lockers_checked` for all 30 retained rows.
- Devices accepting exposed keys = sum of `accepting_devices` on rows joined to LIN-RC-24B or LIN-RC-25E.
- Key families reset = count of distinct `key_family_id` values produced by that join, splitting a pipe-delimited pair before counting.
- Customer doors requiring attended access = sum of `attended_doors` for all retained rows.
- Longest reset window = maximum `reset_window_minutes` among retained rows.

Do not round or substitute narrative estimates. A value is challenged at its row ID before a portfolio total changes.

## Authority and closure

`security_directive.rtf` controls this containment question because it is approved and effective-dated. Emails, field notes, and calendar events explain constraints; they do not create approval. Each family has its own owner, observable result, locker-linked proof, and exception disposition. A meeting or completed schedule row alone cannot close a wave.
