# Gate incident reconstruction notes

Finance and Technology agreed on this workpaper method after the event. It supplies calculation mechanics, not contract terms or a renewal decision.

## Normalize the clocks

Use each row's `clock_profile_id` to locate its calibration in `festival_assumption_limits.yaml`. Correct the local scanner time with that profile's base offset and 15-minute drift steps. Convert `cache_event_utc` to Central daylight time by subtracting five hours. A scanner/cache pair is usable when the absolute difference after both conversions is no more than the stated tolerance and its lineage state is accepted or corroborated.

## Establish the window

The causal start is the earliest usable row with a cache generation below the required generation, a failed used-badge control, and a positive non-permitted repeat-admission count. The end is the first later usable current-generation row where the unused-and-used control pair passes. Keep earlier help-desk symptoms and later vendor bridge timestamps in the chronology, but do not substitute either for the row test.

## Count impact

Include usable source rows from the start time up to, but not including, the end time. Sum `attempt_count`, `nonpermitted_repeat_admissions`, and `valid_badge_denials`. The repeat-admission field is already net of the permitted relationships documented in `attendee_asset_relationships.xml`. Grouping by `bucket_id` is a review aid; totals must still reconcile to source rows.

Use scanner attempts as the rate denominator. Compare that result with signed manual counts from `gate_volume_inputs.tsv`; a difference within the stated variance limit is corroboration, not a replacement denominator.

Apply the signed contract record effective for this event to the computed duration and counts. Keep renewal separate from service-credit entitlement. Neither this workpaper nor a vendor bridge close authorizes a cache push, invoice posting, or contract signature.
