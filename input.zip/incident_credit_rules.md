# River Festival gate incident - reconciliation rules

Finance and Technology agreed to use the following method for the Saturday review. These rules describe the workpaper; they do not decide the renewal.

## Put the clocks on one line

Scanner timestamps are Central Daylight Time (`UTC-05:00`). Cache timestamps are UTC. Help-desk tickets use Central time unless a ticket says otherwise. Convert all three clocks to Central time and treat a scanner/cache pair as matched when the timestamps differ by no more than 90 seconds. Keep unmatched rows in lineage, but do not use their counts in the headline totals.

## Mark the incident window

The causal start is the earliest matched scanner row where `cache_state` is `stale_generation`, `control_result` is `fail`, and `used_badges_admitted_count` is greater than zero. The end is the first later matched row where the cache is on the current generation and the gate control result is `pass`. Count elapsed minutes from start to end; the end row is not part of the impact population.

For the impact totals, retain matched rows at or after the causal start and before the end. `confirmed` and `corroborated` are matched states. `unmatched` is not. The export's `used_badges_admitted_count` is the admission-ledger count after STAFF, VENDOR, and MEDIA roster matches are removed under attendee_asset_relationships.xml. Sum that field for duplicate admissions and `valid_badges_denied_count` for false denials. Use `scan_attempt_count` over the same retained rows as the denominator for any displayed rates. Round rates only after the numerator and denominator are aggregated.

## Apply the signed schedule

Use the executed service schedule, not a proposal or a working email, to select credit tiers. The availability, admission-integrity, and valid-access credits are cumulative when each threshold is met. The invoice holdback equals the cumulative signed credit until Finance posts the credit and Technology's correction evidence is accepted.

The sensitivity file is for challenge testing only. It may show what changes under a different clock or row treatment, but it does not replace the observed case.

## Keep the trail usable

Retain all 30 `BADG-` identifiers. Show which rows entered each sum, identify excluded rows and the reason, and reconcile per-gate scan attempts to `gate_volume_inputs.tsv`. A later informal timestamp does not displace an executed clause. A meeting date proves that a review occurred; it does not prove closure.

The executive committee decides renewal. Finance validates and applies the credit. Technology preserves event evidence and verifies the cache correction. This paper does not configure scanners, change cache settings, sign a renewal, or assign blame to an individual.
