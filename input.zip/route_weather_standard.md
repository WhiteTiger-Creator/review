# Route weather information service standard

**Status:** Approved  
**Effective:** 13 July 2026  
**Owner:** Marine Safety  
**Technology custodian:** Information Technology  
**Approval record:** ACFA-MSC-2026-07-13, item 4

## Purpose

This standard sets the management requirements for weather information delivered to the ferry route decision process. It does not prescribe the master's or duty officer's operating decision and does not replace the Marine Weather Operations Manual.

## Service design

The authority will maintain a primary forecast service and a reserve service. The reserve is intended to remain useful when the primary service or its upstream publisher is unavailable. For that reason, reserve acceptance requires evidence that its upstream forecast origin is independent of the primary for the routes in scope.

Two endpoints do not constitute independent services merely because they have different host names, dashboards, contracts, or terminal network paths. IT must retain the provider identity, product name, endpoint, upstream origin, and effective date for each role. If the origin cannot be established, the service may be tested but must not be represented as the approved independent reserve.

## Delivery evidence

Dispatch records the forecast receipt time at each sampled route decision and preserves the related route, terminal, and issue identifiers. IT maintains the timestamp basis, delivery monitor, origin mapping, and outage event record. Freshness is measured at the route decision, not at a later archive export or support-ticket timestamp.

Coverage reporting uses required and covered route decision points. A portfolio percentage does not close a missed route sample. Exceptions remain tied to the affected route and terminal until the responsible owner records the expected closure evidence.

During an outage review, the event record must show whether the primary and reserve shared an origin, which routes were affected, whether each endpoint delivered a fresh issue, and when delivery recovered. Endpoint reachability without a new issue time is not a successful reserve delivery.

## Ownership

Marine Safety owns the operational use of weather information and determines whether existing marine procedures need revision. Dispatch owns the accuracy of route observations and handoff notes. IT owns feed contracting, service monitoring, provider-to-product mapping, origin-dependency evidence, and technical exception records. Vendor Management coordinates commercial clarifications and signed supplier commitments. Finance validates recurring charges, one-time charges, invoices, and service credits.

No participant may use this standard, a review meeting, or a completed test as authority to sign a contract or change production. Those actions follow their existing approval processes.

## Review and renewal

The annual service review must include:

- the provider and product assigned to each feed role;
- a signed or otherwise accepted upstream-origin attestation;
- route-decision freshness and coverage evidence with retained source identifiers;
- common-origin outage records and recovery timing;
- open exception status, owner, and closure proof;
- annual recurring price, invoice reconciliation, one-time charges, and service credits.

IT presents the evidence package to the service sponsor. Marine Safety may accept the operating design while withholding a supplier or production decision where identity, dependency, or contract evidence is incomplete.

## Source precedence

This approved standard controls working notes, vendor statements, draft committee language, and calendar descriptions on the same subject. A later record changes this standard only if it carries the required approval, has taken effect, and addresses the same requirement. Observations that arrive later may extend the evidence history without changing the management rule.

## Exceptions

An exception record names the route, terminal, service role, owner, expected evidence, and review point. A calendar date alone is not closure. A workaround may remain operational under the appropriate marine process, but the service exception stays open until the recorded condition is met or the sponsor accepts a documented alternative.
