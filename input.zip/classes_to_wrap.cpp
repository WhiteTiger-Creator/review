#include"classes_to_wrap.h"

wrapped_class::wrapped_class(){
	m_value = -1;
}

wrapped_class::wrapped_class( const int value ) : m_value(value) {

}

void wrapped_class::set_value( const int value ){
	m_value = value;
}

int wrapped_class::get_value() const {
	return m_value;
}