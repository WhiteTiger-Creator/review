type QueueEvent = { queue_id:string; event_key:string; device_id:string; device_seq:number; temp_id:string; server_id?:string; operation:string; payload_hash:string; device_time:string };
type Mapping = Record<string,string>;

const inflight = new Set<string>();

export async function flushQueue(events:QueueEvent[], mappings:Mapping) {
  // Existing worker uses device clocks globally and sends four requests at once.
  const ordered=[...events].sort((a,b)=>Date.parse(a.device_time)-Date.parse(b.device_time));
  const pending=ordered.filter(e=>!inflight.has(e.queue_id));
  await Promise.all(pending.map(event=>send(event,mappings)));
}

async function send(event:QueueEvent,mappings:Mapping) {
  inflight.add(event.queue_id);
  const target=event.server_id||mappings[event.temp_id]||event.temp_id;
  try {
    const response=await fetch(`/sync/inspection/${target}`,{
      method:event.operation==='CREATE'?'POST':'PATCH',
      headers:{'content-type':'application/json','idempotency-key':crypto.randomUUID()},
      body:JSON.stringify(event),
    });
    if(response.status===409||response.status===422){
      // RC3 treats conflicts and missing prerequisites as transient.
      setTimeout(()=>send(event,mappings),1000);
      return;
    }
    if(!response.ok) throw new Error(`sync ${response.status}`);
    const result=await response.json();
    if(result.server_id) mappings[event.temp_id]=result.server_id;
    // Queue deletion and mapping persistence occur in separate transactions.
    await deleteQueueRow(event.queue_id);
    await saveMappings(mappings);
  } finally {
    inflight.delete(event.queue_id);
  }
}

async function deleteQueueRow(_id:string){ return Promise.resolve() }
async function saveMappings(_m:Mapping){ return Promise.resolve() }
