# Northline Logistics, Olathe distribution center
## Roof drainage design basis and original calculation summary

Compiled by Alder Ridge Engineering from the 2018 permit set and the design
engineer's calculation package, both provided by Northline. Building completed
and occupied October 2019.

### The roof

Single ply TPO membrane, mechanically attached, over polyisocyanurate insulation
on a steel roof deck carried by open web steel joists spanning 40 feet at 6 feet
on centre. Total roof area 342,200 square feet, divided into six drainage
zones. Each zone drains to roof drains at the low points of a tapered insulation
system sloped at a quarter inch per foot, with through wall overflow scuppers at
the parapet as the secondary system.

All roof drains are the same model, an eight inch cast iron roof drain with a
dome strainer. All scuppers are type SC-1, twenty four inches wide by four
inches high. The design sets every overflow scupper invert 0.25 feet,
which is three inches, above the drain rim elevation of the zone it serves. That
three inches is the head the primary drains were sized on.

### Criteria the design was run against

The governing criterion is the 100 year, one hour rainfall intensity for Johnson
County, Kansas, which is 3.9 inches per hour. The primary system is sized for
that intensity. The secondary system is sized independently for the same
intensity on the assumption that the primary system is completely blocked.

Flow is converted from area and intensity as Q in gallons per minute equals the
tributary area in square feet multiplied by the intensity in inches per hour
multiplied by 0.0104.

Where a return period has to be estimated from a gauge record, use the Weibull
plotting position: for a record of n years, the event ranked m from the largest
has a return period of (n + 1) divided by m.

### Original drainage calculation, as found in the design package

The calculation sheet gives, zone by zone, the intensity the designer entered:

  * Zone A: 68,400 sf, intensity 3.9 in/hr, required 2,774.3 gpm, 6 roof drains at 500 gpm each = 3,000 gpm, 5 scuppers
  * Zone B: 54,200 sf, intensity 3.9 in/hr, required 2,198.4 gpm, 5 roof drains at 500 gpm each = 2,500 gpm, 4 scuppers
  * Zone C: 61,800 sf, intensity 3.9 in/hr, required 2,506.6 gpm, 6 roof drains at 500 gpm each = 3,000 gpm, 5 scuppers
  * Zone D: 47,300 sf, intensity 3.9 in/hr, required 1,918.5 gpm, 4 roof drains at 500 gpm each = 2,000 gpm, 4 scuppers
  * Zone E: 58,900 sf, intensity 2.7 in/hr, required 1,653.9 gpm, 4 roof drains at 500 gpm each = 2,000 gpm, 4 scuppers
  * Zone F: 51,600 sf, intensity 3.9 in/hr, required 2,092.9 gpm, 5 roof drains at 500 gpm each = 2,500 gpm, 4 scuppers

The intensity column is reproduced here exactly as it appears on the sheet. We
have not altered it.

### Design elevations

Drain rim elevations are on the project datum, where 100.00 feet is the finished
roof surface at the northwest control point. Zone A 100.00, Zone B 100.34,
Zone C 99.86, Zone D 100.52, Zone E 100.08, Zone F 100.27. Every scupper invert
is drawn at the zone drain rim elevation plus 0.25 feet. Construction tolerance
on a drain rim in the specification is plus or minus half an inch.

### Structural capacity for ponded water

The joists were designed for a 30 pound per square foot ground snow load and a
rain load taken as three inches of water over the drain, which is 15.6 pounds
per square foot at 5.2 pounds per square foot per inch of depth. The original
calculations show the governing joist at 92 percent of its allowable bending
capacity under that combination. Alder Ridge has run the reserve and the joists
will accept an additional 4.0 pounds per square foot of ponded water and no
more. That is the number that constrains any remedy that would raise the water
line on this roof.

### What is not in the design package

There is no ponding stability check in the package, which the code of the day
required for roofs sloped less than a quarter inch per foot and which this roof
is not, so its absence is not itself a deficiency. There is no record of a
deflection survey at any point in the building's life.
