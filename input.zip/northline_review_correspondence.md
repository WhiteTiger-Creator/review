# ECN-26-047 comment resolution thread

**From:** Mira Solano, PE, rotating equipment  
**To:** Eli Mercer, maintenance engineering; Dana Kline, electrical lead; Joelle Park, documentation  
**Sent:** 2026-07-17 08:14 ET  
**Subject:** Rev C field copy: five comments still open

Joelle, use the signed change notice as the control. The marked-up field copy from June is useful for finding where the crew hesitated, but it is not another authority layer. Please close these points before the instruction goes into the register.

Comment 14: call the base materials by name. P-201A, P-201B, and P-203A are the steel group. P-202A, P-202B, and P-203B are the GFRP group. Do not say “A trains” or “B trains”; that shortcut is wrong for P-203. The GFRP stack uses the SPW-8 pair beneath the bolt head, convex washer against the head and concave washer against the plate. PTN-8 nut is below. No TL-243 on those three.

Comment 22: the drain at the transmitter end is cut back and sleeved. Cabinet end remains bonded. Dana confirmed the greater-than-1-megohm device-end isolation check can be done before the loop is energized. The old two-ended shield paragraph cannot survive as a note or alternate.

Comment 31: leave P-204A and P-204B out altogether except for one clear exclusion in applicability. Crews should not see a parts table or step that appears usable on those trains.

Comment 37: do not write an automatic “put the old unit back” branch. We have two removed units with wet glands and one with an unstable zero. If installation stops, preserve the condition and call maintenance engineering. The old unit only goes back under separate written direction after inspection.

Comment 41: keep the four hold points visible. HP-2 is before wiring, and HP-3 is before guard installation. The crew moved those checks together in the first trial, which hid the reversed washer pair until teardown.

Mira

---

**From:** Dana Kline, electrical lead  
**To:** Mira Solano; Eli Mercer; Joelle Park  
**Sent:** 2026-07-17 11:46 ET  
**Subject:** RE: Rev C field copy: five comments still open

Electrical wording is confirmed with one addition. The installed field cable at these six trains is white, black, and bare drain. Red only appears in the legacy section because the original cable was replaced in 2024. White lands on terminal 1 and black on terminal 2. Fit the VT8 ferrules from the kit; do not reuse the old ferrules. Keep the 3.92-4.08 mA and 19.88-20.12 mA limits exactly as Mira issued them.

For the temporary loop check, say that the lock is cleared only for that check and is reapplied before the guard work. We had one person read “energize for loop check” as permission to leave the train available. It is not. The start permissive remains inhibited until the guard and HP-3 are complete.

Dana


---

**From:** Eli Mercer, maintenance engineering  
**To:** Joelle Park  
**Cc:** Mira Solano; Dana Kline  
**Sent:** 2026-07-18 15:22 ET  
**Subject:** ECN-26-047 Rev C released

Revision C is signed and effective at 17:00 ET today. The trial log still includes early setups that are no longer allowed; keep those observations as engineering evidence, not as alternate steps. A released crew copy needs the asset split, the two fastener methods, the four hold points, the guarded three-reading comparison, and the full work-order record list. Put the instruction revision in the footer and leave the approver/signature blocks empty for document control to complete in the controlled system.

We are not authorizing any work by email. The supervisor still opens each asset work order and operations still controls the train release.

Eli
