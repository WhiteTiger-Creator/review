# OMM-EIP-17, Section 7.4: Bearing-housing vibration transmitter service

**Facility issue:** 2019-11  
**Equipment family:** East Intake vertical turbine pumps P-201 through P-204  
**Applies to installed VX-210 transmitters**  
**Document custodian:** Northline Water Authority maintenance planning

## Equipment identification

Each pump train has one vibration transmitter on the outboard bearing housing. The transmitter cable routes to JB-21 on the north side of the train and then to vibration monitor VM-4 in the east control cabinet. Train identity is stamped on the local disconnect placard, the bearing-housing tag, and the JB-21 nameplate. If the three identifiers do not agree, stop and have planning correct the work order before parts are removed.

P-201A and P-201B occupy Bays 1 and 2. P-202A and P-202B occupy Bays 3 and 4. P-203A and P-203B occupy Bays 5 and 6. P-204A and P-204B occupy Bays 7 and 8. Normal start and return-to-service authority remains with the shift operator assigned to the east intake desk.

## Work preparation

Open the maintenance work order against the individual asset. Record the installed transmitter serial number and take a photograph that shows both the transmitter and bearing-housing tag. Obtain permission from the east intake shift operator before applying the local disconnect lock. Use the site's current hazardous-energy procedure for the local disconnect and pump isolation. The control-room stop indication is an operating indication only and is not an electrical test.

Inspect the coupling guard, JB-21 cover, field cable, and transmitter cable entry before disturbance. Add pre-existing damage to the work order. Do not continue when the field cable jacket is cut through, the junction-box cover will not seat, or the bearing-housing tag is unreadable. Planning supplies a corrected job package after asset identity or cable condition is resolved.

The service kit for the VX-210 includes a cast saddle, two zinc-plated M8 bolts, split lock washers, a flat neoprene pad, and a straight cable-entry seal. Parts from different service-kit issues may not be mixed because saddle thickness changed during the original station construction.

## Removal

After the electrical worker verifies zero energy, mark the red conductor, black conductor, and bare drain before disconnecting them at the transmitter. Keep the bare drain separated from the two insulated conductors. Loosen the cable gland and withdraw the cable without twisting it. Cover the cable end while mechanical work is in progress.

Support the transmitter by hand while removing the two saddle bolts. Retain the transmitter for the work-order record. Remove the old neoprene pad and scrape loose material with a plastic tool. Do not use a powered wire wheel near the bearing seal. Wipe the mounting surface dry and inspect the two holes. Surface rust that can be removed with a cloth is acceptable; deep scale, an elongated hole, or damaged threads requires maintenance-engineering direction.

## VX-210 installation method

Place the flat neoprene pad over the existing holes and place the cast saddle on the pad. Install the two zinc-plated bolts with one split lock washer beneath each head. Tighten both bolts alternately to 18 N·m. The 2019 instruction applies the same final torque to every train because the station drawing set showed steel mounting plates at all eight locations.

Set the transmitter with its connector facing the junction box. Route the cable along the shortest path that clears the coupling guard. The manual does not define an angular tolerance for the cable entry. A clearance check is made visually with the guard temporarily held in place.

Install the straight cable-entry seal with the flat lip against the transmitter. Tighten the gland until the cable does not slide when pulled lightly. Do not apply sealing compound to the gland threads.

## VX-210 conductor and shield connections

Connect the red conductor to transmitter terminal 1 and the black conductor to transmitter terminal 2. Twist the bare drain into one lead and land it on the transmitter grounding screw. Confirm that the drain is also bonded at the VM-4 control-cabinet ground bar. This two-ended shield connection matched the original station wiring diagram.

At JB-21, keep the conductor bend inside the terminal channel. Refit the cover gasket and tighten each cover screw until the cover is uniformly seated. The cover may not be left hanging from its ground strap during a run.

Restore loop power for a functional check. The historical field check accepted a zero point from 3.8 through 4.2 mA and a full-scale point from 19.7 through 20.3 mA. Record both values on the work order. If either current falls outside the range, inspect the conductor polarity and cable connection before replacing the transmitter.

## Return to service

Reinstall the coupling guard with all original fasteners. Check that the cable does not touch the guard at rest. Remove tools and loose material from the base. The electrical worker closes JB-21, and the maintenance supervisor verifies the work area before the shift operator clears the start permissive.

Start the pump through the normal station sequence. After five minutes, compare the control-room vibration indication with one handheld reading at the outboard bearing. Historical acceptance was a difference of no more than 0.5 mm/s. A larger difference required a second handheld reading and inspection of the mounting bolts.

When readings are acceptable, record the new transmitter serial number, loop values, mounting-bolt torque, and final operating indication. Attach the pre-work and post-work photographs to the work order. Return the removed transmitter to the instrument shop with the asset number on the tag.

## Maintenance note added 2025-02-06

Three trains received nonmetallic adapter plates during the 2025 bearing-seal project, but this section was not revised at that time. Check current engineering direction before applying the 18 N·m mounting value on a nonmetallic plate. The adapter-plate work order is NW-25-1186. No change to the conductor or shield paragraphs was issued with this note.

## Records retained by planning

Planning retains the closed work order, loop-check entry, transmitter serial number, and photographs under the individual asset. The shift log records the time the pump was released and the first control-room vibration value. Instrument-shop findings are filed against the removed transmitter serial number rather than the pump train.
