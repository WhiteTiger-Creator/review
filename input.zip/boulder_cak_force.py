"""
boulder_cak_force.py -- reference modified-CAK line-force module.

Direct Python port of the PLUTO modified-CAK source that the Boulder group
runs for their hot-star wind test case.  Kept close to the C so the physics
and the known review concerns carry over.  This is a reference implementation,
not a finished library: several review items below are intentionally left as
they are in production so a reviewer / integrator can find and fix them.

API (mirrors the C):
    load_parameters(...)   -> dict of force parameters
    minmod(a, b)           -> monotonic slope limiter
    radial_gradient(...)   -> radial velocity gradient at a grid point
    theta_gradient(...)    -> latitudinal gradient (2-D rotating runs)
    line_force(params, r_cgs, rho_cgs, dvds_cgs)   -> g_line [cm/s^2]
    compute_force(...)     -> apply the source term to a 1-D sweep

All code-unit constants come from definitions.h.
"""

# ---------------------------------------------------------------------------
# Code units (from definitions.h / unit_normalization.md)
# ---------------------------------------------------------------------------
UNIT_LENGTH    = 6.957e11      # cm  == R_star
UNIT_DENSITY   = 1.0e-13       # g/cm^3
UNIT_VELOCITY  = 1.0e8         # cm/s
UNIT_TIME      = UNIT_LENGTH / UNIT_VELOCITY   # s
UNIT_PRESSURE  = UNIT_DENSITY * UNIT_VELOCITY ** 2
ACCELERATION_UNIT = UNIT_LENGTH / (UNIT_TIME * UNIT_TIME)

GRAV_CONST_CGS = 6.67430e-8
CLIGHT_CGS     = 2.99792458e10
SIGMA_E_CGS    = 0.34          # electron-scattering opacity [cm^2/g]

# Floors / switches (see definitions.h)
CAK_DVDR_FLOOR_CGS = 1.0e-12
CAK_RHO_FLOOR_CGS  = 1.0e-30

DEFAULT_PARAMS = {
    "RSTAR_CGS": 6.957e11,
    "MSTAR_CGS": 3.98e34,
    "LSTAR_CGS": 1.0e39,
    "TEFF_K":    40000.0,
    "RHO0_CGS":  1.0e-13,
    "VIN_BASE_CGS": 2.0e6,
    "CSOUND_CGS": 2.0e7,
    "VINFINITY_CGS": 3.0e8,
    "BETA_VLAW": 1.0,
    "WROT": 0.0,
    "CAK_ALPHA": 0.60,
    "CAK_K": 0.30,
    "CAK_QBAR": 1.0,
    "GAMMA_E": 0.20,
    "FD_CORRECTION": 1.0,
    "USE_THETA_GRADIENT": 0.0,
    "DVDS_FLOOR_CGS": CAK_DVDR_FLOOR_CGS,
    "FORCE_TAPER_WIDTH": 0.05,
}


def minmod(a, b):
    if a * b <= 0.0:
        return 0.0
    return a if abs(a) < abs(b) else b


def radial_gradient(v_code, x_code, i):
    """Minmod radial gradient of the radial velocity at cell index i."""
    drm = x_code[i] - x_code[i - 1]
    drp = x_code[i + 1] - x_code[i]
    gm = (v_code[i] - v_code[i - 1]) / drm
    gp = (v_code[i + 1] - v_code[i]) / drp
    return minmod(gm, gp)


def _theta_gradient(vt_code, r_code, theta_code, j):
    """Minmod latitudinal gradient (only used in 2-D rotating runs)."""
    dthm = theta_code[j] - theta_code[j - 1]
    dthp = theta_code[j + 1] - theta_code[j]
    gm = (vt_code[j] - vt_code[j - 1]) / (r_code * dthm)
    gp = (vt_code[j + 1] - vt_code[j]) / (r_code * dthp)
    return minmod(gm, gp)


def line_force(params, r_cgs, rho_cgs, dvds_cgs):
    """Return g_line [cm/s^2] for the given flow point.

    g_line = gamma_e * G M / r^2 * CAK_K * (QBAR * dvds / rho)^alpha

    Reproduces cak_force.c.  Callers handle the geometry: dvds is the total
    (radial + optional theta) velocity gradient passed in code units.
    """
    alpha = params["CAK_ALPHA"]
    kcak = params["CAK_K"]
    qbar = params["CAK_QBAR"]
    gamma_e = params["GAMMA_E"]
    taper_width = params["FORCE_TAPER_WIDTH"]
    r_code = r_cgs / UNIT_LENGTH

    ge_cgs = gamma_e * GRAV_CONST_CGS * params["MSTAR_CGS"] / (r_cgs * r_cgs)
    # PLUTO implementation uses parameter CAK_ALPHA on the optical depth bracket
    gline_cgs = ge_cgs * kcak * pow(qbar * dvds_cgs / rho_cgs, alpha)

    # Near-surface taper used in the PLUTO setup.
    taper = 1.0
    if r_code < 1.0 + taper_width:
        taper = (r_code - 1.0) / taper_width
        if taper < 0.0:
            taper = 0.0
    gline_cgs *= taper
    return gline_cgs


def compute_force(rho_code, vx_code, x_code, params, rho_floor=None,
                  dvdr_floor=None, use_theta_gradient=0.0, theta_code=None,
                  vt_code=None):
    """Apply the modified-CAK source term to a 1-D radial sweep.

    Mirrors CAK_ComputeLineForce: converts cgs, floors the gradient and
    density, applies the taper, and returns the per-cell acceleration rhs
    (code units).

    REVIEW CONCERNS carried over from the C implementation:
      * conversion & floor are applied AFTER summing radial + theta so a
        negative theta contribution can hide the radial acceleration near base
      * the cgs->code conversion uses UNIT_VELOCITY/UNIT_TIME here instead of
        the named ACCELERATION_UNIT (algebraically equal only when
        UNIT_TIME = UNIT_LENGTH/UNIT_VELOCITY)
      * rho below CAK_RHO_FLOOR_CGS is floored to the floor, then re-passed
    """
    dvdr_floor = CAK_DVDR_FLOOR_CGS if dvdr_floor is None else dvdr_floor
    rho_floor = CAK_RHO_FLOOR_CGS if rho_floor is None else rho_floor

    n = len(vx_code)
    rhs = [0.0] * n
    for i in range(1, n - 1):
        rho_cgs = rho_code[i] * UNIT_DENSITY
        r_cgs = x_code[i] * UNIT_LENGTH

        dvds_code = radial_gradient(vx_code, x_code, i)
        if use_theta_gradient > 0.5:
            dvds_code += _theta_gradient(vt_code, x_code[i], theta_code, 0)

        # ---- known review concern: floor applied after the sum ----
        dvds_cgs = dvds_code / UNIT_TIME
        if dvds_cgs < dvdr_floor:
            dvds_cgs = dvdr_floor
        if rho_cgs < rho_floor:
            rho_cgs = rho_floor

        gline_cgs = line_force(params, r_cgs, rho_cgs, dvds_cgs)

        # ---- known review concern: UNIT_VELOCITY/UNIT_TIME vs ACCELERATION_UNIT ----
        gline_code = gline_cgs / (UNIT_VELOCITY / UNIT_TIME)
        rhs[i] = rho_code[i] * gline_code
    return rhs


if __name__ == "__main__":
    # self-test over a simple beta-law flow so the module is runnable as-is
    import math
    p = dict(DEFAULT_PARAMS)
    x = [1.0 + 0.02 * i for i in range(201)]
    v = [p["VIN_BASE_CGS"] + p["VINFINITY_CGS"] * (1.0 - 1.0 / r) ** p["BETA_VLAW"]
         for r in x]
    rho = [p["RHO0_CGS"] / (r * r * max(vv, 1.0)) for r, vv in zip(x, v)]
    rhs = compute_force(
        [r / UNIT_DENSITY for r in rho],
        [vv / UNIT_VELOCITY for vv in v],
        x, p)
    print("line force self-test OK; max rhs =", max(rhs))
