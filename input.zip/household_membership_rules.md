# Audience identity and household boundary rules

Owner: Audience Data Governance  
Approved: 2026-04-30  
Rehearsal cutoff used by this packet: 2026-07-21

These rules govern the conversion of print-circulation subscribers and digital audience profiles into the shared audience platform. They distinguish a person identity from a household relationship and distinguish contact provenance from newsletter permission. A match-export row is evidence that two records should be evaluated; it is never, by itself, authority to combine them.

## ID-01 — Unordered candidate identity

Candidate edges are unordered. The pair L441 and D9021 is the same candidate as D9021 and L441, and repeated exports of the same orientation do not create additional decisions. The conversion must form a stable pair key from the lower and higher source identifiers, retain every contributing edge identifier for audit, and issue one disposition for that pair. If contributing edges carry inconsistent relationship hints, the pair cannot be automatically merged.

## ID-02 — Match hints and entity meaning

SAME_PERSON means that the matching process found person-level evidence, such as a subscriber self-link token. It is still subject to billing authority, suppression, and refund ownership checks. HOUSEHOLD_ONLY means the records represent different people who may share delivery or residence information. A shared postal address, surname, device, or payment instrument cannot promote HOUSEHOLD_ONLY to SAME_PERSON. Do not create a fuzzy threshold that is not present in the source packet.

## ID-03 — Automatic person-merge boundary

A normalized pair may receive AUTO_MERGE only when all of the following are true on the rehearsal cutoff: every contributing edge agrees on SAME_PERSON; both source profiles have one current billing-authority row; the current billing party identifier is identical on both sides; neither profile has an active IDENTITY_MERGE suppression; and neither profile is attached to an open refund case whose issue is OWNER_DISPUTE. A missing or conflicting billing party identifier routes the pair to manual review. A nonownership delivery credit does not block an otherwise eligible merge.

Pairs that fail an automatic condition are not discarded. They must receive an exclusion, household-link, or manual-review disposition with a reason code that identifies the controlling evidence.

## HH-04 — Household relationship without person consolidation

A pair whose consistent hint is HOUSEHOLD_ONLY may create one audience_household_link row after active identity-merge suppressions are checked. Each source identity remains a separate person. The household link keeps both source references, uses relationship_type SHARED_DELIVERY_ADDRESS, and records the contributing edge identifiers. It must not create an audience_identity_xref that points the two sources to one person identifier.

Household linkage is not allowed to bypass an active IDENTITY_MERGE suppression. A suppressed household pair belongs in the exclusion output so the case owner can decide whether even the relationship is appropriate.

## BILL-05 — Name and postal provenance

For an automatic person merge, the current bill-to party is authoritative for billing name and postal address. Current means authority_state CURRENT, effective_from on or before the cutoff, and effective_to blank or after the cutoff. PROPOSED and EXPIRED ledger rows do not control the load. Both source profiles must resolve to the same current billing_party_id for automatic processing.

The target billing name and address must come from that current ledger row. The source record used for the winning value is retained as billing_ledger_id. A more recently edited web address does not supersede the billing ledger, and a delivery address does not establish person identity.

## CONSENT-06 — Newsletter email and permission

Newsletter state is evaluated independently from billing authority. Consider only explicit OPT_IN and OPT_OUT events belonging to either source identifier in an automatic pair. Select the event with the latest event_at; if timestamps tie, use the lexically greatest event_id as the deterministic tie breaker. The selected event supplies newsletter_email, newsletter_allowed, consent_event_id, and consent_event_at. OPT_IN produces newsletter_allowed true. OPT_OUT produces false.

Delivery, open, bounce, and profile-correction events are not consent instructions. A later DELIVERED or OPEN event cannot reverse an earlier OPT_OUT. The audience person may retain an email with newsletter_allowed false because service identity and marketing permission are separate fields. If an automatic pair has no explicit consent event, leave newsletter_email null and newsletter_allowed false; do not borrow the login email.

## SUP-07 — Scoped suppression

An exclusion applies when either profile in a pair has a suppression whose scope is IDENTITY_MERGE, whose effective_from is on or before the cutoff, and whose effective_to is blank or after the cutoff. Preserve suppression_id and reason_code in the exclusion output. An expired suppression is historical context only. NEWSLETTER_SEND and DATA_SALE_EXPORT suppressions remain valid for those domains but do not independently block the identity conversion.

Suppression is evaluated before automatic merge, household link, or manual review. A suppressed pair receives EXCLUDE_SUPPRESSION even if all other evidence would allow a write.

## REF-08 — Refund ownership cases

An open case with issue OWNER_DISPUTE attached to either source profile requires MANUAL_REFUND_OWNERSHIP. OPEN and INVESTIGATING are open states; RESOLVED, DENIED, and CLOSED are not. Cases for DELIVERY_CREDIT, VACATION_CREDIT, or duplicate-payment research do not determine person ownership and therefore do not block an otherwise eligible pair. Preserve the controlling case identifier in the manual-review row.

## PROV-09 — Cross-reference and attribute audit

Each automatic merge produces one audience person and two audience_identity_xref rows, one for each source identifier. The target person key must be deterministic from the normalized pair key so a rerun does not create another person. Attribute provenance is stored separately: billing name and postal fields cite the current billing ledger record; newsletter email and permission cite the selected explicit consent event. The original profile references must remain queryable after the load.

## QA-10 — Rehearsal completion

The rehearsal is acceptable only when each normalized pair has exactly one disposition; no excluded, household-only, or manual-review profile appears in an automatic identity cross-reference; every automatic pair has exactly two source cross-references; no source reference maps to more than one audience person; each billing attribute cites a current ledger row; each nonnull newsletter attribute cites the selected explicit consent event; and the four disposition outputs reconcile to the normalized candidate population. Assertions should return violation counts, with zero as the passing value.
