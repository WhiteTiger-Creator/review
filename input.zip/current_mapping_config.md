# Kessler Claims Exchange - 837P outbound mapping configuration
# Owner: EDI Mapping. Applies to all payers unless a payer-specific branch is noted.

## Diagnosis qualifier (HI segment)

Claims originated in the legacy submission form emit qualifier BK for the principal diagnosis. Claims
originated in the current submission form emit ABK. The legacy code path was never updated when the
national qualifier withdrew BK; it still runs for any claim whose source_system is LEGACY_FORM,
regardless of which payer the claim is going to.

## Referral number (REF*9F)

Populated whenever the claim's referral indicator is Y, for any payer. The value is passed through as
the raw digits captured at intake, with no format transformation. There is no payer-specific branch
for this element.

## Line item control number (REF*6R)

Not implemented. No code path in the current mapping populates this element for any claim, to any
payer.

## Paperwork segment (PWK)

Populated whenever the claim record has supplemental records attached (has_supplemental_records = Y),
for any payer. There is no payer-specific suppression logic.

## Billing provider tax identification (REF*EI)

Always sourced from the provider's default_tax_id in the provider roster. There is no lookup against
provider_payer_tax_id_overrides.csv; the override table exists but nothing in the mapping reads it.

## Change history

2025-11-02: added has_supplemental_records flag to intake capture, wired to PWK population.
2025-08-14: referral capture added ahead of the Voss onboarding request; format review was deferred.
2023-01-01: legacy submission form frozen; current submission form introduced. Diagnosis qualifier
logic was written once for the current form and never backported to the legacy path.
