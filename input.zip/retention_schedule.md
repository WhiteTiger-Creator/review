# Dunphy Electric Membership Corporation - Records Retention Schedule

Owner: Records and Information Governance
Approved: 2026-01-12
Applies to: customer interval consumption data and its dependent billing determinants

## 1. Retention classes

| Class | Records | Minimum retention | Authority |
|---|---|---|---|
| R-1 | Interval consumption reads | 36 months from the read timestamp | Board records policy 4.2 |
| R-2 | Billing determinants derived from R-1 | 7 years from the bill date | State tax and tariff rules |
| R-3 | Assistance program participation and the reads supporting it | 7 years from the end of the program year | State assistance program rule 860-021-0430 |
| R-4 | Net metering interconnection and generation reads | 10 years from interconnection | Interconnection agreement, standard form |
| R-5 | Medical baseline enrollment and supporting reads | Duration of enrollment plus 3 years | Commission order 22-114 |

An account may fall in more than one class. Where classes disagree, the longest retention governs. A
class is not satisfied by keeping a summary; the underlying reads are the record.

## 2. Legal holds

A legal hold suspends every purge rule for the records in its scope for as long as the hold is active,
without exception and regardless of any retention minimum having already elapsed. A hold may be scoped
to a list of accounts or to an account attribute; an attribute-scoped hold covers every account that
carries the attribute on the day the purge runs, not only those that carried it when the hold issued.

When a hold is released, the schedule resumes from the release date. Release of one hold has no effect
on any other hold that still covers the same records.

## 3. Billing disputes

Records supporting a disputed bill are retained until the dispute is closed and for twelve months
afterward. An open dispute is recorded on the account, not in the hold register.

## 4. Purge execution

Purges run quarterly. A purge may only remove records that satisfy every applicable minimum in section
1 and are not within the scope of any active hold under section 2 or any open dispute under section 3.
Partitioned tables are purged by partition only when the entire partition falls outside every
applicable minimum. A partition containing a single retained read is not eligible for partition drop.
