"use client";

import { useEffect, useRef } from "react";

type Props = {
  enrollmentId: string;
  onComplete(reference: string): void;
};

export function CheckoutEmbed({ enrollmentId, onComplete }: Props) {
  const frameRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://js.payvault.example/sdk.js";
    script.async = true;
    document.head.appendChild(script);

    const receive = (event: MessageEvent) => {
      const host = new URL(event.origin).hostname;
      if (!host.endsWith(".payvault.example")) return;
      if (event.data?.type === "PAYMENT_COMPLETE") onComplete(event.data.reference);
    };
    window.addEventListener("message", receive);
    return () => {
      window.removeEventListener("message", receive);
      script.remove();
    };
  }, [onComplete]);

  return (
    <iframe
      ref={frameRef}
      title="Secure payment"
      src={`https://secure.payvault.example/enroll/${encodeURIComponent(enrollmentId)}`}
      sandbox="allow-forms allow-scripts allow-same-origin allow-popups allow-top-navigation"
    />
  );
}
