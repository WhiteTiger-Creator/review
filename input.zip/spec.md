The implementation must read telemetry snapshots from:

`/app/data/cars/`

The program must be implemented at:

`/app/validate_cars.py`

It must accept exactly two date arguments:

`python /app/validate_cars.py <start_date YYYY-MM-DD> <end_date YYYY-MM-DD>`

The requested date range is inclusive.

For missing or invalid arguments, exit with a non-zero status and print a
clear error message to stdout.

If either date argument is invalid, the output must contain the exact
substring:

`Invalid date format`

If the start date is later than the end date, exit with a non-zero status and
print an appropriate invalid-range error to stdout.

The implementation must create the following directory if it does not
already exist:

`/app/output/`

The final report must be written to:

`/app/output/validation_report.pdf`

The implementation must not require any additional command-line arguments.


FILE DISCOVERY AND FILENAME VALIDATION
======================================

Only files whose names exactly match:

`^car_([A-Za-z0-9]+)_(\d{4}-\d{2}-\d{2})\.csv$`

may be processed.

The filename must therefore contain:

- the literal prefix `car_`;
- a non-empty alphanumeric `brand_id`;
- an underscore separating the brand ID and date;
- a date in `YYYY-MM-DD` format;
- the `.csv` extension.

The first regex capture group is the authoritative `brand_id`.

The second regex capture group is the authoritative file date.

The captured date must additionally be validated as a real calendar date.

For example, `2026-02-31` is invalid even though it matches the regular
expression.

Files that do not match the naming convention must be ignored completely.

Files with syntactically matching but invalid calendar dates must also be
ignored completely.

Do not infer brands from invalid filenames.

Only brands extracted from valid filenames may appear in the final report.

Brand IDs must be processed independently.

Filesystem traversal order must never affect the result.


DATE RANGE AND MISSING FILES
============================

The requested date range is the inclusive range between the two command-line
dates.

Use calendar-aware date arithmetic when enumerating dates.

For every discovered brand, expect one telemetry file for every calendar
date in the requested inclusive range.

If a valid expected file does not exist for a brand/date combination, record
that date in that brand's `missing_files` list.

Only existing telemetry files within the requested date range appear under
`files`.

Missing daily files appear only in `missing_files`.

A missing file must not be treated as a telemetry snapshot containing
missing metrics.

A missing file must not be processed for duplicate, unexpected-metric, or
anomaly detection.


EXPECTED TELEMETRY METRICS
==========================

Each valid telemetry file contains:

`metric,value`

The implementation expects exactly 100 telemetry metrics.

The expected metrics, in fixed order, are:

```text
speed
fuel_efficiency
braking_distance
acceleration
engine_temp
tire_pressure
oil_level
battery_voltage
gearbox_temp
emissions
engine_rpm
engine_load
throttle_position
coolant_level
coolant_pressure
oil_pressure
oil_temp
intake_air_temp
intake_manifold_pressure
mass_air_flow
fuel_pressure
fuel_level
fuel_consumption_rate
air_fuel_ratio
lambda_sensor
catalytic_converter_temp
exhaust_gas_temp
exhaust_flow_rate
co2_output
nox_output
particulate_matter
oxygen_sensor_voltage
transmission_oil_temp
transmission_pressure
clutch_temperature
clutch_wear
brake_fluid_level
brake_fluid_temp
brake_pressure
front_left_brake_temp
front_right_brake_temp
rear_left_brake_temp
rear_right_brake_temp
front_left_tire_pressure
front_right_tire_pressure
rear_left_tire_pressure
rear_right_tire_pressure
front_left_tire_temp
front_right_tire_temp
rear_left_tire_temp
rear_right_tire_temp
steering_angle
steering_torque
yaw_rate
lateral_acceleration
longitudinal_acceleration
vertical_acceleration
vehicle_pitch
vehicle_roll
wheel_speed_fl
wheel_speed_fr
wheel_speed_rl
wheel_speed_rr
odometer
trip_distance
engine_runtime
idle_time
battery_current
alternator_voltage
battery_state_of_charge
battery_state_of_health
generator_load
ambient_temperature
cabin_temperature
hvac_load
ac_refrigerant_pressure
outside_air_pressure
barometric_pressure
turbocharger_pressure
turbocharger_rpm
turbocharger_temp
egr_valve_position
egr_flow_rate
variable_valve_timing
ignition_timing
fuel_injector_duration
fuel_trim_short_term
fuel_trim_long_term
engine_vibration
engine_torque
engine_power
drive_mode
traction_control_status
abs_activity
parking_brake_status
door_status
seat_belt_status
headlight_status
wiper_status
airbag_system_status

The expected metric list above is authoritative.

The implementation must not generate, infer, rename, or substitute additional
expected metrics.

A metric name is a string.

A metric value is expected to be numeric, although missing, empty, and
non-numeric values must be handled safely.

CSV PROCESSING

Metrics may appear in any order in the input CSV.

Metrics may be duplicated.

For every existing telemetry file within the requested date range:

Read all rows in their original order.
For each expected metric, keep only its first occurrence.
For every later occurrence of an expected metric, discard that row and
increment duplicates_removed by one.
Identify every metric name that is not in the expected metric set as an
unexpected metric.
Record unexpected metric names in unexpected_metrics.
Identify every expected metric that was absent from the original snapshot.
Record those absent expected metrics in missing_metrics.
Add every missing expected metric with value "" to the cleaned
representation.
Construct the cleaned snapshot with exactly the 100 expected metrics,
appearing exactly once each, in the fixed expected-metric order.

Unexpected metrics must not be included in the cleaned 100-metric snapshot.

Unexpected metrics must only be reported through unexpected_metrics.

Repeated unexpected metrics are not counted as duplicates.

Only duplicate occurrences of expected metrics contribute to
duplicates_removed.

duplicates_removed is therefore the total number of discarded duplicate
rows whose metric name belongs to the expected metric set.

Original telemetry files must never be modified, renamed, deleted, or
otherwise altered.

The cleaned representation is internal to the implementation and does not
replace the original input file.

INCOMPLETE SNAPSHOTS

A file is considered complete when every one of the 100 expected metrics
was present in the original telemetry snapshot.

A file is considered incomplete when one or more expected metrics were
absent from the original telemetry snapshot and therefore had to be inserted
with value "".

A file containing unexpected metrics is not automatically incomplete.

A file containing duplicate expected metrics is not automatically incomplete.

A metric whose row exists but whose value is empty is still considered
present.

A metric whose row exists but whose value is non-numeric is still considered
present.

Therefore, an empty or non-numeric value does not by itself make the file
incomplete.

Missing and non-numeric values must never be treated as valid numeric
measurements during anomaly detection.

DAY-TO-DAY ANOMALY DETECTION

For each existing processed file, determine its immediately preceding
calendar date using calendar-aware date arithmetic.

A day-to-day comparison for the current file is permitted only when both
conditions are true:

the previous calendar day's file exists for the same brand; and
the previous day's snapshot is complete.

If the previous calendar day's file is missing, skip day-to-day anomaly
detection for the current file.

If the previous day's snapshot is incomplete, skip day-to-day anomaly
detection for the current file entirely.

When day-to-day anomaly detection is permitted:

For each expected metric, compare the current value with the previous day's
value.

Ignore the metric when either value is missing, empty, or non-numeric.

For valid numeric values, flag the metric as anomalous when:

abs(current - previous) / abs(previous) > 0.20

A change of exactly 20% is not anomalous.

If the previous value is zero, do not apply the percentage formula and do not
flag the metric as a day-to-day anomaly.

The implementation must never divide by zero or crash.

anomalies_day_to_day must contain metric names only.

The anomaly list must contain each metric at most once.

CROSS-BRAND ANOMALY DETECTION

For each processed brand, each existing date, and each expected metric:

Collect valid numeric values for that metric from all other brands that
have an existing telemetry snapshot for the same date.
Exclude the brand currently being evaluated.
For each other brand, use at most one value for the specified metric,
taken from that brand's cleaned snapshot.
Ignore missing, empty, and non-numeric values.
If no other brand has a valid numeric value for the metric, skip
cross-brand anomaly detection for that metric.
Otherwise, compute the median of the remaining valid numeric values.

For the current brand's value, ignore the metric if its value is missing,
empty, or non-numeric.

Flag a cross-brand anomaly when:

abs(value - median) / abs(median) >= 3

A ratio of exactly 3 is anomalous.

If the median is zero:

a current value of zero is not anomalous;
any non-zero current value is anomalous.

The implementation must never divide by zero.

Missing or non-numeric values must be ignored.

anomalies_cross_brand must contain metric names only.

The anomaly list must contain each metric at most once.

ANOMALY INDEPENDENCE

Day-to-day anomaly detection and cross-brand anomaly detection are
independent.

A day-to-day anomaly must not automatically become a cross-brand anomaly.

A cross-brand anomaly must not automatically become a day-to-day anomaly.

An incomplete previous snapshot affects only day-to-day anomaly detection.

An incomplete current snapshot does not automatically suppress
cross-brand anomaly detection for valid numeric metrics that are present.

An incomplete current snapshot may still participate in cross-brand anomaly
detection for metrics that have valid numeric values.

Missing, empty, and non-numeric metric values must be ignored individually
during cross-brand anomaly detection.

REPORT STRUCTURE

Write the final report to:

/app/output/validation_report.pdf

The PDF must be human-readable.

Organize the report by brand and then by date.

Brands must be ordered lexicographically.

Dates must be ordered chronologically.

For every discovered brand, include its missing_files information.

For every existing telemetry file within the requested date range, include:

missing_metrics
unexpected_metrics
duplicates_removed
anomalies_day_to_day
anomalies_cross_brand

The report must not include files outside the requested date range.

The report must not include files whose names do not match the required
filename pattern.

The report must not include brands discovered only through invalid filenames.

ORDERING AND DETERMINISM

The report must be deterministic regardless of filesystem traversal order.

Process brand IDs in lexicographic order.

Process expected metrics in the fixed expected-metric order defined above.

Do not alphabetically reorder the expected metric list.

Sort missing_files chronologically.

Sort dates chronologically.

Sort missing_metrics according to the fixed expected-metric order.

Sort anomalies_day_to_day according to the fixed expected-metric order.

Sort anomalies_cross_brand according to the fixed expected-metric order.

Sort unexpected_metrics lexicographically.

Repeated unexpected metric names should appear only once in
unexpected_metrics, even if the same unexpected metric occurs multiple
times in the input file.

The implementation must use deterministic iteration and serialization so
that repeated executions against unchanged input produce equivalent results.

The generated PDF must use deterministic ordering and stable formatting.

ERROR HANDLING

The implementation must handle:

missing command-line arguments;
extra command-line arguments;
invalid date formats;
impossible calendar dates;
a start date later than the end date;
missing telemetry files;
invalid filenames;
duplicate metrics;
unexpected metrics;
missing metrics;
empty metric values;
non-numeric metric values;
division by zero;
multiple brands;
multiple dates;
filesystem traversal in arbitrary order.

For missing or invalid command-line arguments, exit with a non-zero status.

For an invalid date argument, the output must contain:

Invalid date format

For an invalid date range where the start date is later than the end date,
exit with a non-zero status and print a clear invalid-range error.

For successful execution, exit with status 0.

Errors must be printed to stdout.

The implementation must not crash because of malformed telemetry values.

INPUT FILE PROTECTION

The implementation must never modify the original telemetry files.

It must not:

overwrite input CSV files;
delete input CSV files;
rename input CSV files;
move input CSV files;
rewrite input CSV files;
alter file contents.

The input directory is read-only from the implementation's perspective.

Only /app/output/ may be created or written to by the reporting process.

DIRECTORY REQUIREMENTS

The implementation must read input files from:

/app/data/cars/

The implementation must be located at:

/app/validate_cars.py

The implementation must create:

/app/output/

if it does not already exist.

The final output file must be:

/app/output/validation_report.pdf

SUCCESS CRITERIA

A correct implementation must:

accept exactly two date arguments;
validate both dates as real calendar dates;
reject an invalid date range;
contain the exact Invalid date format message for invalid dates;
discover brands only from valid filenames;
ignore invalid filenames completely;
ignore filenames containing invalid calendar dates;
process only files in the requested inclusive date range;
enumerate missing dates using calendar-aware date arithmetic;
recognize exactly the 100 expected metrics listed in this specification;
preserve the fixed expected metric order;
retain the first occurrence of each expected metric;
count later expected-metric occurrences as duplicates;
report unexpected metrics;
not count unexpected metrics as duplicates;
detect missing expected metrics;
construct a cleaned 100-metric representation;
treat empty and non-numeric values as invalid numeric measurements;
distinguish incomplete snapshots from snapshots containing unexpected or
duplicate metrics;
correctly determine the immediately preceding calendar date;
skip day-to-day detection when the previous file is missing;
skip day-to-day detection when the previous snapshot is incomplete;
apply the strict > 20% day-to-day threshold;
treat exactly 20% as non-anomalous;
avoid division by zero;
perform cross-brand comparison using other brands on the same date;
compute the median of valid numeric values;
apply the cross-brand >= 3 threshold;
treat exactly 3 as anomalous;
correctly handle a zero cross-brand median;
ignore missing and non-numeric values during anomaly detection;
process brands independently;
produce deterministic results independent of filesystem order;
sort brands lexicographically;
sort dates chronologically;
sort expected-metric-based lists according to the fixed metric order;
sort unexpected metrics lexicographically;
write the final human-readable PDF to
/app/output/validation_report.pdf;
create /app/output/ if necessary;
never modify the original input files;
exit with status 0 on success;
exit non-zero on invalid or missing arguments;
print clear errors to stdout.