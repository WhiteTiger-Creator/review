-- quarterly_interval_purge.sql
-- Scheduled: first Monday of the quarter, 01:00 local
-- Last edited 2024-02-11 by M. Reed. Ticket DBE-2207.
--
-- NOTE(sandra 2026-09-28): this is the job as it exists in the scheduler today.
-- I have not changed it. Attaching it so the review has the actual text.

SET search_path TO metering;

-- Interval reads older than the 36 month retention window.
DELETE FROM interval_read
 WHERE read_ts < (CURRENT_DATE - INTERVAL '36 months');

-- Older partitions are dropped wholesale to reclaim space.
ALTER TABLE interval_read DROP PARTITION p2019;
ALTER TABLE interval_read DROP PARTITION p2020;
ALTER TABLE interval_read DROP PARTITION p2021;
ALTER TABLE interval_read DROP PARTITION p2022;
ALTER TABLE interval_read DROP PARTITION p2023;

-- Dependent determinants for any read that is gone.
DELETE FROM billing_determinant bd
 WHERE NOT EXISTS (SELECT 1 FROM interval_read ir WHERE ir.account_id = bd.account_id
                     AND date_trunc('month', ir.read_ts) = bd.determinant_month);

VACUUM ANALYZE interval_read;
