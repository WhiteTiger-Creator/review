# Meter estimation acceptance rules

Approved by the Billing Quality Council on 9 July 2026. These rules apply to the May-June parallel run and supersede unsigned working notes on the same subjects.

## Calculation sequence

1. Retain every row in `parallel_bill_results.csv`. For each row, verify `valid_sample_count = raw_sample_count + exclusion_adjustment`. The adjustment must be zero or negative and its reason must remain visible.
2. Within each district and meter class, calculate MAPE as `SUM(valid_sample_count * class_mape_pct) / SUM(valid_sample_count)`. Calculate signed bias the same way using `signed_bias_pct`.
3. A class passes only when its combined valid sample is at least 175, MAPE is no more than 3.00%, and absolute signed bias is no more than 1.00%.
4. A district passes the accuracy gate only when all three classes pass. Do not net a positive class bias against a negative bias elsewhere.
5. Join the district to `district_volume_inputs.csv`. The volume gate is at least 12,000 annual bills. A district is eligible for cutover only when both its accuracy gate and volume gate pass.
6. For approved-district portfolio figures, include only the districts that pass both gates. Weight MAPE and signed bias by valid sample count across their class rows. Sum annual bill population and annual service cost from the district volume file. Round displayed percentages to two decimals after aggregation.

## Seasonal exclusions

The permitted reasons are storm-restoration reads, estimated move-out reads, holiday closure accounts, late interval uploads, pre-season zero-use meters, manual register replacements, tariff-code conversion cases, and freeze-damaged register reads. An exclusion with no reason, a positive adjustment, or a mismatch between raw and valid sample counts is invalid and returns the affected class to review.

## Authority and boundary

The billing steering committee owns cutover acceptance. Finance validates bill exposure, and IT manages vendor remediation. Calendar entries are scheduling records; vendor and operations notes are supporting evidence. This method supplies a committee review record. Billing issuance, tariff administration, meter-record maintenance, and production deployment remain subject to their separate controls.
