# Tariff and field observations

These notes were assembled by the tariff analyst after reviewing exception tickets and talking with district billing clerks. They explain why particular records were excluded or challenged; they do not declare a district ready for production.

## Bastrop

The May storm-restoration accounts used reconstructed readings after service work. They were removed before comparing the estimation service with the production bill. In June, a handful of interval files arrived after the normal close. The late files were not silently backfilled into the validation set. Small-commercial tariff assignments sampled by the analyst matched the production system, and no unresolved conversion ticket was found.

## Caldwell

Move-out bills created the main residential exception. The account close dates and final reads were consistent between the customer system and the billing extract, so the exclusions are limited to the rows named in the parallel results. Holiday closure accounts explain the small-commercial deductions. The irrigation sample includes only meters with an active seasonal schedule and a readable register.

## Hays

Field services confirmed that the May irrigation zero-use accounts had not started their normal cycle. The four exclusions are therefore seasonal, not failed estimates. June register replacements were matched to the old meter numbers through the season relationship file. Hays clerks reported no change to the applicable tariff during either parallel month.

## Lee

The small-commercial cohort shows positive bias in both months, concentrated in accounts moved from a legacy demand tariff. Ticket IT-6432 asks the vendor to confirm how the new service interprets the demand-history field. Preserve the class result separately from the district average. Residential and irrigation observations use different determinants and do not answer the tariff-mapping question.

## Washington

Freeze-damaged irrigation registers explain twelve removed observations across the two periods. The retained valid count, MAPE, and signed bias must be calculated from the parallel rows and compared with the approved limits. Field services expects replacement reads in the next normal cycle. The district's annual bill population remains in the Finance volume file for a separate comparison with the approved threshold.

## Items to carry into a rerun

Lee needs a vendor response tied to IT-6432, a corrected tariff mapping if warranted, and a fresh small-commercial parallel comparison. Washington needs a new irrigation sample after replacement reads are available. For both districts, the next workpaper should retain the old record IDs so the change in sample and bias can be seen. A scheduled review window is planning evidence only; closure requires the observed rerun result and the named owner's acceptance.

## Check made against customer records

The analyst compared the district extract references with the billing batches in customer_record_lineage.xml. The five district names and owners agree with the Finance population file. This check does not establish accuracy, but it prevents a population from being assigned to the wrong run. The Lee conversion accounts remain tied to their original customer extract, and the Washington replacement meters remain linked to the field-services evidence. No undocumented tariff effective date was used to change either class result.

The field notes are intentionally narrower than the approved quality record. They support the reasons and relationships in the data, while the signed record controls the thresholds, decision ownership, and treatment of conflicting working material.
