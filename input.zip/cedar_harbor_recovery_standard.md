# Cedar Harbor managed recovery certification standard

Document owner: Managed Data Reliability, Operations Control  
Control reference: MDR-BCP-17, revision 4.3  
Effective date: 2026-07-01  
Review owner: Database Operations Manager  
Applies to: MemberCore, PaymentOps, and DocumentVault production databases

## Purpose and decision boundary

The maintenance board uses this standard to decide whether a database may enter a planned infrastructure window. A green job status is not recovery evidence by itself. The reviewer must demonstrate a restorable sequence, the recovery point it reaches, access to the required encryption key, verified primary and secondary media copies, and a recent successful rehearsal whose buffered duration meets the database recovery time objective. The evidence cut is 2026-08-17 05:30 Eastern Time. A set that finished after that cut is outside the review even when its recovery coverage ends before the cut.

The required recovery point objective is 15 minutes for MemberCore, 15 minutes for PaymentOps, and 60 minutes for DocumentVault. The recovery time objective is 120 minutes for MemberCore, 90 minutes for PaymentOps, and 180 minutes for DocumentVault. RPO age is the whole number of minutes from the evidence cut back to the recovery end carried by the last selected usable set. A result equal to the target passes. Do not round an older point down to the target.

## Eligible backup foundations

Start with the latest completed non-copy-only FULL set for the database that finished no later than the evidence cut. Its backup status, checksum result, and encryption field must all read COMPLETED, PASS, and ENCRYPTED. A failed checksum, incomplete job, unencrypted set, copy-only set, wrong database, or post-cut finish is not an eligible foundation. Keep every rejected set in the review surface with a direct reason.

A DIFFERENTIAL set is usable only when it passes the same status, checksum, encryption, timing, and non-copy-only tests and its database_backup_lsn exactly equals the checkpoint_lsn of the selected FULL. When several usable differentials share that base, select the one with the latest recovery end. An older matching differential remains valid evidence but is superseded by the later one. A differential with another base is rejected; it cannot be repaired by later transaction logs.

## Transaction-log continuity

After the selected FULL and latest usable DIFFERENTIAL, select transaction-log sets in recovery order. The first selected LOG must have first_lsn equal to the selected differential last_lsn plus one. Every next LOG must have first_lsn equal to the prior selected LOG last_lsn plus one. Status, checksum, encryption, key identity, and timing controls still apply. A later log cannot jump over a missing LSN interval. Once a gap appears, stop the recoverable chain at the last contiguous set; classify later otherwise-clean logs as POST-GAP, not as usable coverage.

Two exports with the same database, backup type, first_lsn, last_lsn, and recovery_end_et represent duplicate physical or catalog copies, not additional recovery coverage. Select at most one. Prefer the record whose media register has both copies verified most recently. If both records have equally current verified media evidence, either may represent the interval; identify the evidence tie, explain the representative chosen, and classify the other DUPLICATE_COPY. A copy-only FULL never changes the differential base and must not displace the selected regular FULL.

## Key and media custody

Every selected set must reference one encryption key marked ACTIVE in the custody register. The latest escrow test for that key must be no more than 90 calendar days old at the evidence cut. Every selected media_id must show primary_copy_status VERIFIED, secondary_copy_status VERIFIED, and a last copy verification no more than 30 calendar days old. A missing register row, expired or suspended key, stale key escrow test, unverified copy, or stale copy verification fails the custody gate. Do not substitute another database's key or infer that a second copy exists from a duplicate catalog row.

## Restore rehearsal basis

Use the latest run for each database in which all five required stages are present exactly once: FULL_RESTORE, DIFFERENTIAL_APPLY, LOG_REPLAY, RECOVERY, and APPLICATION_CHECK. Every stage must read PASS. A failed or incomplete later run supersedes an older success and fails the rehearsal gate until a new complete run passes. For a complete passing run, sum the five stage durations and select a 15 to 30 percent contingency for coordination and validation overhead. Ground that selection in the latest-run age, the immediately prior run's duration trend and stage results, any incident_ref, and whether the backup-set basis is sufficiently comparable. Round the resulting projected time upward to the next whole minute and compare it with the database RTO. Record the evidence assessment as REPRESENTATIVE when the supplied comparison supports ordinary use, USABLE-CONDITIONALLY when a 46-to-60-day pass supports only the bounded stale-rehearsal decision, or NOT-SUPPORTED when the records do not support a defensible contingency or comparable basis. NOT-SUPPORTED requires HOLD.

A passing rehearsal remains current for 45 calendar days from test_date through the evidence cut. A complete pass that is 46 to 60 days old does not erase the chain evidence, but it cannot support an unconditional CERTIFY call. The reviewer may recommend CONDITIONAL when the other gates pass, the supplied trend and incident evidence supports continued use, and the condition requires a complete passing rerun before the window; HOLD is also supportable when the residual evidence is too weak. A passing result older than 60 days requires HOLD. The reviewer must compare the latest passing run with the immediately prior run and state which evidence controls. A failed latest rehearsal, incomplete latest stage set, unsupported basis, or projected RTO above target requires HOLD.

## Certification calls and closeout

CERTIFY applies only when chain, RPO, projected RTO, key, media, and rehearsal-currency gates all pass. Any chain break, RPO failure, RTO failure, key failure, media failure, failed latest rehearsal, or combination of exceptions requires HOLD. When the sole exception is an older successful rehearsal, the supported decision envelope is CONDITIONAL or HOLD, never CERTIFY. A CONDITIONAL recommendation must name a successful full five-stage rerun before the window as a release condition; a HOLD recommendation must explain why the supplied rehearsal history is insufficient for conditional release.

## Required judgment record

The standard fixes the safety gates but not every professional choice inside the evidence boundary. Where duplicate interval copies have equally current verified custody evidence, choose exactly one representative using the supplied media-verification recency and source-replica diversity, document the basis, and explain why the tie does not add coverage. For each database, state the selected contingency and why the two-run evidence supports it. For a stale successful rehearsal, compare the latest run with the immediately prior run and choose within the allowed decision envelope. For a broken chain, name one primary recovery strategy. Recovering a missing interval is supportable only when the supplied records establish that set and its custody; otherwise establish a new valid foundation. State the evidence trigger for any fallback and keep the database on HOLD until a fresh export and certification close the gap. Do not invent timing, ownership, or availability that the records do not establish.

The workbook must retain the raw catalog identity, selected restore order, row-level set disposition, rehearsal basis, custody result, and one crosswalk row per supplied source. The first sheet should state the current call, recovery point, targets, results, controlling exception, and concrete closeout action for all three databases. Deterministic calculations and rollups must remain live formulas. Source values remain unchanged; corrections belong in disposition and action fields rather than in overwritten source columns.
