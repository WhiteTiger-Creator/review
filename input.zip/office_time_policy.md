# Linden scheduling time policy — release 2027.1

This policy governs client-facing consultation slots for the Boston, Chicago, and Phoenix offices. The booking service stores an accepted instant in UTC, while each availability rule is authored as a recurring wall-clock time in the office IANA zone.

## Office authority

| Office | IANA zone | 2027 standard offset | 2027 daylight offset | DST behavior |
|---|---|---:|---:|---|
| BOS | America/New_York | UTC-05:00 | UTC-04:00 | changes March 14 and November 7 |
| CHI | America/Chicago | UTC-06:00 | UTC-05:00 | changes March 14 and November 7 |
| PHX | America/Phoenix | UTC-07:00 | UTC-07:00 | no clock change |

The office zone owns slot creation and booking identity. Browser zone and client zone may be used for a labelled secondary display only. Neither may change the accepted slot ID or UTC instant.

## Local-time resolution

For Boston and Chicago on March 14, 2027, local times from 02:00 through 02:59 do not exist. The application must not advance, subtract, or otherwise coerce one of those values. Slot generation omits the value and an attempted direct booking returns `NONEXISTENT_LOCAL_TIME`.

For Boston and Chicago on November 7, 2027, local times from 01:00 through 01:59 occur twice. The application must return both candidates and require the user to choose `EARLIER` or `LATER`. Boston 01:30 resolves to 05:30Z for `EARLIER` and 06:30Z for `LATER`; Chicago 01:30 resolves to 06:30Z and 07:30Z respectively. No cookie, browser offset, prior booking, or array order may supply that choice.

Phoenix has neither a gap nor an overlap. Phoenix 09:00 is 16:00Z throughout 2027. A one-hour movement at the national DST boundary is an error.

## Recurrence, duration, and capacity

Availability recurs in office-local time. A Boston 09:00 rule remains 09:00 before and after the offset change; its UTC instant changes. Slot duration comes from the availability record. A slot identity is the server-issued `slot_id`, not a formatted time or a client-generated key.

Do not offer a slot whose hold remains active, whose confirmed count has reached capacity, or whose availability revision has been superseded. Duplicate deliveries of the same booking command are handled only through the API idempotency key. Do not merge different office slots because their local labels match.

## Confirmed records and correction classes

An accepted booking stores `start_utc`, `end_utc`, `office_tz`, `availability_revision`, and `booking_version`. That accepted instant is immutable unless the server accepts an explicit reschedule command against the current booking version.

- If the accepted UTC instant is correct and only the portal label or calendar attachment is wrong, preserve the booking and issue a corrected display or invite.
- If the accepted UTC instant is wrong for the office-local time the client acknowledged, do not silently change it. Place the record in client confirmation and let the scheduling owner complete a versioned reschedule.
- If no instant was accepted because the local time was nonexistent, ambiguous without a choice, stale, held, or full, keep it blocked and require a fresh slot selection.
- A rejected stale reschedule or cancellation does not alter the current confirmed booking.

## Calendar output

Calendar attachments use the accepted UTC values and the basic UTC form `YYYYMMDDTHHMMSSZ` for both `DTSTART` and `DTEND`. The invite summary and description may show labelled office-local and client-local values, but those labels do not replace the UTC properties. A delivery status of `SENT` proves transport only.

Every corrected invite must use the current booking version. Do not resend an attachment from a superseded version. Cancellation uses the accepted booking ID and current version; it never reconstructs identity from a displayed date.

## Release controls

Client Services owns confirmation outreach. Scheduling Operations owns availability and capacity. Web Scheduling owns slot generation, display, and command construction. Calendar Integrations owns ICS output and replacement delivery. Platform Time owns the adapter. Release Engineering owns staged deployment.

The release remains blocked on any silent gap coercion, inferred overlap choice, fixed-offset office conversion, client-side replacement of a server slot ID, or invite generated from anything other than the accepted UTC instant.
