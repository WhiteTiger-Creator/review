# Fairhaven consolidation - closing summary

Selwyn Advisory, Workforce Planning
Filed 12 November 2024 by T. Pelletier
Status: closed. Kept on file as reference. Not a template.

## What it was

Two Halbrook sites (Fairhaven and Marlow) folded into one operation over about six weeks in autumn
2024, single product line, running intake, adjustments and correspondence only. Certified at 41.0
FTE. Signed off by the client's operations lead and taken to the board in December.

## Assumptions we used, for the record

- Productive minutes per FTE: 2,000 per week. That was Halbrook's current figure at the time. It
  was revised upward in 2025 when they folded a further allowance into the base figure, so the
  2,000 should not be reused on anything after that change - the two figures are not comparable
  and the older one is not simply "more conservative".
- Two sites, not three. No Castlebridge; that site did not exist. No compliance queue.
- No shared support pool. Reconciliations and sign-offs were done by whichever processor was free.

## Timeline

Kickoff was 23 September 2024. The role-level rebuild took the first two weeks, the reconciliation
of the two sites' summaries against it the third, and the certification package went to Halbrook's
operations lead on 1 November. Two queues were rebalanced before go-live: 0.6 FTE moved from
Marlow correspondence to Fairhaven adjustments, and a 0.4 FTE addition was requested and approved
for intake. Go-live was 18 November 2024, with the first four weeks run under the outgoing site
leads' supervision.

## Numbers at close

Certified at 41.0 FTE across five queues: Fairhaven intake 11.2, Fairhaven adjustments 9.6, Marlow
intake 8.4, Marlow adjustments 7.3, correspondence 4.5. Every queue was at or above its computed
requirement on the 2,000 figure at certification, and the plan carried no net reduction. The
recurring work was not sized; see below.

## What we would do differently

The thing that bit us was the recurring admin work. Turnaround on the two queues that carried the
daily reconciliations slipped on and off for the first two quarters after go-live and nobody could
see a pattern in the weekly numbers, because there was none in the weekly numbers - the slippage
was on specific days. It was only in the internal review the following spring that we connected
it to the unstaffed daily work. Halbrook set up the Operations Support pool afterwards partly
because of this. Any new engagement should size that work explicitly and put it somewhere.

The second thing was the productive-minutes figure. Fairhaven and Marlow had each been planning on
their own version of it and neither matched the figure Halbrook's workforce team held centrally;
we spent a week reconciling three numbers that were supposed to be one. The client has since put
the figure in its annual planning letter, which is where any later engagement should take it from.

## Note for the current engagement

Halbrook finance asked at the August 2026 kickoff whether the Fairhaven ratios could be carried
across because the queue names look the same. The queue names came from us and were reused; that
is the only thing that carried over. Site count, productive-minutes figure and the support
arrangement have all changed. Check each against the current packet before reusing anything from
here.
