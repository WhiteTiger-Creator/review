
# HP-FCN-26-0814 | Warranty tree coordination record

Meeting: 2026-08-14, 07:20-08:05 ET  
Location: Harbor Point south trailer and field walk  
Present by initials: RK (landscape), JL (civil), TS (irrigation), MN (owner representative), AV (general contractor)  
Current status: issued for the 2026-08-18 recovery-design call

The team walked only the five positions below. All other positions remain governed by the current tree inventory and site-constraint register. These notes change field facts; they do not reserve plant material or authorize added construction cost.

## FCN-26-0814-01 | P-07 root plate

RK and AV found fresh soil cracking on the west side of the root ball and movement at the trunk flare under hand pressure. The inventory still reads FAIR because it was exported before the morning walk. Do not keep P-07 in warranty observation. Carry P-07 as REPLACE and treat the instability as Phase 1. The promenade remains HZ-P1. The existing planter and salt-exposure limits stay unchanged.

## FCN-26-0814-02 | L-03 electrical vault

JL confirmed that the revised electrical vault lid and service clearance occupy the issued L-03 tree opening. The vault is permanent work, not temporary access. Carry the tree position as REMOVE - NO REPLANT and keep the row visible for owner closeout. Do not move the tree quantity to L-02 or L-04. Closure evidence is the owner's written confirmation that the planting position is deleted from the warranty scope.

## FCN-26-0814-03 | C-11 brace review

The courtyard sweetbay at C-11 looked worse in the July export after a brace failed, but the brace was reset on August 6. RK found live buds on the upper scaffold limbs and no new trunk split. Keep C-11 as WATCH through the September inspection; do not procure a replacement now. Photograph the same north and east canopy faces and record brace tension at the next visit.

## FCN-26-0814-04 | G-04 clearance

AV measured 9.5 feet from finished grade to the lowest fixed garage sign support over G-04. The 14-foot value in the earlier register came from the pre-signage coordination background. Use 9.5 feet as the mature-height limit. The bed remains well drained, HZ-G1, HIGH salt exposure, and SMALL_TREE_ONLY. Do not assume the sign support will be raised.

## FCN-26-0814-05 | P-10 hydrozone

TS traced the lateral at P-10 to controller station HZ-P1. The HZ-P2 label in the tree inventory is a carryover from the ninety-percent irrigation drawing. Use HZ-P1 and the LOW water-class gate. No emitter count or physical site limit changed during this check.

Record prepared from meeting notes by RK. Initial blocks remain open for the design-call meeting; this record is not an owner approval, change order, nursery hold, or release for installation.
