-- PostgreSQL 15 target contract for the shared audience platform.
-- The conversion SQL may insert into these tables only through a normalized pair decision.

CREATE TABLE audience_person (
    person_id              text PRIMARY KEY,
    billing_name           text NOT NULL,
    postal_address1        text NOT NULL,
    postal_city            text NOT NULL,
    postal_state           char(2) NOT NULL,
    postal_code            text NOT NULL,
    newsletter_email       text,
    newsletter_allowed     boolean NOT NULL DEFAULT false,
    created_at             timestamptz NOT NULL DEFAULT clock_timestamp(),
    CHECK (person_id ~ '^ap_[0-9a-f]{20}$'),
    CHECK (newsletter_email IS NOT NULL OR newsletter_allowed = false)
);

COMMENT ON TABLE audience_person IS
'One person created from an eligible normalized source pair. Postal values come from current billing authority; newsletter state comes from explicit consent.';

CREATE TABLE audience_identity_xref (
    source_profile_ref   text PRIMARY KEY,
    person_id            text NOT NULL REFERENCES audience_person(person_id),
    source_system        text NOT NULL,
    pair_key             text NOT NULL,
    loaded_at            timestamptz NOT NULL DEFAULT clock_timestamp(),
    CHECK (source_system IN ('LEGACY', 'DIGITAL'))
);

CREATE INDEX audience_identity_xref_person_idx
    ON audience_identity_xref (person_id);

CREATE INDEX audience_identity_xref_pair_idx
    ON audience_identity_xref (pair_key);

COMMENT ON TABLE audience_identity_xref IS
'Preserves both source identifiers. A source profile may map to no more than one audience person.';

CREATE TABLE audience_attribute_provenance (
    person_id             text NOT NULL REFERENCES audience_person(person_id),
    attribute_domain      text NOT NULL,
    source_record_id      text NOT NULL,
    source_profile_ref    text,
    selected_at           timestamptz NOT NULL,
    PRIMARY KEY (person_id, attribute_domain),
    CHECK (attribute_domain IN ('BILLING_NAME_POSTAL', 'NEWSLETTER_PERMISSION'))
);

COMMENT ON TABLE audience_attribute_provenance IS
'Stores the exact billing ledger or newsletter event that supplied each domain of winning attributes.';

CREATE TABLE audience_household_link (
    pair_key            text PRIMARY KEY,
    member_a_ref        text NOT NULL,
    member_b_ref        text NOT NULL,
    relationship_type   text NOT NULL,
    edge_ids            jsonb NOT NULL,
    created_at          timestamptz NOT NULL DEFAULT clock_timestamp(),
    CHECK (member_a_ref < member_b_ref),
    CHECK (relationship_type = 'SHARED_DELIVERY_ADDRESS')
);

COMMENT ON TABLE audience_household_link IS
'Links different people at a household level. It does not authorize a shared audience person identifier.';

CREATE TABLE identity_merge_exclusion (
    pair_key             text PRIMARY KEY,
    member_a_ref         text NOT NULL,
    member_b_ref         text NOT NULL,
    reason_code          text NOT NULL,
    evidence_id          text NOT NULL,
    edge_ids             jsonb NOT NULL,
    recorded_at          timestamptz NOT NULL DEFAULT clock_timestamp(),
    CHECK (member_a_ref < member_b_ref),
    CHECK (reason_code = 'ACTIVE_IDENTITY_SUPPRESSION')
);

COMMENT ON TABLE identity_merge_exclusion IS
'Pairs withheld before any person, cross-reference, household, or review write because an active identity suppression controls.';

CREATE TABLE identity_merge_review (
    pair_key             text PRIMARY KEY,
    member_a_ref         text NOT NULL,
    member_b_ref         text NOT NULL,
    reason_code          text NOT NULL,
    evidence_id          text,
    billing_party_a      text,
    billing_party_b      text,
    edge_ids             jsonb NOT NULL,
    recorded_at          timestamptz NOT NULL DEFAULT clock_timestamp(),
    CHECK (member_a_ref < member_b_ref),
    CHECK (reason_code IN (
        'OPEN_REFUND_OWNERSHIP',
        'BILLING_PARTY_CONFLICT',
        'MISSING_BILLING_AUTHORITY',
        'CONFLICTING_MATCH_HINT',
        'UNSUPPORTED_MATCH_HINT'
    ))
);

COMMENT ON TABLE identity_merge_review IS
'Work queue for candidate pairs that cannot be written automatically and are not governed by an active suppression.';

CREATE TABLE identity_rehearsal_run (
    run_id                 text PRIMARY KEY,
    cutoff_date            date NOT NULL,
    normalized_pair_count  integer NOT NULL,
    auto_merge_count       integer NOT NULL,
    household_link_count   integer NOT NULL,
    manual_review_count    integer NOT NULL,
    exclusion_count        integer NOT NULL,
    recorded_at            timestamptz NOT NULL DEFAULT clock_timestamp(),
    CHECK (
        normalized_pair_count =
        auto_merge_count + household_link_count + manual_review_count + exclusion_count
    )
);

COMMENT ON TABLE identity_rehearsal_run IS
'Count reconciliation for a repeatable source packet. Counts are derived from the materialized pair decision, not manually entered.';
