# Banyan Advisory July staffing rules

Planning date: 2026-07-06
Audience: operations director and practice leads

Use the request queue as the source for request IDs, due dates, estimated hours, required practice, required role, priority, revenue, and sponsor visibility. Use consultant capacity as the source for base availability, PTO, role, practice, and client load. Use the current assignment backlog as the source for already committed July hours. Use client priority notes for named sponsor context and priority overrides.

## Priority score

Start with priority points: P0 is 40, P1 is 30, P2 is 20, and P3 is 10. Add 15 for High contract risk, 8 for Medium contract risk, and 0 for Low contract risk. Add 15 when the due date is on or before 2026-07-12, 10 when it is on or before 2026-07-19, 5 when it is on or before 2026-07-26, and 0 after that. Add 8 when sponsor visibility is Yes. Add 6 when revenue is at least 100000.

## Status rules

Mark a request Start now when it is P0 or P1 and has a feasible practice owner for July. Mark Queue for July when it is P2 or P3 and a matching consultant has capacity after Start now work. Mark Scope discussion when the request needs a role that cannot be covered cleanly, the estimated hours exceed realistic remaining capacity, or the priority notes say Scope first.

Treat client priority notes as escalation guidance, not as a replacement for the capacity math. A Start now override still needs a July owner whose practice and role can cover the work. A Can wait override may stay queued when the due week and risk profile do not justify using scarce manager or senior hours. A Scope first override should stay in scope discussion until the practice lead agrees to trim hours, change the deliverable, split the work, or move the date.

When priority scores are tied, break ties in this order: earlier due week, High contract risk, sponsor visible, larger revenue, then lower estimated hours. The tie-break does not change the numeric score. It only guides which feasible request gets the first available July capacity. Do not use tie-breaks to push a low-risk request ahead of a fixed meeting, court, board, or regulatory deadline.

Use due weeks as planning labels. Dates from 2026-07-06 through 2026-07-12 fall in Week of Jul 6. Dates from 2026-07-13 through 2026-07-19 fall in Week of Jul 13. Dates from 2026-07-20 through 2026-07-26 fall in Week of Jul 20. Dates after 2026-07-26 fall in Week of Jul 27. The due week should come from the request due date, not from the date the request was received.

## Assignment rules

Match practice first. A principal, manager, or senior can own work that needs a lower role in the same practice. An analyst can own analyst work and can support senior work only when the plan names a senior review owner. Do not assign new work that would leave a consultant with negative July remaining hours unless the status is Scope discussion.

Use the role hierarchy as Principal, Manager, Senior, then Analyst. A higher role can cover a lower-role request when the practice match is strong and client load stays inside the consultant limit. A lower role cannot independently own higher-role work. If analyst build work is used for a senior request, name the senior reviewer in the owner or reason so the escalation path is visible during the meeting.

Calculate each consultant's base July capacity as weekly capacity multiplied by four. Subtract July PTO and committed backlog before assigning new requests. Backlog hours count even when the backlog note says the work can move, unless the plan explicitly records the move as a staffing assumption. Keep client load visible. A consultant who would exceed the client limit can still be proposed only when the meeting agenda calls out the needed practice lead approval.

Planned July hours should normally equal the request estimate for Start now and Queue for July items. Scope discussion items should not consume new July capacity until the scope decision is made. If a request is split or reduced, the workbook should explain the split in the reason and keep the remaining scope visible as an exposure.

## Meeting output

The workbook should show the recommended staffing choices and the reasoning in plain language. The operations director needs to know which requests start now, which can wait, which need a scope conversation, and how many hours remain by consultant and practice after the proposed plan.

The consultant view should show base capacity, PTO, current backlog, available hours before new work, planned new work, remaining hours, client load after the plan, and a short capacity note. The client exposure view should show request count, high-risk request count, start-now hours, queued hours, scope hours, revenue, and a direct exposure note for each client. The source checks should tie back to the consultant list, request queue, backlog, status counts, negative remaining hours, and visible formula error scan.

Use only the five planning packet files. Do not add market background, public company facts, outside benchmarks, or extra client assumptions. Keep the workbook practical for a Tuesday operations meeting: direct statuses, named owners, short reasons, and formulas that let a practice lead trace the math without rebuilding it.
