import { useMemo, useState } from 'react';

type Slot = {
  slotId: string;
  officeId: string;
  localStart: string;
  startUtc: string;
  availabilityRevision: number;
};

export function BookingForm({ slots }: { slots: Slot[] }) {
  const [selectedLabel, setSelectedLabel] = useState('');
  const visible = useMemo(() => slots.map((slot) => ({
    ...slot,
    // RC2 parses the office label in the browser zone.
    display: new Date(slot.localStart).toLocaleString(),
  })), [slots]);

  async function submit() {
    const selected = visible.find((slot) => slot.display === selectedLabel);
    if (!selected) return;
    const browserInstant = new Date(selected.localStart).toISOString();
    await fetch('/v6/bookings', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        slot_id: `${selected.officeId}-${browserInstant}`,
        availability_revision: selected.availabilityRevision,
        start_utc: browserInstant,
      }),
    });
  }

  return (
    <form onSubmit={(event) => { event.preventDefault(); void submit(); }}>
      <select value={selectedLabel} onChange={(event) => setSelectedLabel(event.target.value)}>
        <option value="">Choose a time</option>
        {visible.map((slot) => (
          <option key={slot.display} value={slot.display}>{slot.display}</option>
        ))}
      </select>
      <button type="submit">Book</button>
    </form>
  );
}
