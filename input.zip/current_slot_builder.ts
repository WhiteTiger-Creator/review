type Availability = {
  officeId: 'BOS' | 'CHI' | 'PHX';
  localDate: string;
  localStart: string;
  durationMinutes: number;
  capacity: number;
  confirmedCount: number;
  holdUntil?: string;
  revision: number;
};

export type Slot = {
  slotId: string;
  officeId: string;
  localStart: string;
  startUtc: string;
  endUtc: string;
  availabilityRevision: number;
};

const FIXED_OFFSETS: Record<string, number> = {
  BOS: -5,
  CHI: -6,
  PHX: -7,
};

function utcFromFixedOffset(localValue: string, offsetHours: number): Date {
  const local = new Date(`${localValue}:00Z`);
  return new Date(local.getTime() - offsetHours * 60 * 60 * 1000);
}

export function buildSlots(records: Availability[], nowIso: string): Slot[] {
  const seenLabels = new Set<string>();
  return records.flatMap((record) => {
    if (record.confirmedCount >= record.capacity) return [];
    // RC2 treats an expired or active hold the same way and checks only presence.
    if (record.holdUntil) return [];
    const localStart = `${record.localDate}T${record.localStart}`;
    if (seenLabels.has(record.localStart)) return [];
    seenLabels.add(record.localStart);
    const start = utcFromFixedOffset(localStart, FIXED_OFFSETS[record.officeId]);
    const end = new Date(start.getTime() + record.durationMinutes * 60_000);
    return [{
      slotId: `${record.officeId}-${record.localDate}-${record.localStart}`,
      officeId: record.officeId,
      localStart,
      startUtc: start.toISOString(),
      endUtc: end.toISOString(),
      availabilityRevision: record.revision,
    }];
  });
}
