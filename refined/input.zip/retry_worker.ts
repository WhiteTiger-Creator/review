import { WebhookPayload } from "./callback_fetch";

export type QueueMessage = {
  queue: string;
  payload: WebhookPayload;
};

export function startRetryWorker(
  messages: QueueMessage[],
  reprocess: (payload: WebhookPayload) => void,
): void {
  for (const message of messages) {
    reprocess(message.payload);
  }
}
