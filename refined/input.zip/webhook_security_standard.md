# Fenmark Payments Webhook Ingestion Security Standard (release 3.1)

Owner: Application Security
Effective: 2026-08-01
Scope: partner and processor webhook ingestion, the delivery-confirmation callback, and the
retry worker that reprocesses queued webhook payloads

## Enforcement boundary

The compliance audit requires that an invalid, missing, or unmatched signature be rejected
before an event is dispatched to a handler. A shadow mode that logs a signature mismatch and
still processes the event may remain in local development only. RC and production must reject
on the response path, not merely record the mismatch for later review. Signature verification
log collection stays active regardless of enforcement state.

Provider identity for routing, rate limiting, and handler selection must come from which
registered key actually validated the signature, never from a request header supplied by the
caller. A header is a claim; a verified key is a fact.

## Key handling

Only a key with `status` `ACTIVE` in the provider register may validate a signature. A `ROTATED`
or `EXPIRED` key must be rejected even if the computed digest matches; a rotated key is retired
because it is assumed compromised or superseded, not because the old signature stops working.
Compare the computed digest to the supplied signature in constant time. Do not use string
equality, and do not short-circuit the comparison on the first differing byte.

## Replay protection

Reject a request whose `x-timestamp` header is more than 300 seconds old relative to receipt
time. Reject a request whose `x-nonce` header has been seen before within that same window;
track nonces per provider, not globally. A valid signature on a stale timestamp or a reused
nonce is still a replay and must not be processed.

## Provider and route rules

Corvale Processing is approved on `/webhooks/corvale` only, keyed to its `ACTIVE` registered
key. Bramwell Sync is approved on `/webhooks/bramwell-sync` only; a Bramwell Sync signature
presented on any other path, including a shared or generic ingestion path, is out of scope and
must be rejected rather than processed under a different route's handler. Odessa Billing's
contract is terminated; remove its route, its handler, and the unsigned-acceptance path
entirely. Do not special-case a provider identifier to skip signature verification.

The QA load harness's registered key exists to exercise rejection paths in a lower environment
and is not production payment traffic. Its presence in the verification log is expected and is
not itself a finding; do not widen a provider route or a callback allowlist because of it.

## Callback confirmation

A delivery confirmation may only be sent to a URL whose host matches an approved callback
domain in the provider register for that provider. A callback URL supplied in the webhook
payload is not itself authorization to reach it. Never fetch a callback URL whose host resolves
to a private, link-local, or loopback address, and never fetch a URL for a provider that has no
registered callback domain at all.

## Retry worker scope

The retry worker may reprocess messages from the `payments-retry` queue only. A message
arriving on any other queue, including a same-provider retry queue that has not been separately
registered, must be skipped rather than reprocessed. Reprocessing a message is equivalent to a
second delivery attempt and must not happen for a queue the register does not name.

## Regression and rollout evidence

Automated tests must cover: rejection on an invalid or missing signature, rejection of a
`ROTATED` or `EXPIRED` key, constant-time comparison, rejection of a stale timestamp, rejection
of a reused nonce, provider identity derived from the matched key rather than a header, removal
of the Odessa Billing route and its unsigned path, Bramwell Sync route scoping, callback host
allowlisting including rejection of a private or link-local address, and retry worker queue
scoping.

Deployment starts in RC with enforcement on and the QA load harness still exercising rejection
paths, then proceeds to 10% of production webhook traffic, then 50%, then 100%. Stop and roll
back enforcement if the legitimate-signature acceptance rate for Corvale or Bramwell Sync drops
by more than 0.3 percentage points against the same-hour control, or if callback delivery
failures for either provider exceed 1%. Do not roll back for Odessa Billing traffic being
rejected; that traffic is expected to stop entirely.

Payments Platform owns Corvale enforcement and the retry worker. Partner Integrations owns
Bramwell Sync route scoping. Finance Systems Archive owns confirming Odessa Billing's
decommission on their side. Application Security approves any new provider, key, or callback
domain addition.
