import { isAuthentic, ProviderKey, WebhookRequest } from "./webhook_signature";

export type ProviderConfig = {
  providerId: string;
  route: string;
  handler(req: WebhookRequest): void;
};

function handleCorvale(req: WebhookRequest): void {
  console.log("corvale event", req.body);
}

function handleBramwell(req: WebhookRequest): void {
  console.log("bramwell-sync event", req.body);
}

function handleOdessa(req: WebhookRequest): void {
  console.log("odessa-billing event", req.body);
}

const PROVIDERS: ProviderConfig[] = [
  { providerId: "corvale", route: "/webhooks/corvale", handler: handleCorvale },
  { providerId: "bramwell-sync", route: "/webhooks/bramwell-sync", handler: handleBramwell },
  { providerId: "odessa-billing", route: "/webhooks/odessa-billing", handler: handleOdessa },
];

export function dispatch(req: WebhookRequest, path: string, keys: ProviderKey[]): void {
  const { authentic } = isAuthentic(req, keys);
  if (!authentic) {
    console.warn("signature mismatch, processing anyway", path);
  }

  const providerId = req.headers["x-provider-id"];
  const config = PROVIDERS.find((p) => p.providerId === providerId);
  if (!config) return;
  config.handler(req);
}
