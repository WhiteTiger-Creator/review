export type WebhookPayload = {
  providerId: string;
  eventType: string;
  callbackUrl?: string;
};

export async function confirmDelivery(payload: WebhookPayload): Promise<void> {
  if (!payload.callbackUrl) return;
  await fetch(payload.callbackUrl, {
    method: "POST",
    body: JSON.stringify({ status: "received" }),
  });
}
