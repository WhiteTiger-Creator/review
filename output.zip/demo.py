from ExtensionExample import *

print('calling get_string(), should print out a random string')
cpp_str1 = get_string()
assert type(cpp_str1) == str
print(cpp_str1)

print ('calling get_string(), should print out a random string')
cpp_str2 = get_string()
assert type(cpp_str2) == str
print(cpp_str2)

print ('calling are_values_equal( 10, 10 ), should print True')
print (are_values_equal( 10, 10 ))
assert are_values_equal( 10, 10 ) == True

print ('calling are_values_equal( 10, 1 ), should print False')
print (are_values_equal( 10, 1 ))
assert are_values_equal( 10, 1 ) == False


print ('calling num_arguments( True ), should print 1')
print (num_arguments( True ))
assert num_arguments( True ) == 1


print ('calling num_arguments( True, True ), should print 2')
print (num_arguments( True, True ))
assert num_arguments( True, True ) == 2

print ('calling num_arguments( True, True, True ), should print 3')
print (num_arguments( True, True, True ))
assert num_arguments( True, True, True ) == 3


print ('running: a = wrapped_class()')
a = wrapped_class()
print ('running: a.get_value(), should print -1')
print (a.get_value())
assert a.get_value() == -1

print ('running: a.set_value( 5 )')
a.set_value( 5 )
print ('running: a.get_value(), should print 5')
print (a.get_value())
assert a.get_value() == 5

print ('calling num_arguments( True, True, True, True ), should print 4')
print (num_arguments( True, True, True, True ))
assert num_arguments( True, True, True, True ) == 4


print ('running: b = wrapped_class( 10 )')
b = wrapped_class( 10 )
print ('running: b.get_value(), should print 10')
print (b.get_value())
assert b.get_value() == 10
