from ExtensionExample import *

print ('calling get_string(), should print out a random string')
print (get_string())

print ('calling get_string(), should print out a random string')
print (get_string())

print ('calling are_values_equal( 10, 10 ), should print True')
print (are_values_equal( 10, 10 ))

print ('calling are_values_equal( 10, 1 ), should print False')
print (are_values_equal( 10, 1 ))

print ('calling num_arguments( True ), should print 1')
print (num_arguments( True ))

print ('calling num_arguments( True, True ), should print 2')
print (num_arguments( True, True ))

print ('calling num_arguments( True, True, True ), should print 3')
print (num_arguments( True, True, True ))

print ('running: a = wrapped_class()')
a = wrapped_class()
print ('running: a.get_value(), should print -1')
print (a.get_value())
print ('running: a.set_value( 5 )')
a.set_value( 5 )
print ('running: a.get_value(), should print 5')
print (a.get_value())

print ('calling num_arguments( True, True, True, True ), should print 4')
print (num_arguments( True, True, True, True ))

print ('running: b = wrapped_class( 10 )')
b = wrapped_class( 10 )
print ('running: b.get_value(), should print 10')
print (b.get_value())
