# Friday homepage readout: hold

Marisol, I rebuilt the incident slice from the request, edge, browser, and identity rows. The short answer is still **do not use `home_readout_v1` in Friday's lift slide**.

That extract says A had 8 exposures and 5 paid starts and B had 9 and 2. After applying the entry and event contract session by session, A is 5 / 4 (80.0%) and B is 6 / 1 (16.7%). Combined, the sample moves from 17 / 7 (41.2%) to 11 / 5 (45.5%). `restated_experiment_metrics.csv` has the deltas. This is a deliberately selected 18-session incident sample, not an experiment result. It supports neither a winning-arm decision nor a statistical-significance claim. We need a clean collection window after the repair.

## Notes from the reconstruction

The delivery failures are S05 and S06. S05 rendered A on the request but recorded a B exposure under a browser-only token. S06 is the cache bleed Lila found: the ORD hit used unsegmented `home:v3` and served an A token over a B origin assignment. Neither row can be repaired by choosing one side.

Five other sessions leave the population for different reasons: S08 was a subscriber at entry; S10 is version 2; S11's browser token is not the server token; S13 is a bot; and S16 has a paid-start but no exposure that could establish an arm.

The remaining corrections are counting and order, not exclusions. S07 and S12 each have a duplicate exposure. S14 has two paid-starts on one token, so one counts. S15 keeps its B exposure at 15:36:44Z, but the paid-start at 15:36:01Z is 43 seconds earlier and does not count.

Sign-in does not start a second cohort. The transition file shows the same assignment token before and after authentication for S02, S04, S07, S09, and S14. Those later user IDs stay with the anonymous entry assignment. S18 is a useful clean cache hit: `home:v3:B`, the delivered hero, and the browser event all agree.

Every S01 to S18 call, including the request and event references I used, is in `session_dispositions.csv`.

## Code handoff

`experiment_assignment.ts` keeps eligibility and bucketing on the server. The bucket is derived from the anonymous entry ID itself, not taken as an argument from the caller, so the same anonymousId always lands on the same bucket regardless of who calls the function or what they pass. It uses the contract boundaries (0 to 4999 for A, 5000 to 9999 for B), returns the saved session assignment after sign-in, and never substitutes user ID for the anonymous entry identity. Edge should cache only the version-and-arm hero segment. The visitor token is attached after cache lookup.

`exposure_tracker.tsx` has no bucketing import. It accepts the server envelope, rejects a rendered-arm mismatch, and reuses one idempotency key across remounts and retries. Paid-start is held until the matching exposure is marked sent.

Deployment order matters here:

1. Land the server assignment change and Edge's version/arm cache key together.
2. Purge the unsegmented `home:v3` object.
3. Deploy the tracker once the server envelope is present in rendered pages.
4. Check both bucket boundaries plus a signed-out-to-signed-in journey while the readout stays paused.
5. Open a new version-3 analysis window, then rebuild from raw request, edge, event, and identity evidence. Do not append these corrections to `home_readout_v1`.

No row in this sample needs a Merchandising decision. Preserve the raw S05 and S06 evidence with the incident; they are conflicts, not judgment calls.

## Checks for the rollout

These are the checks I would run before Analytics reopens the population.

**Assignment through sign-in**

```sql
select session_id,
       count(distinct assignment_token) as token_count,
       count(distinct variant) as arm_count
from experiment_events
where experiment_id = 'EXP-HOME-27' and assignment_version = 3
group by session_id
having count(distinct assignment_token) <> 1
    or count(distinct variant) <> 1;
```

Expected: no eligible sessions returned. In the browser check, load signed out, keep the session, sign in, and compare the before/after token and arm.

**Edge separation**

Send bucket 4999 and bucket 5000 through the same POP. The first trace must show `home:v3:A`; the second must show `home:v3:B`. Neither cached object may contain a prior visitor's token. A plain `home:v3` key or blank experiment Vary value fails.

**Server, render, and hydration**

```sql
select s.session_id
from server_assignments s
join experiment_events e using (session_id)
where e.event_type = 'EXPOSURE'
  and (s.assigned_variant <> s.rendered_variant
    or s.rendered_variant <> e.variant
    or s.served_assignment_token <> e.assignment_token);
```

Expected: zero rows. Exercise one A and one B page with hydration on and compare the server assignment, visible hero, browser event arm, and token.

**Duplicate suppression**

```sql
select experiment_id, assignment_version, session_id, assignment_token,
       event_type, count(*) as event_count
from experiment_events
group by experiment_id, assignment_version, session_id, assignment_token, event_type
having count(*) > 1;
```

Expected: zero rows after endpoint deduplication. Remount the hero twice and double-submit paid-start; each event type must retain one idempotency key.

**Paid-start order**

```sql
select c.session_id
from experiment_events c
left join experiment_events x
  on x.session_id = c.session_id
 and x.assignment_token = c.assignment_token
 and x.event_type = 'EXPOSURE'
 and x.event_time_utc < c.event_time_utc
where c.event_type = 'CONVERSION' and x.event_id is null;
```

Expected: zero rows in the attributed-conversion set. Calling paid-start before exposure reaches `sent` must return false and send nothing.

**Subscriber entry**

```sql
select s.session_id
from server_assignments s
join experiment_events e using (session_id)
where s.entry_status = 'SUBSCRIBER' and e.event_type = 'EXPOSURE';
```

Expected in the counted population: zero rows. A subscriber-at-entry request receives no experiment envelope; a prospect who signs in later retains the original one.
