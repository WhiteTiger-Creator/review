# Atlas Industrial CMS Cutover: RC3 Routing Release Review

Prepared for the September 2026 release huddle  
Owner: Web Platform Release
Submission archive: atlas_cms_routing_release_package.zip  

## Release call

**Hold RC3.** The corrected package closes the observed middleware, redirect, market, and metadata defects, but Regional Marketing must still approve or reject the proposed parent fallback from `/industries/water-treatment` to `/solutions`; the intended replacement remains draft in cms_route_export.csv (entry 1103). The desired German and Canadian header sets also name landing pages that are absent from the CMS export. Those links remain omitted rather than being manufactured, but they are publication gaps, not additional release approvals established by this packet.

Once the water-treatment decision is closed, Engineering can release this code without another routing redesign. Search Operations should rerun the manifest and request checks below, and deployment must provide both LEGACY_UK_ORIGIN and NEXT_PUBLIC_LEGACY_UK_ORIGIN.

## What changed from RC3

The approved manifest accounts for all 48 legacy inventory rows: 11 retained routes, 32 permanent redirects, 3 UK legacy pass-through routes, and 2 retirements. One of the 32 redirects remains blocked for owner approval. The two retired utilities, `/search` and `/compare`, return 410 rather than falling through to a 404 or being hidden behind a home-page redirect.

Middleware order now reflects revision 3.4. Assets and service endpoints bypass first. UK requests pass to the configured legacy origin. Old `/de` and `/ca` routes resolve from the manifest before any locale logic. Cookie and browser-language selection runs only at `/`, so opening a deep US link no longer changes its market. Explicit `/de-de` and `/en-ca` paths win and set the 180-day market cookie.

Redirects are permanent and single-hop. Matching is case-insensitive for known legacy paths and removes one trailing slash. At a redirect boundary, campaign parameters are removed while functional parameters remain in incoming order. Unknown paths are not normalized into invented routes.

The header now uses one filtered collection for desktop and mobile. It exposes only destinations supported by the CMS export. The UK selector entry goes to the configured legacy origin and is labelled as a legacy site; no `/en-gb` route is created.

Metadata now self-canonicalizes every published market page. Products match by model identity, and editorial or vertical pages require an explicit family identity. Legal content never receives cross-market alternates. No `en-GB` alternate is emitted, and `x-default` is present only when a published US equivalent exists.

## RC3 evidence reconciliation

| RC3 request or symptom | Corrected result | Evidence used |
|---|---|---|
| `/products/precision-pumps/ax-420` took two hops | One 308 directly to `/products/precision-pumps/ax-series-420` | CMS 1032; Omar Feld decision |
| Deep AX-410 link moved to Germany by cookie | US product remains on the requested route | Root-only locale rule |
| Deep AX-410 link moved by `de-DE` | US product remains on the requested route | Root-only locale rule |
| Root with `site_market=DE` | One redirect to `/de-de` | Locale selection rule |
| Root with German primary language | One redirect to `/de-de` | Locale selection rule |
| `/_next/static/chunks/app.js` intercepted | Bypasses middleware | Bypass prefix rule |
| `/assets/atlas-wordmark.svg` intercepted | Bypasses middleware | Bypass prefix and file rule |
| `/api/product-search` | Continues to bypass middleware | Bypass prefix rule |
| `/health` intercepted | Bypasses middleware | Bypass prefix rule |
| Pump selector lost `pumpModel` and retained ad tags | Redirect retains `pumpModel=AX-410`; removes `utm_campaign` and `gclid` | Query-handling rule |
| Canadian cavitation guide landed on US article | One 308 to `/en-ca/learning-center/avoiding-pump-cavitation` | CMS 3201; Canada decision |
| German guide gained a duplicated locale segment | One 308 to `/de-de/wissen/pumpenkavitation-vermeiden` | CMS 2201; DACH decision |
| Legacy German AX-410 returned 404 | One 308 to the localized published product | CMS 2031 |
| Legacy Canadian pump category returned 404 | One 308 to the Canadian category | CMS 3021 |
| Water-treatment route returned 404 | Proposed 308 to `/solutions`, blocked until Regional Marketing approves | CMS 1103 draft; release thread |
| `/compare` had no disposition | Returns 410 | Product decision: no launch substitute |
| UK route was moved into Germany | Rewritten to LEGACY_UK_ORIGIN with its UK path intact | Phase-two boundary |
| US privacy route moved to Canada | One 308 to `/legal/privacy-us`; deep links are not locale-detected | CMS 1500; legal metadata rule |
| Mixed-case AX-420 with trailing slash returned 404 | One direct 308 to the lowercase renamed product | Legacy normalization rule |
| `/de-de/produkte` was overridden by CA cookie | Explicit German route continues and sets DE cookie | Explicit-prefix precedence |

## Release decision and publication gaps

**Open owner decision — Regional Marketing.** Approve `/solutions` as the water-treatment launch destination or publish entry 1103. Until then, the manifest row stays BLOCKED_OWNER_APPROVAL and the release stays held.

The following are recorded as publication gaps rather than approval decisions in the supplied packet:

- The desired Canadian Solutions, Learning Center, Support, and About landing entries are absent from cms_route_export.csv. The current header shows only the published Products destination.
- A German Support landing entry is absent. The header includes the published Kontakt destination and withholds an unsupported Support link.

## QA checks required for sign-off

| Required area | Named check | Expected result |
|---|---|---|
| Market precedence | Request `/products/precision-pumps/ax-410` with `site_market=DE`, then request `/de-de/produkte` with `site_market=CA` | The deep US path does not redirect; the explicit German path continues and sets the DE cookie |
| Query strings | Request `/resources/pump-sizing-tool?pumpModel=AX-410&utm_campaign=fall&gclid=123` | One 308 to `/tools/pump-selector?pumpModel=AX-410`; both tracking parameters are absent |
| Redirect hops | Request `/products/precision-pumps/ax-420` | Exactly one 308 whose Location is `/products/precision-pumps/ax-series-420` |
| Navigation parity | Render US mobile and desktop headers from the same build | Both modes expose the same item IDs and destinations; the UK selector uses the legacy origin and no `/en-gb` link appears |
| Canonical URLs | Render metadata for US AX-410 and Canadian AX-410 | Each page emits its own absolute URL as canonical |
| Alternate-language URLs | Render AX-410, both cavitation articles, and `/legal/privacy-us` | Only published equivalents appear; legal has no cross-market alternates and no `en-GB` alternate is emitted |

**48-row manifest sweep.** Load approved_redirect_manifest.csv and issue one request for every legacy_path, preserving a result row keyed by that path. The result file must contain exactly 48 unique paths: each READY PERMANENT_REDIRECT returns exactly one 308 whose Location equals destination; each RETAINED path returns no redirect; each LEGACY_PASSTHROUGH reaches LEGACY_UK_ORIGIN with the path intact; each RETIREMENT returns 410; and the BLOCKED_OWNER_APPROVAL water-treatment row is not installed or exercised as a release redirect.
- Confirm no destination in the READY set is draft or absent from cms_route_export.csv. Keep the water-treatment row out of the release until its status changes.
- Repeat the ten highest-inbound-link legacy routes from legacy_url_inventory.csv and record the single-hop result.
- Exercise `/`, a deep US URL, `/de-de/produkte`, `/en-ca/products`, a legacy `/de` URL, and a legacy `/ca` URL with US, DE, and CA cookies plus German and English language headers.
- Request `/_next`, `/assets`, `/api`, `/health`, `/robots.txt`, `/sitemap.xml`, and a file-extension URL with market cookies; none may redirect or rewrite.
- Redirect the pump selector with `pumpModel`, repeated functional parameters, every listed tracking key, and mixed combinations. Functional parameters must survive in order; tracking keys must be absent.
- Render desktop and mobile navigation for each launched locale from the same build and compare item IDs and destinations. Verify the UK selector points to the legacy origin and no `/en-gb` link appears.
- Inspect canonical and alternate markup for AX-410, VX-10, both cavitation articles, a page without an equivalent, and each legal page. Canonicals must be self-referencing; alternates must include only published equivalents.
- Verify both UK-origin environment variables in the release environment before final approval.
