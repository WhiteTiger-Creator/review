# Checkout SDK 4.0 migration plan

Owner: SDK platform. Prepared for the 2026-10-30 review.

This is the whole handoff. The schedule, the merchant-by-merchant actions, the rollback, and the
three source changes are all below; there is no second attachment. An engineer applying this
replaces the two named modules with the listings in "Replacement sources" and adds the regression
suite in "Regression suite" alongside them.

## Migration schedule

Every date below is derived from the packet, and the constraint that actually binds each one is
named so it can be rechecked when something moves.

### The three dates

| Step | Date | Bound by |
|---|---|---|
| Promote 4.0.0 to the channel | 2026-11-12, 15:00 UTC | the seasonal freeze plus the 8 day propagation window |
| Stop writing the v1 record | 2027-01-12 | Duclos Home's app adoption curve |
| Remove the v1 read path | 2027-02-26 | the 45 day cart retention window |

### Promotion: 2026-11-12

`/sdk/v3/checkout.js` is served with `max-age=86400, stale-while-revalidate=604800`. A browser
holding a copy can therefore run the previous build for 86400 plus 604800 seconds, which is
8 days, and purging does not shorten it. That 8 days is the propagation window.

The freeze runs 2026-11-24 00:00 UTC to 2026-12-02 23:59 UTC, and a promotion whose
propagation window runs into the freeze counts as a change inside it. The train runs Tuesdays
and Thursdays at 15:00 UTC. Thursday 2026-11-12 propagates out to 2026-11-20, clear of the
freeze. The next slot, Tuesday 2026-11-17, propagates to 2026-11-25, which is inside it. So
2026-11-12 is the last eligible slot, not a preferred one, and there is no slack behind it: if
we miss it the promotion moves to 2026-12-03 and everything downstream moves with it.

### Dual write: through 2027-01-12

Duclos Home is the constraint. Their storefront is a webview whose document ships inside the
app binary, pinned to 3.6.0, so no channel promotion, purge or resolve change reaches them.
Their next app release is 2026-12-08.

Retirement is measured on the trailing seven day mean of a build's share of non-synthetic
sessions, below 0.5 percent. Applying the previous release's adoption curve in
`app_version_adoption.csv` from 2026-12-08:

- the daily share first dips below 0.5 percent on day 30, which is 2027-01-07
- the trailing seven day mean, which is what the policy specifies, first falls below
  0.5 percent on day 35, which is 2027-01-12

Day 30 is the number a reader gets from the wrong column and it is 5 days early. 3.6.0 is
retired on 2027-01-12, and the dual write runs until then.

Two other builds are already settled. 3.4.1 carried 6,048 sessions in the 21 day telemetry
window and every one of them is MON-11 or MON-12 against the dormant Nagel Tool sandbox, so
its non-synthetic share is zero and it is already retired. 3.7.4 belongs to Aldrich Office
alone and moves when they rebuild.

### Removing the v1 read path: 2027-02-26

The 45 day cart retention window is measured from the date the dual write stops. A v1 record
written on the last day of the dual write stays readable to 2027-02-25, so the read path comes
out on 2027-02-26. Recency at the
time of the pull shows 128,220 shoppers holding a saved cart inside a 45 day window; removing
the read path on 2027-01-12 instead would strand carts across that population, which is the
whole reason the retention window and not the retirement date governs this step.

Nothing about 2027-02-26 depends on Duclos shipping on time. If their release slips, both this
date and the dual write date move with it, and the arithmetic above is the way to recompute
them.

### Merchant actions

Ten merchants need nothing. Four do, and three of those have to happen before 2026-11-12.

| Merchant | Situation | Action | Owner | By |
|---|---|---|---|---|
| M-006 Halloway Pet Supply | service worker caches our bundle for 30 days, which overrides the channel headers in both directions | bump their service worker cache version and deploy it on their Wednesday release | Kowalczyk | 2026-11-11 |
| M-007 Sandoval Textiles | pinned to `/sdk/3.8.2/checkout.js`; an immutable pin never moves | ask them to repoint the embed at the channel; their release process runs about two weeks, so raise it this week | Ruiz | 2026-11-12 |
| M-005 Aldrich Office | server-rendered shell inlines the bundle at their build time, currently a 3.7.4 snapshot | rebuild and deploy after the promotion, before the freeze | Delgado | 2026-11-23 |
| M-009 Duclos Home | 3.6.0 bundled in the app binary | carry 4.0 in the 2026-12-08 app release | Kowalczyk | 2026-12-08 |

Two housekeeping items that are not merchant actions. Vosberg sends Brandt Grocers' tier 1
notice on 2026-11-02; it was missed in the 2026-10-15 batch and the register still reads
`not_sent`. MON-11 and MON-12 should be repointed or retired once 3.4.1 is formally closed,
because a probe against a retired build produces exactly the argument this schedule had to
work around.

Cormier Kitchen is worth one line because it looks like an exception and is not. They embed
the loader, but their storefront document carries `max-age=86400`, so they pick 4.0 up in
about 24 hours rather than the 5 minutes the loader alone implies. That is still inside the
window and needs no action.

### What is not binding

Brandt Grocers' notice clock ends on 2027-01-01, 60 days from the 2026-11-02 send. That is
earlier than both the dual write date and the removal date, so it constrains neither, provided
the notice is actually sent on 2026-11-02. It does bind if it slips past 2026-12-27.

Sandoval Textiles cannot block the promotion either. If they have not repointed by 2026-11-12
we promote anyway and they stay on 3.8.2, which keeps working, because the dual write means an
older build still finds a current cart. Their pin is a reason to keep the v1 record alive, not
a reason to hold the release.

### Rollback

The promotion is revertible for the full 14 days the policy requires, and reverting loses no
shopper data, because the dual write is what makes it safe: every cart 4.0 saves is also
written in the v1 shape, with both `qty` and `count` populated, so 3.8.2 and 3.6.0 both read a
current cart after a revert. Reverting is repointing the channel back at 3.8.2. Per merchant,
setting `cart_v2_migration` to false at resolve turns the migration off without republishing
the bundle, which is the lever to use if one storefront misbehaves rather than reverting the
channel for everyone.

A revert leaves `sdk.cart.v2` in place. Keeping it costs storage and nothing else, and a
shopper who returns after a re-promotion finds their cart where 4.0 left it.

## Replacement sources

### Complete replacement for cart_store.ts

```typescript
/**
 * Persisted cart storage for the hosted checkout SDK.
 *
 * 4.0 keeps both representations alive for the whole transition window. The v1 record is the
 * one older builds read, so it is written on every save and is not removed here; see
 * "Removing the v1 read path" above for the date the v1 half of this file comes out.
 */

const V1_KEY = "sdk.cart.v1";
const V2_KEY = "sdk.cart.v2";
const RETENTION_MS = 45 * 24 * 60 * 60 * 1000;
const SUFFIXED_SKU = /^SKU-[^-]+-([^-]+-[^-]+)$/;

export interface V1Item {
  sku: string;
  qty?: number;
  count?: number;
  addedAt: string;
}

export interface V1Cart {
  cartId: string;
  updatedAt: string;
  items: V1Item[];
  currency: string;
}

export interface V2Line {
  sku: string;
  variantId: string | null;
  quantity: number;
  addedAt: string;
  variantResolved: boolean;
}

export interface V2Cart {
  cartId: string;
  schemaVersion: number;
  updatedAt: string;
  lines: V2Line[];
  currency: string;
}

export type PersistFailure = "quota" | "unavailable";

function readJson<T>(key: string): T | null {
  let raw: string | null;
  try {
    raw = window.localStorage.getItem(key);
  } catch {
    return null;
  }
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

function expired(updatedAt: string): boolean {
  const at = new Date(updatedAt).getTime();
  if (Number.isNaN(at)) return true;
  return Date.now() - at > RETENTION_MS;
}

/**
 * Variant segments of a suffixed SKU, or null when the SKU does not carry one.
 *
 * The suffixed form is SKU-<base>-<color>-<size> and the variant is its two trailing
 * segments. The schema puts no length or alphabet limit on any segment, so neither does
 * this: BLACK-XL and BLU-XXL resolve exactly as BLU-M does. Anything that is not four
 * segments is not the suffixed form.
 *
 * A bare SKU has no variant in the string and none is invented for it; 4.0 resolves it
 * against the merchant catalog at checkout, which is the only place the mapping exists.
 */
export function variantFromSku(sku: string): string | null {
  const match = SUFFIXED_SKU.exec(sku);
  return match ? match[1] : null;
}

/** Quantity as written by either generation of the v1 record. */
export function quantityOf(item: V1Item): number {
  if (typeof item.qty === "number") return item.qty;
  if (typeof item.count === "number") return item.count;
  return 0;
}

export function readV1(): V1Cart | null {
  const cart = readJson<V1Cart>(V1_KEY);
  if (!cart || !Array.isArray(cart.items)) return null;
  if (expired(cart.updatedAt)) return null;
  return cart;
}

export function readV2(): V2Cart | null {
  const cart = readJson<V2Cart>(V2_KEY);
  if (!cart || !Array.isArray(cart.lines)) return null;
  if (expired(cart.updatedAt)) return null;
  return cart;
}

export function toV2(cart: V1Cart): V2Cart {
  return {
    cartId: cart.cartId,
    schemaVersion: 2,
    updatedAt: cart.updatedAt,
    currency: cart.currency,
    lines: cart.items.map((item) => {
      const variantId = variantFromSku(item.sku);
      return {
        sku: item.sku,
        variantId,
        quantity: quantityOf(item),
        addedAt: item.addedAt,
        variantResolved: variantId !== null,
      };
    }),
  };
}

/**
 * The v1 representation of a v2 cart. Both quantity field names are written: 3.7.0 and later
 * prefer qty, and 3.6.x and earlier read count only and see a line as empty without it.
 */
export function toV1(cart: V2Cart): V1Cart {
  return {
    cartId: cart.cartId,
    updatedAt: cart.updatedAt,
    currency: cart.currency,
    items: cart.lines.map((line) => ({
      sku: line.sku,
      qty: line.quantity,
      count: line.quantity,
      addedAt: line.addedAt,
    })),
  };
}

/**
 * The cart the shopper should see. Both keys can be present at once, and the v1 key can be
 * the newer of the two whenever an older build has saved since 4.0 last wrote: a second tab,
 * or a cached older bundle on a return visit. The later updatedAt wins.
 */
export function readCart(): V2Cart | null {
  const v2 = readV2();
  const v1 = readV1();
  if (v2 && v1) {
    return new Date(v1.updatedAt).getTime() > new Date(v2.updatedAt).getTime()
      ? toV2(v1)
      : v2;
  }
  if (v2) return v2;
  return v1 ? toV2(v1) : null;
}

/** Seed the v2 record from v1 without disturbing v1. Safe to call on every boot. */
export function migrate(): V2Cart | null {
  const cart = readCart();
  if (!cart) return null;
  writeCart(cart);
  return cart;
}

/**
 * Save both representations. A quota rejection restores what was there before and reports
 * the failure instead of throwing, because in 3.x the exception escaped into the checkout
 * step and unmounted it.
 */
export function writeCart(cart: V2Cart, onFailure?: (reason: PersistFailure) => void): void {
  const stamped: V2Cart = { ...cart, schemaVersion: 2, updatedAt: new Date().toISOString() };
  let previousV2: string | null = null;
  let previousV1: string | null = null;
  try {
    previousV2 = window.localStorage.getItem(V2_KEY);
    previousV1 = window.localStorage.getItem(V1_KEY);
    window.localStorage.setItem(V2_KEY, JSON.stringify(stamped));
    window.localStorage.setItem(V1_KEY, JSON.stringify(toV1(stamped)));
  } catch (error) {
    restore(V2_KEY, previousV2);
    restore(V1_KEY, previousV1);
    if (onFailure) onFailure(isQuotaError(error) ? "quota" : "unavailable");
  }
}

function restore(key: string, value: string | null): void {
  try {
    if (value === null) window.localStorage.removeItem(key);
    else window.localStorage.setItem(key, value);
  } catch {
    /* storage is already refusing; nothing further to do here */
  }
}

function isQuotaError(error: unknown): boolean {
  const name = (error as { name?: string } | null)?.name ?? "";
  return name === "QuotaExceededError" || name === "NS_ERROR_DOM_QUOTA_REACHED";
}

/** Clears both records. Called when an order is placed, and nowhere else. */
export function clearCart(): void {
  try {
    window.localStorage.removeItem(V1_KEY);
    window.localStorage.removeItem(V2_KEY);
  } catch {
    /* nothing to clear if storage is unavailable */
  }
}
```

### Complete replacement for sdk_bootstrap.ts

```typescript
/**
 * SDK entry point. Resolves which merchant is embedding us, wires the checkout steps, and
 * runs any pending client-side migration before the first step mounts.
 *
 * 4.0. The migration is gated per merchant so a storefront can be held back or rolled back
 * without republishing the bundle.
 */

import { migrate, readCart, V2Cart } from "./cart_store";

declare const __SDK_BUILD__: string;

export interface ResolveResponse {
  merchantId: string;
  channel: "loader" | "channel" | "pinned";
  features: Record<string, boolean>;
}

export const CART_V2_FLAG = "cart_v2_migration";

let resolved: ResolveResponse | null = null;

export async function resolveMerchant(publicKey: string): Promise<ResolveResponse | null> {
  try {
    const response = await fetch(
      `https://cdn.sedlak-commerce.example/sdk/resolve?k=${encodeURIComponent(publicKey)}`,
      { credentials: "omit" },
    );
    if (!response.ok) return null;
    resolved = (await response.json()) as ResolveResponse;
    return resolved;
  } catch {
    return null;
  }
}

/**
 * Off unless resolve has come back and said otherwise. An unresolved merchant is not a
 * merchant we have decided to migrate, and defaulting the other way migrates every storefront
 * whose resolve call failed, including ones deliberately held back.
 */
export function feature(name: string): boolean {
  if (!resolved) return false;
  return resolved.features[name] === true;
}

export function currentBuild(): string {
  return typeof __SDK_BUILD__ === "string" ? __SDK_BUILD__ : "unknown";
}

function readPublicKey(): string {
  const tag = document.currentScript as HTMLScriptElement | null;
  const fromTag = tag?.dataset?.sedlakKey;
  if (fromTag) return fromTag;
  const fallback = document.querySelector<HTMLElement>("[data-sedlak-key]");
  return fallback?.dataset?.sedlakKey ?? "";
}

export async function boot(): Promise<V2Cart | null> {
  const key = readPublicKey();
  if (!key) {
    console.warn("[sdk] no merchant key on the page; checkout will not mount");
    return null;
  }

  await resolveMerchant(key);
  console.log("[sdk] build", currentBuild(), "channel", resolved?.channel ?? "unresolved");

  if (feature(CART_V2_FLAG)) {
    migrate();
  }

  return readCart();
}

export function mount(): void {
  void boot().then((cart) => {
    document.dispatchEvent(new CustomEvent("sedlak:cart-ready", { detail: cart }));
  });
}

if (typeof window !== "undefined") {
  mount();
}
```

## Regression suite

Add this alongside the two replaced modules. It fails against the current sources and passes
against the replacements.

```typescript
/**
 * Transition-window regression cases for cart_store.
 *
 * These cover the states that exist only while two builds are live at once. Run with the
 * bundled runner: no framework, because the suite has to run inside the merchant sandbox
 * image where nothing is installed.
 */

import {
  V1Cart,
  V2Cart,
  clearCart,
  migrate,
  quantityOf,
  readCart,
  toV1,
  variantFromSku,
  writeCart,
} from "./cart_store";

declare const process: { exitCode?: number };

type Store = Record<string, string>;

let store: Store = {};
let quotaAfter = Number.POSITIVE_INFINITY;
let writes = 0;

class QuotaExceededError extends Error {
  constructor() {
    super("quota exceeded");
    this.name = "QuotaExceededError";
  }
}

const fakeStorage = {
  getItem: (k: string): string | null => (k in store ? store[k] : null),
  setItem: (k: string, v: string): void => {
    writes += 1;
    if (writes > quotaAfter) throw new QuotaExceededError();
    store[k] = v;
  },
  removeItem: (k: string): void => {
    delete store[k];
  },
};

(globalThis as unknown as { window: unknown }).window = { localStorage: fakeStorage };

const V1_KEY = "sdk.cart.v1";
const V2_KEY = "sdk.cart.v2";

let failures = 0;

function check(name: string, fn: () => void): void {
  store = {};
  quotaAfter = Number.POSITIVE_INFINITY;
  writes = 0;
  try {
    fn();
    console.log("ok   " + name);
  } catch (error) {
    failures += 1;
    console.log("FAIL " + name + ": " + (error as Error).message);
  }
}

function assert(condition: boolean, message: string): void {
  if (!condition) throw new Error(message);
}

function now(offsetMs = 0): string {
  return new Date(Date.now() + offsetMs).toISOString();
}

function v1Record(items: unknown[], updatedAt = now()): void {
  store[V1_KEY] = JSON.stringify({
    cartId: "c_8f31a2",
    updatedAt,
    items,
    currency: "USD",
  });
}

check("a 3.6.x record keeps its line, because count is read as the quantity", () => {
  v1Record([{ sku: "SKU-7781-GRN-L", count: 1, addedAt: now(-60000) }]);
  const cart = readCart() as V2Cart;
  assert(cart.lines.length === 1, "the line was dropped");
  assert(cart.lines[0].quantity === 1, "count was not read as the quantity");
});

check("a bare SKU carries no invented variant", () => {
  assert(variantFromSku("SKU-4412-BLU-M") === "BLU-M", "suffixed SKU did not resolve");
  assert(variantFromSku("SKU-4412-BLACK-XL") === "BLACK-XL", "a longer colour did not resolve");
  assert(variantFromSku("SKU-4412-BLU-XXL") === "BLU-XXL", "a longer size did not resolve");
  assert(variantFromSku("SKU-9004") === null, "a variant was invented for a bare SKU");
  v1Record([
    { sku: "SKU-4412-BLU-M", qty: 2, addedAt: now(-60000) },
    { sku: "SKU-9004", qty: 1, addedAt: now(-30000) },
  ]);
  const cart = readCart() as V2Cart;
  assert(cart.lines[0].variantResolved === true, "suffixed line not marked resolved");
  assert(cart.lines[1].variantId === null, "bare line carries a variantId");
  assert(cart.lines[1].variantResolved === false, "bare line marked resolved");
});

check("a save writes both quantity field names into the v1 record", () => {
  v1Record([{ sku: "SKU-9004", qty: 3, addedAt: now(-60000) }]);
  migrate();
  const legacy = JSON.parse(store[V1_KEY]) as V1Cart;
  assert(legacy.items[0].count === 3, "count is missing, so 3.6.x reads the line as empty");
  assert(legacy.items[0].qty === 3, "qty is missing, so 3.7.0 and later read the line as empty");
});

check("the v1 record is still present after a v2 save", () => {
  v1Record([{ sku: "SKU-9004", qty: 1, addedAt: now(-60000) }]);
  migrate();
  assert(store[V1_KEY] !== undefined, "the v1 record was removed during the window");
  assert(store[V2_KEY] !== undefined, "the v2 record was not written");
});

check("a later save from an older build wins over the v2 record", () => {
  const older = now(-120000);
  store[V2_KEY] = JSON.stringify({
    cartId: "c_8f31a2",
    schemaVersion: 2,
    updatedAt: older,
    currency: "USD",
    lines: [{ sku: "SKU-9004", variantId: null, quantity: 1, addedAt: older, variantResolved: false }],
  });
  v1Record(
    [
      { sku: "SKU-9004", qty: 1, addedAt: older },
      { sku: "SKU-4412-BLU-M", qty: 2, addedAt: now(-1000) },
    ],
    now(-1000),
  );
  const cart = readCart() as V2Cart;
  assert(cart.lines.length === 2, "the line added by the older build was discarded");
});

check("a quota rejection leaves both records as they were and does not throw", () => {
  v1Record([{ sku: "SKU-9004", qty: 1, addedAt: now(-60000) }]);
  const before = store[V1_KEY];
  const cart = readCart() as V2Cart;
  quotaAfter = writes;
  let reason = "";
  writeCart(cart, (r) => {
    reason = r;
  });
  assert(reason === "quota", "the failure was not reported as a quota rejection");
  assert(store[V1_KEY] === before, "the v1 record was left damaged by a failed save");
  assert(store[V2_KEY] === undefined, "a partial v2 record survived a failed save");
});

check("nothing outside the schema is persisted", () => {
  v1Record([{ sku: "SKU-9004", qty: 1, addedAt: now(-60000) }]);
  migrate();
  const written = store[V1_KEY] + store[V2_KEY];
  for (const banned of ["email", "paymentSessionToken", "token"]) {
    assert(!written.includes(banned), banned + " reached browser storage");
  }
});

check("a record past the 45 day window is not returned", () => {
  v1Record([{ sku: "SKU-9004", qty: 1, addedAt: now(-60000) }], now(-46 * 24 * 60 * 60 * 1000));
  assert(readCart() === null, "an expired record was returned to the shopper");
});

check("a placed order clears both records", () => {
  v1Record([{ sku: "SKU-9004", qty: 1, addedAt: now(-60000) }]);
  migrate();
  clearCart();
  assert(store[V1_KEY] === undefined && store[V2_KEY] === undefined, "a record survived checkout");
});

check("quantityOf and toV1 agree on a line with neither field", () => {
  assert(quantityOf({ sku: "SKU-9004", addedAt: now() }) === 0, "a malformed line is not zero");
  const cart: V2Cart = {
    cartId: "c_1",
    schemaVersion: 2,
    updatedAt: now(),
    currency: "USD",
    lines: [{ sku: "SKU-9004", variantId: null, quantity: 0, addedAt: now(), variantResolved: false }],
  };
  assert(toV1(cart).items[0].count === 0, "the line was dropped rather than carried at zero");
});

if (failures > 0) {
  console.log(failures + " failing case(s)");
  process.exitCode = 1;
} else {
  console.log("all transition-window cases pass");
}
```
