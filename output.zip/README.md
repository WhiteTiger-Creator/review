# Boost.Python Extension Module Demo

This project demonstrates exposing existing C++ functions and classes to Python through a Boost.Python extension module while keeping the native C++ implementation independently usable.


## Requirements

- Apple Silicon macOS
- Python 3.14
- Homebrew
- uv

Install Boost.Python:

    brew install boost-python3

## Project Setup


Extract `project_skeleton.zip` into a working directory.

Extract `cpp_python_demo.zip` into that same directory. The native C++ files from
`project_skeleton.zip` should remain unchanged and sit alongside the binding,
build, and demonstration files.

Create the Python environment:

    uv sync

Build the extension:

    make

Run the demonstration:

    make run

Clean generated build artifacts:

    make clean

The demonstration calls the exposed C++ functions, exercises functions with default arguments, constructs the wrapped C++ class, mutates its state with `set_value`, and verifies the resulting value with `get_value`.
