# Boost.Python Extension Module Demo

This project demonstrates exposing existing C++ functions and classes to Python through a Boost.Python extension module while keeping the native C++ implementation independently usable.


## Requirements

- Python
- C++ compiler with C++14 support
- Boost and Boost.Python
- uv

This project has been tested on Apple Silicon macOS with Python 3.14 and Homebrew.

On macOS with Homebrew:

Install Boost & Boost.Python:
```bash
brew install boost boost-python3
```

On Linux, install Boost and Boost.Python development packages using your distribution's package manager.

For nonstandard Boost installations, the build supports these overrides:

- `BOOST_ROOT` - Boost installation prefix
- `BOOST_LIBRARYDIR` - directory containing the Boost.Python library
- `BOOST_PYTHON_LIB` - Boost.Python library name

macOS example:

	BOOST_ROOT=/opt/homebrew/opt/boost make

Linux example for Python 3.14:

	BOOST_ROOT=/opt/boost BOOST_LIBRARYDIR=/opt/boost/lib BOOST_PYTHON_LIB=boost_python314 make


## Project Setup

Place the provided input files alongside these files.

Create the Python environment:

```bash
uv sync
```

Build the extension:

```bash
make
```

Run the demonstration:

```bash
make run
```

Clean generated build artifacts:

```bash
make clean
```

The demonstration calls the exposed C++ functions, exercises functions with default arguments, constructs the wrapped C++ class, mutates its state with `set_value`, and verifies the resulting value with `get_value`.
