import { useEffect } from "react";

type HomeEnvelope = {
  experimentId: "EXP-HOME-27";
  assignmentVersion: 3;
  sessionId: string;
  variant: "A" | "B";
  assignmentToken: string;
};

type ExposureProps = {
  assignment: HomeEnvelope;
  renderedVariant: "A" | "B";
};

type EventKind = "exposure" | "conversion";

function stateKey(kind: EventKind, a: HomeEnvelope): string {
  return ["home-exp", kind, a.experimentId, a.assignmentVersion,
    a.sessionId, a.assignmentToken].join(":");
}

async function report(kind: EventKind, props: ExposureProps): Promise<boolean> {
  const a = props.assignment;
  if (props.renderedVariant !== a.variant) return false;

  const exposureKey = stateKey("exposure", a);
  if (kind === "conversion" && sessionStorage.getItem(exposureKey) !== "sent") {
    return false;
  }

  const idempotencyKey = stateKey(kind, a);
  const priorState = sessionStorage.getItem(idempotencyKey);
  if (priorState === "sent") return true;
  if (priorState === "sending") return false;
  sessionStorage.setItem(idempotencyKey, "sending");

  try {
    const response = await fetch("/analytics/experiment", {
      method: "POST",
      keepalive: true,
      headers: {
        "content-type": "application/json",
        "idempotency-key": idempotencyKey,
      },
      body: JSON.stringify({
        eventType: kind === "exposure" ? "EXPOSURE" : "CONVERSION",
        ...a,
      }),
    });
    if (!response.ok) throw new Error(`experiment event returned ${response.status}`);
    sessionStorage.setItem(idempotencyKey, "sent");
    return true;
  } catch (error) {
    // Keep the key stable for the retry; only the transient state is cleared.
    sessionStorage.removeItem(idempotencyKey);
    throw error;
  }
}

export function HomepageExposure(props: ExposureProps) {
  useEffect(() => {
    // Do not import the assignment helper here. The server envelope is the assignment.
    void report("exposure", props);
  }, [props.assignment.assignmentToken, props.renderedVariant]);
  return null;
}

export function recordPaidStart(props: ExposureProps): Promise<boolean> {
  return report("conversion", props);
}
