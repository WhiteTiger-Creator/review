# Linden DST scheduling cutover review

**Release:** SR-118  
**Decision:** **HOLD public booking traffic.** The corrected implementation may proceed through tests, shadow mode, and internal staff validation, but public traffic must remain paused until the five blocked requests are reselected, the three confirmed wrong-instant bookings are placed with Client Services, and the four calendar-only corrections are generated from their current booking versions.

## What failed

Three defects compounded. `current_slot_builder.ts` treats BOS, CHI, and PHX as fixed numeric offsets. That makes Boston and Chicago one hour late after March 14 and incorrectly makes Phoenix follow a national clock change. It also cannot represent a gap or both sides of an overlap. `current_booking_form.tsx` reparses an office label in the browser zone, builds a new slot ID, and posts a client-derived instant. T016–T019 prove that the same office label becomes a different instant in Los Angeles, London, Denver, or New York. `current_calendar_invite.ts` reconstructs `DTSTART` from the local label and emits floating values, so `SENT` is only transport evidence.

The server booking response is the authority. A correct browser rendering may be reformatted without changing a booking. A wrong accepted instant requires client confirmation and a versioned server reschedule. A rejected command created no booking to repair.

## Booking disposition

| Booking | Disposition | Governing evidence | Required action |
|---|---|---|---|
| B001 | VALID_UNCHANGED | 09:00 Boston before transition equals 14:00Z; CAL-001 agrees | none |
| B002 | CORRECT_INVITE | accepted 13:00Z is correct for 09:00 Boston after transition; CAL-002 says 14:00Z | send version-1 invite with 13:00Z–13:45Z |
| B003 | CLIENT_CONFIRMATION | client acknowledged 09:00 Boston, but accepted 14:00Z represents 10:00 | Nora confirms and submits a versioned reschedule to 13:00Z only with client approval |
| B004 | CLIENT_CONFIRMATION | client acknowledged 09:00 Chicago, but accepted 15:00Z represents 10:00 | Grace confirms and submits a versioned reschedule to 14:00Z only with client approval |
| B005 | CLIENT_CONFIRMATION | Phoenix 09:00 must remain 16:00Z; accepted instant is 15:00Z | Camila confirms and submits a versioned reschedule to 16:00Z only with client approval |
| B006 | VALID_UNCHANGED | Phoenix control remains 16:00Z and CAL-006 agrees | none |
| B007 | BLOCKED_RESELECT | 2027-03-14 02:30 Boston is nonexistent; no instant accepted | refresh availability; do not coerce |
| B008 | BLOCKED_RESELECT | Boston 01:30 overlap has two candidates and no choice | require EARLIER or LATER on a fresh slot |
| B009 | VALID_UNCHANGED | explicit EARLIER resolves to 05:30Z; invite agrees | none |
| B010 | VALID_UNCHANGED | explicit LATER resolves to 06:30Z; invite agrees | none |
| B011 | BLOCKED_RESELECT | submitted availability revision 11; current is 12 | refresh slots after STALE_AVAILABILITY |
| B012 | VALID_UNCHANGED | same idempotency key returned the same 15:00Z booking and one invite | none |
| B013 | BLOCKED_RESELECT | active hold owned by another request | refresh after HOLD_ACTIVE; do not choose a neighbor |
| B014 | BLOCKED_RESELECT | confirmed count equals capacity | refresh after CAPACITY_FULL; do not choose a neighbor |
| B015 | CORRECT_INVITE | accepted 15:00Z is correct; CAL-015 is a floating 09:00 | replace with version-1 15:00Z–15:45Z invite |
| B016 | VALID_UNCHANGED | cancellation succeeded and current version is 2 | retain cancelled state and cancellation delivery |
| B017 | VALID_UNCHANGED | stale cancellation was rejected; confirmed version 2 and CAL-017 remain correct | show current confirmed state |
| B018 | VALID_UNCHANGED | accepted 13:00Z is 09:00 Boston and 06:00 Los Angeles | retain both labelled displays |
| B019 | VALID_UNCHANGED | accepted 14:00Z is 09:00 Chicago and 14:00 London | retain both labelled displays |
| B020 | CORRECT_INVITE | reschedule version 2 accepted 17:00Z; only superseded version-1 invite exists | issue version-2 replacement for 17:00Z–17:45Z |
| B021 | VALID_UNCHANGED | stale reschedule did not change confirmed version 2 at 13:00Z | show current booking; do not apply rejected request |
| B022 | VALID_UNCHANGED | Chicago 09:00 after transition correctly equals 14:00Z | none |
| B023 | VALID_UNCHANGED | explicit Chicago EARLIER correctly equals 06:30Z | none |
| B024 | CORRECT_INVITE | accepted Phoenix instant is 16:00Z; CAL-024 is floating 09:00 | replace with version-1 16:00Z–16:45Z invite |

Totals: 12 valid or validly cancelled records remain unchanged, 4 need calendar-only replacement, 3 require client confirmation before rescheduling, and 5 remain blocked for fresh selection.

## Replacement for `current_slot_builder.ts`

```typescript
import {
  chooseCandidate,
  OffsetChoice,
  resolveOfficeLocal,
} from './timezone_adapter';

export type Availability = {
  availabilityId: string;
  officeId: 'BOS' | 'CHI' | 'PHX';
  officeTz: string;
  localDate: string;
  localStart: string;
  durationMinutes: number;
  capacity: number;
  confirmedCount: number;
  holdUntil?: string;
  revision: number;
};

export type Slot = {
  slotId: string;
  officeId: string;
  officeTz: string;
  officeLocalStart: string;
  startUtc: string;
  endUtc: string;
  availabilityRevision: number;
  capacityRemaining: number;
  offsetChoice: OffsetChoice | null;
};

function makeSlot(record: Availability, choice?: OffsetChoice): Slot {
  const officeLocalStart = `${record.localDate}T${record.localStart}`;
  const resolution = resolveOfficeLocal(officeLocalStart, record.officeTz);
  const startUtc = chooseCandidate(resolution, choice);
  const endUtc = new Date(
    Date.parse(startUtc) + record.durationMinutes * 60_000,
  ).toISOString();
  const suffix = choice ? `-${choice}` : '';
  return {
    slotId: `${record.availabilityId}-R${record.revision}${suffix}`,
    officeId: record.officeId,
    officeTz: record.officeTz,
    officeLocalStart,
    startUtc,
    endUtc,
    availabilityRevision: record.revision,
    capacityRemaining: record.capacity - record.confirmedCount,
    offsetChoice: choice ?? null,
  };
}

export function buildSlots(records: Availability[], nowIso: string): Slot[] {
  const now = Date.parse(nowIso);
  const seen = new Set<string>();
  const output: Slot[] = [];

  for (const record of records) {
    if (record.confirmedCount >= record.capacity) continue;
    if (record.holdUntil && Date.parse(record.holdUntil) > now) continue;
    const local = `${record.localDate}T${record.localStart}`;
    const resolution = resolveOfficeLocal(local, record.officeTz);
    if (resolution.kind === 'NONEXISTENT') continue;
    const candidates = resolution.kind === 'AMBIGUOUS'
      ? [makeSlot(record, 'EARLIER'), makeSlot(record, 'LATER')]
      : [makeSlot(record)];

    for (const slot of candidates) {
      const identity = `${slot.officeId}|${slot.startUtc}`;
      if (seen.has(identity)) continue;
      seen.add(identity);
      output.push(slot);
    }
  }
  return output.sort((a, b) => a.startUtc.localeCompare(b.startUtc));
}
```

The recurrence remains in each office wall clock because every date is resolved through its IANA zone. The gap produces no slot; the overlap produces two separately identified server candidates. Phoenix is resolved through `America/Phoenix`, not a March switch. Active holds and full capacity are excluded, while expired holds do not suppress a slot. De-duplication includes office and UTC instant, so identical labels across offices and the two overlap candidates remain distinct.

## Replacement for `current_booking_form.tsx`

```tsx
import { useMemo, useRef, useState } from 'react';
import { formatInZone } from './timezone_adapter';

type Slot = {
  slotId: string;
  officeId: string;
  officeTz: string;
  officeLocalStart: string;
  startUtc: string;
  endUtc: string;
  availabilityRevision: number;
  capacityRemaining: number;
  offsetChoice: 'EARLIER' | 'LATER' | null;
};

type Props = {
  slots: Slot[];
  refreshSlots(): Promise<void>;
};

export function BookingForm({ slots, refreshSlots }: Props) {
  const [selectedSlotId, setSelectedSlotId] = useState('');
  const [message, setMessage] = useState('');
  const keys = useRef(new Map<string, string>());
  const clientZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const selected = slots.find((slot) => slot.slotId === selectedSlotId);

  const options = useMemo(() => slots.map((slot) => {
    const office = formatInZone(slot.startUtc, slot.officeTz);
    const client = formatInZone(slot.startUtc, clientZone);
    const overlap = slot.offsetChoice ? ` — ${slot.offsetChoice}` : '';
    return { slot, label: `${office} ${slot.officeTz} / ${client} ${clientZone}${overlap}` };
  }), [slots, clientZone]);

  async function submit(): Promise<void> {
    if (!selected) return;
    const idempotencyKey = keys.current.get(selected.slotId) ?? crypto.randomUUID();
    keys.current.set(selected.slotId, idempotencyKey);
    const response = await fetch('/v6/bookings', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        slot_id: selected.slotId,
        availability_revision: selected.availabilityRevision,
        idempotency_key: idempotencyKey,
        client_display_zone: clientZone,
      }),
    });
    if (response.status === 409) {
      setSelectedSlotId('');
      setMessage('Availability changed. Choose a refreshed slot.');
      await refreshSlots();
      return;
    }
    if (!response.ok) {
      setMessage('Booking was not accepted. Keep this selection for support review.');
      return;
    }
    const accepted = await response.json();
    setMessage(`Confirmed ${formatInZone(accepted.start_utc, accepted.office_tz)} ${accepted.office_tz}`);
  }

  return (
    <form onSubmit={(event) => { event.preventDefault(); void submit(); }}>
      <label htmlFor="slot">Consultation time</label>
      <select id="slot" value={selectedSlotId} onChange={(event) => setSelectedSlotId(event.target.value)}>
        <option value="">Choose a time</option>
        {options.map(({ slot, label }) => (
          <option key={slot.slotId} value={slot.slotId}>{label}</option>
        ))}
      </select>
      <button type="submit" disabled={!selected}>Book</button>
      <p aria-live="polite">{message}</p>
    </form>
  );
}
```

The command contains the server slot ID, revision, stable idempotency key, and display zone only. It does not post a client-computed instant. A 409 clears the stale selection and refreshes; it never books a nearby slot. Office and client displays are both labelled, and overlap choices remain visible in distinct server options.

## Replacement for `current_calendar_invite.ts`

```typescript
import { formatInZone, toIcsUtc } from './timezone_adapter';

type AcceptedBooking = {
  bookingId: string;
  bookingVersion: number;
  officeId: string;
  officeTz: string;
  startUtc: string;
  endUtc: string;
  clientDisplayZone?: string;
};

function escapeIcs(value: string): string {
  return value.replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/,/g, '\\,').replace(/;/g, '\\;');
}

export function createInvite(booking: AcceptedBooking): string {
  const office = `${formatInZone(booking.startUtc, booking.officeTz)} ${booking.officeTz}`;
  const client = booking.clientDisplayZone
    ? `${formatInZone(booking.startUtc, booking.clientDisplayZone)} ${booking.clientDisplayZone}`
    : null;
  const description = client ? `Office: ${office}\nClient: ${client}` : `Office: ${office}`;
  return [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Linden Regulatory Advisors//Scheduling v6.2//EN',
    'BEGIN:VEVENT',
    `UID:${booking.bookingId}@linden.example`,
    `SEQUENCE:${booking.bookingVersion}`,
    `DTSTART:${toIcsUtc(booking.startUtc)}`,
    `DTEND:${toIcsUtc(booking.endUtc)}`,
    `DESCRIPTION:${escapeIcs(description)}`,
    'END:VEVENT',
    'END:VCALENDAR',
  ].join('\r\n');
}
```

The generator accepts only the authoritative booking response. `DTSTART`, `DTEND`, and `SEQUENCE` therefore track the accepted UTC interval and current version. Office and client labels are descriptive only.

## Regression cases

| ID | Exact case | Expected result |
|---|---|---|
| Q01 | BOS `2027-03-12T09:00` | unique 14:00Z |
| Q02 | BOS `2027-03-15T09:00` | unique 13:00Z; office label remains 09:00 |
| Q03 | CHI `2027-03-12T09:00` then `2027-03-15T09:00` | 15:00Z then 14:00Z |
| Q04 | PHX `2027-03-12T09:00` and `2027-03-15T09:00` | both 16:00Z |
| Q05 | BOS and CHI `2027-03-14T02:30` | NONEXISTENT; no slot and no coercion |
| Q06 | BOS `2027-11-07T01:30` without choice | candidates 05:30Z and 06:30Z; selection required |
| Q07 | BOS overlap with EARLIER then LATER | 05:30Z then 06:30Z |
| Q08 | CHI overlap with EARLIER then LATER | 06:30Z then 07:30Z |
| Q09 | PHX `2027-11-07T01:30` | one candidate 08:30Z |
| Q10 | BOS 09:00 rendered in Los Angeles, London, and Tokyo browsers | slot ID and 13:00Z stay unchanged; displays are labelled |
| Q11 | CHI 10:00 and BOS 10:00 with matching labels | distinct office slot IDs; neither is deduplicated into the other |
| Q12 | availability revision 11 submitted when current is 12 | 409 STALE_AVAILABILITY; refresh and no automatic retry |
| Q13 | active hold and capacity-full rows | excluded; expired hold may be offered |
| Q14 | identical booking command and idempotency key twice | one booking and the same response; changed command with same key is 422 |
| Q15 | stale reschedule or cancellation version | 409 and accepted booking remains unchanged |
| Q16 | accepted reschedule version 2 | calendar `SEQUENCE:2` and UTC values from version 2 |
| Q17 | B002 invite replacement | `DTSTART:20270315T130000Z`; `DTEND:20270315T134500Z` |
| Q18 | B015 and B024 replacements | 15:00Z–15:45Z and 16:00Z–16:45Z; no floating values |

## Correction and rollout

1. Keep new bookings paused, retain the exports and delivery logs, and prevent replacement invites from the current generator.
2. Deploy the three corrected modules behind the scheduling release flag and run Q01–Q18 plus the 24 supplied probes in the simulator.
3. In read-only shadow, compare generated slot IDs and UTC candidates without creating bookings or calendar deliveries.
4. Route B003 to Nora, B004 to Grace, and B005 to Camila. Record the client decision; only an approved server reschedule may change the accepted instant.
5. After unchanged-instant verification, Samir issues replacements for B002, B015, B020, and B024 using their current versions. B007, B008, B011, B013, and B014 receive fresh-selection handling rather than appointment creation.
6. Promote to internal staff, then 10%, 50%, and 100%. At each stage compare accepted booking responses with portal confirmations and ICS UTC fields.

Promotion requires zero fixed-offset conversions, zero gap slots, an explicit choice on every overlap, zero client-derived booking identities, zero stale-revision or stale-version writes, no cross-office de-duplication, and exact invite agreement with accepted `start_utc`, `end_utc`, and `booking_version`. Roll back immediately on any accepted-instant mutation, silent gap coercion, inferred overlap, stale overwrite, duplicate booking from one idempotency key, or invite UTC mismatch.

Web Scheduling owns slot and form evidence. Platform Time owns adapter behavior. Scheduling Operations owns availability, holds, and capacity. Nora, Grace, and Camila own client confirmation in their offices. Calendar Integrations owns versioned replacements. Release Engineering owns staged promotion and rollback. Public booking resumes only after every non-valid row has an owner and the 50% gate completes without a stop condition.
