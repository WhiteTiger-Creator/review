// Replacement for the limiter that produced the 2026-08-20 incident. Three things
// changed and all three matter: the bucket is keyed on the API key instead of the
// caller address, it refills continuously instead of resetting on the minute, and
// the counter lives in the shared store so six nodes spend one allowance between
// them rather than six. Weights and reserve arithmetic come from the rating
// platform contract, sections 5 to 7.

import type { NextFunction, Request, Response } from "express";

const MINUTE_MS = 60_000;

export const COST_UNITS: Record<string, number> = {
  "POST /v3/quotes": 10,
  "POST /v3/shipments": 6,
  "GET /v3/shipments/:id/tracking": 1,
  "GET /v3/service-points": 1,
  "GET /v3/health": 0,
};

export type KeyRecord = {
  keyId: string;
  environment: "production" | "sandbox" | "internal";
  status: "active" | "suspended" | "terminated";
  sustainedUnitsPerMin: number;
};

type BucketResult = { allowed: boolean; tokens: number };

export interface TokenBucketStore {
  consume(
    key: string,
    cost: number,
    capacity: number,
    refillPerMs: number,
    atMs: number,
  ): Promise<BucketResult>;
}

// Specs and the local harness only. Production injects the shared-store adapter at
// bootstrap - if this class ever shows up in a production bootstrap we are back to
// per-node counters and the incident repeats itself.
export class MemoryTokenBucketStore implements TokenBucketStore {
  private buckets = new Map<string, { tokens: number; touchedAt: number }>();

  async consume(key: string, cost: number, capacity: number, refillPerMs: number, atMs: number) {
    const old = this.buckets.get(key) ?? { tokens: capacity, touchedAt: atMs };
    const elapsed = Math.max(0, atMs - old.touchedAt);
    const available = Math.min(capacity, old.tokens + elapsed * refillPerMs);
    const allowed = available >= cost;
    const tokens = allowed ? available - cost : available;

    this.buckets.set(key, { tokens, touchedAt: atMs });
    return { allowed, tokens };
  }
}

export type Decision = {
  keyId: string;
  route: string;
  cost: number;
  allowed: boolean;
  limit: number;
  remaining: number;
  retryAfterSec: number;
  enforced: boolean;
};

export type LimiterOptions = {
  store: TokenBucketStore;
  lookupKey: (req: Request) => KeyRecord | undefined;
  observeOnly?: boolean;
  onDecision?: (decision: Decision) => void;
  now?: () => number;
};

export function routeOf(req: Request): string {
  return `${req.method} ${req.route?.path ?? req.path}`;
}

export function costOf(route: string): number {
  const cost = COST_UNITS[route];
  if (cost === undefined) throw new Error(`missing rate weight: ${route}`);
  return cost;
}

// Never advertise a wait of zero seconds on a refusal; a client that reads
// Retry-After: 0 hot-loops, which is most of what we saw in the trace.
function secondsFor(units: number, refillPerMs: number): number {
  if (refillPerMs <= 0) return 60;
  return Math.max(1, Math.ceil(units / refillPerMs / 1000));
}

export function rateLimiter(opts: LimiterOptions) {
  const clock = opts.now ?? Date.now;

  return async function partnerRateLimit(req: Request, res: Response, next: NextFunction) {
    const route = routeOf(req);

    // Health goes first, before the key lookup. The load balancer does not carry a
    // key and we are not taking the platform down over that again.
    if (route === "GET /v3/health") return next();

    const key = opts.lookupKey(req);
    if (!key) {
      res.status(401).json({ error: "unauthenticated" });
      return;
    }
    if (key.status !== "active") {
      res.status(403).json({ error: "key_not_active" });
      return;
    }
    if (key.environment !== "production") return next();

    const cost = costOf(route);
    const limit = key.sustainedUnitsPerMin;
    const capacity = limit * 2; // burst is one minute of sustained held in reserve
    const refillPerMs = limit / MINUTE_MS;

    // PLAT-1188 follow-up: the API key is the identity. Do not put XFF here - two
    // partners sit behind the Vogel egress address and throttling one of them
    // took out the other.
    const bucket = await opts.store.consume(
      `partner-rate:${key.keyId}`,
      cost,
      capacity,
      refillPerMs,
      clock(),
    );

    const remaining = Math.floor(bucket.tokens);
    const retryAfterSec = bucket.allowed
      ? 0
      : secondsFor(cost - bucket.tokens, refillPerMs);
    const resetSec = secondsFor(capacity - bucket.tokens, refillPerMs);

    opts.onDecision?.({
      keyId: key.keyId,
      route,
      cost,
      allowed: bucket.allowed,
      limit,
      remaining,
      retryAfterSec,
      enforced: !opts.observeOnly,
    });

    res.setHeader("RateLimit-Limit", String(limit));
    res.setHeader("RateLimit-Remaining", String(remaining));
    res.setHeader("RateLimit-Reset", String(resetSec));

    if (bucket.allowed || opts.observeOnly) return next();

    res.setHeader("Retry-After", String(retryAfterSec));
    res.status(429).json({ error: "rate_limited", retry_after: retryAfterSec });
  };
}
