# cak_force.py -- modified (finite-disk) CAK line force + validation driver
#
# Line force from Castor Abbott Klein 1975, with the m-CAK constant finite-disk
# factor C_fd(a) = (1-a)/(1+2a) adopted for this task (PPK86 form; the CAK75
# paper does not give this constant expression).  The force multiplier follows
# CAK75 eq. 12, M(t)=k*t**(-a).  Mass loss is the pressure-free critical-point
# result and v_inf uses q(SpT)*v_esc_eff.  Calculations are cgs unless noted.
#
# The fixed q table was calibrated once from the survey's vinf/vesc ratios.
# Per-star model calls do not use either reference column; the validation
# driver reads them only after calculating Mdot and v_inf.
#
# Usage:  python cak_force.py --input-dir . --output-dir validation_outputs

import argparse
import csv
import json
import math
from pathlib import Path

C = 2.99792458e10      # cm/s
G = 6.67430e-8         # cm^3 g^-1 s^-2
MSUN = 1.98847e33      # g
RSUN = 6.957e10        # cm
SIGMA = 5.670374419e-5 # erg cm^-2 s^-1 K^-4
KB = 1.380649e-16      # erg/K
MH = 1.6735575e-24     # g
YR = 365.25 * 86400.0  # s

# Mean survey v_inf/v_esc_eff by spectral class, rounded after calibration.
Q_TABLE = {'O': 2.80, 'B': 2.20, 'A': 0.80}

#La fonction kappa_es calcule l'opacité de diffusion Thomson pour les électrons en fonction de la fraction massique d'hydrogène X. Elle retourne une valeur en cm^2/g.
def kappa_es(X=0.7):
    """Thomson electron scattering opacity, cm^2/g. X = H mass fraction (dimensionless)."""
    return 0.20 * (1.0 + float(X))

# La fonction v_thermal calcule la vitesse thermique isotherme en fonction de la température T et du poids moléculaire moyen mu. Elle retourne une valeur en cm/s.
def v_thermal(T, mu=1.0):
    """Isothermal thermal speed sqrt(2 k T / (mu m_H)) in cm/s. T in Kelvin, mu dimensionless."""
    return math.sqrt(2.0 * KB * T / (mu * MH))

#la fonction lum_from_R_T calcule la luminosité d'une étoile en fonction de son rayon R (en rayons solaires) et de sa température effective Teff (en Kelvin). Elle retourne une valeur en erg/s.
def lum_from_R_T(R_rsun, Teff):
    """L = 4 pi R^2 sigma Teff^4 in erg/s. R in solar radii, Teff in Kelvin."""
    r = R_rsun * RSUN
    return 4.0 * math.pi * r * r * SIGMA * Teff**4

# La fonction gamma_e calcule le facteur d'Eddington pour les électrons en fonction de la luminosité L (en erg/s), de la masse M (en masses solaires) et de la fraction massique d'hydrogène X. Elle retourne une valeur sans dimension.
def gamma_e(L, M_msun, X=0.7):
    """Electron Eddington factor, dimensionless. L in erg/s, M in solar masses."""
    return kappa_es(X) * L / (4.0 * math.pi * G * M_msun * MSUN * C)


def g_grav(r_cm, M_msun, Gamma):
    """Effective inward gravity G M (1-Gamma)/r^2 in cm/s^2. r_cm in cm, M in solar masses, Gamma dimensionless."""
    return G * M_msun * MSUN * (1.0 - Gamma) / (r_cm * r_cm)

# Mise à jour du 08/09/2023 : validation explicite de 0 < alpha < 1
# avant le calcul du facteur de disque fini.
def c_fd(a):
    """Adopted m-CAK finite-disk factor (1-a)/(1+2a), dimensionless. Needs 0 < a < 1."""
    if not 0.0 < a < 1.0:
        raise ValueError('alpha must be between 0 and 1')
    return (1.0 - a) / (1.0 + 2.0 * a)


def line_force(r_cm, L, k, a, kappa_e, rho, dvdr, v_th, finite_disk=True):
    """CAK line acceleration g_L in cm/s^2.

    r_cm radius [cm], L luminosity [erg/s], k and a the CAK line-distribution
    parameters (dimensionless), kappa_e opacity [cm^2/g], rho density [g/cm^3],
    dvdr velocity gradient [s^-1], v_th thermal speed [cm/s].

    CAK75 defines t = kappa_e*rho*v_th/dvdr and M(t) = k*t**(-a),
    so the inverse-depth bracket below carries exponent a.  The Boulder port
    uses the same convention; see report section 2.
    """
    if min(r_cm, L, k, kappa_e, rho, dvdr, v_th) <= 0.0:
        raise ValueError('dimensional inputs and k must all be positive')
    if not 0.0 < a < 1.0:
        raise ValueError('alpha must be between 0 and 1')
    electron_accel = kappa_e * L / (4.0 * math.pi * r_cm**2 * C)
    multiplier = k * pow(dvdr / (kappa_e * rho * v_th), a)
    if finite_disk:
        multiplier *= c_fd(a)
    return electron_accel * multiplier


def v_esc_eff(M_msun, R_rsun, Gamma):
    """Effective surface escape speed sqrt(2 G M (1-Gamma) / R) in cm/s. M in solar masses, R in solar radii."""
    return math.sqrt(2.0 * G * M_msun * MSUN * (1.0 - Gamma) / (R_rsun * RSUN))


def terminal_velocity(M_msun, R_rsun, Gamma, sptype):
    """v_inf in cm/s, as q(SpT) * v_esc_eff. M in solar masses, R in solar radii,
    Gamma dimensionless, sptype e.g. 'B0Ia' (first letter picks q)."""
    letter = sptype.strip().upper()[:1]
    if letter not in Q_TABLE:
        raise ValueError('no q ratio adopted for class ' + repr(sptype))
    return Q_TABLE[letter] * v_esc_eff(M_msun, R_rsun, Gamma)


def cak_mdot(M_msun, R_rsun, Teff, k, a, X=0.7, mu=1.0):
    """CAK critical-point mass-loss rate in g/s.

    Inputs: M [solar masses], R [solar radii], Teff [K], CAK k and alpha
    (dimensionless), H fraction X and mean molecular weight mu (dimensionless).
    Pressure-free critical result; Mdot scales as (k*C_fd)^(1/a).
    """
    if not 0.0 < a < 1.0:
        raise ValueError('alpha must be between 0 and 1')
    kap = kappa_es(X)
    L = lum_from_R_T(R_rsun, Teff)
    Gam = gamma_e(L, M_msun, X)
    vt = v_thermal(Teff, mu)
    gmeff = G * M_msun * MSUN * (1.0 - Gam)

    # With y=r^2*v*dv/dr, singularity and momentum balance give
    # y_c = a*GM_eff/(1-a).  Solving the CAK eigenvalue for Mdot then gives
    # the expression below (pressure-free form of the CAK75 eq. 46 scaling).
    ycrit = a * gmeff / (1.0 - a)
    electron_force_scale = kap * L / (4.0 * math.pi * C)
    drive = a * electron_force_scale * k * c_fd(a)
    return (4.0 * math.pi / (kap * vt)
            * drive**(1.0 / a)
            * ycrit**(-(1.0 - a) / a))


def read_csv_rows(path):
    """Read a task CSV, normalizing headings to lowercase; values stay as text."""
    with open(path, newline='', encoding='utf-8-sig') as f:
        rd = csv.DictReader(f)
        if not rd.fieldnames:
            raise ValueError(str(path) + ' has no header')
        return [{str(k).strip().lower(): (v or '').strip() for k, v in row.items()}
                for row in rd]


def validate_profile(path, star):
    """Evaluate one tabulated profile and return one diagnostics dict per row.

    ``path`` names a CSV whose dimensional fields are radius [cm], velocity
    [km/s or cm/s], density [g/cm^3], and velocity gradient [s^-1]. ``star``
    supplies mass [solar masses], radius [solar radii], and Teff [K], plus
    dimensionless X, k, and alpha. Returned radius, velocity, density, and
    gradient use cm, cm/s, g/cm^3, and s^-1; every force-balance term uses
    cm/s^2, and the relative residual is dimensionless.
    """
    mass = float(star['m_msun'])
    rad = float(star['r_rsun'])
    teff = float(star['teff_k'])
    X = float(star['x_frac'])
    k = float(star['k'])
    a = float(star['alpha'])
    L = lum_from_R_T(rad, teff)
    kap = kappa_es(X)
    Gam = gamma_e(L, mass, X)
    vt = v_thermal(teff)
    rst = rad * RSUN

    out = []
    for n, row in enumerate(read_csv_rows(path), start=2):
        try:
            r = float(row['r_cm'])
            v = 1.0e5 * float(row['v_kms'])
            rho = float(row['rho_gcm3'])
            grad = float(row['dvdr_per_s'])
        except (KeyError, TypeError, ValueError) as e:
            raise ValueError('%s row %d: %s' % (path, n, e))
        gL = line_force(r, L, k, a, kap, rho, grad, vt)
        gg = g_grav(r, mass, Gam)
        inertia = v * grad
        net = gL - gg
        res = inertia - net
        scale = max(abs(inertia), abs(net), 1e-30)
        out.append({'radius_cm': r, 'r_over_rstar': r / rst,
                    'velocity_cm_s': v, 'density_g_cm3': rho, 'dvdr_s1': grad,
                    'g_line_cm_s2': gL, 'g_grav_eff_cm_s2': gg,
                    'net_radiative_cm_s2': net, 'v_dvdr_cm_s2': inertia,
                    'momentum_residual_cm_s2': res,
                    'relative_residual': res / scale})
    return out


def validate_survey_star(star):
    """Model and compare one survey star without reference-value leakage.

    ``star`` supplies mass [solar masses], radius [solar radii], Teff [K], and
    dimensionless X, k, and alpha. The returned model/reference mass-loss rates
    use solar masses/year, terminal velocities use km/s, and Gamma and relative
    errors are dimensionless. References never feed the modeled quantities.
    """
    mass = float(star['m_msun'])
    rad = float(star['r_rsun'])
    teff = float(star['teff_k'])
    X = float(star['x_frac'])
    k = float(star['k'])
    a = float(star['alpha'])
    sp = star.get('spectral_type', 'O')
    Gam = gamma_e(lum_from_R_T(rad, teff), mass, X)

    mdot = cak_mdot(mass, rad, teff, k, a, X) / MSUN * YR
    vinf = terminal_velocity(mass, rad, Gam, sp) / 1.0e5
    mdot_ref = float(star['mdot_msun_yr'])
    vinf_ref = float(star['vinf_kms'])
    return {'star_id': star.get('star_id', '').upper(),
            'spectral_type': sp, 'gamma_e': Gam,
            'mdot_model_msun_yr': mdot, 'mdot_ref_msun_yr': mdot_ref,
            'mdot_rel_err': abs(mdot - mdot_ref) / mdot_ref,
            'vinf_model_kms': vinf, 'vinf_ref_kms': vinf_ref,
            'vinf_rel_err': abs(vinf - vinf_ref) / vinf_ref}


def main():
    """CLI entry: validate all 12 profiles and the 12-star survey, write CSV/JSON outputs."""
    ap = argparse.ArgumentParser()
    ap.add_argument('--input-dir', default='.')
    ap.add_argument('--output-dir', default='validation_outputs')
    ap.add_argument('--linelist', default='survey_linelist.csv')
    ap.add_argument('--residual-tol', type=float, default=0.10)
    ap.add_argument('--survey-tol', type=float, default=0.01)
    args = ap.parse_args()
    indir = Path(args.input_dir)
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)

    stars = {}
    for row in read_csv_rows(indir / args.linelist):
        sid = row.get('star_id', '').upper()
        if not sid:
            raise SystemExit('Survey row is missing star_id')
        if sid in stars:
            raise SystemExit('Duplicate survey star_id: ' + sid)
        stars[sid] = row

    expected_ids = {'S%02d' % n for n in range(1, 13)}
    if set(stars) != expected_ids:
        raise SystemExit('Expected survey star IDs S01-S12; found ' +
                         ', '.join(sorted(stars)))

    profiles = sorted(indir.glob('wind_profile_S*.csv'))
    expected_names = {'wind_profile_S%02d.csv' % n for n in range(1, 13)}
    found_names = {p.name for p in profiles}
    if found_names != expected_names:
        missing = sorted(expected_names - found_names)
        extra = sorted(found_names - expected_names)
        raise SystemExit('Expected exactly wind_profile_S01.csv through '
                         'wind_profile_S12.csv; missing=%s extra=%s' % (missing, extra))

    pts, psum = [], []
    for p in profiles:
        sid = p.stem.split('_')[-1].upper()
        if sid not in stars:
            raise SystemExit(p.name + ': ' + sid + ' absent from linelist')
        diag = validate_profile(p, stars[sid])
        for i, d in enumerate(diag, start=1):
            pts.append({'star_id': sid, 'profile_file': p.name, 'row_number': i, **d})
        arel = [abs(d['relative_residual']) for d in diag]
        psum.append({'star_id': sid, 'profile_file': p.name, 'points': len(diag),
                     'median_abs_relative_residual': sorted(arel)[len(arel) // 2],
                     'max_abs_relative_residual': max(arel),
                     'fraction_within_tolerance': sum(x <= args.residual_tol for x in arel) / len(arel),
                     'force_balance_status': 'CONSISTENT' if max(arel) <= args.residual_tol
                     else 'PRESCRIBED_PROFILE_NOT_FORCE_BALANCED'})

    srows = []
    for sid in sorted(stars):
        r = validate_survey_star(stars[sid])
        r['pass_within_tolerance'] = 'PASS' if (r['mdot_rel_err'] <= args.survey_tol
                                                and r['vinf_rel_err'] <= args.survey_tol) else 'FAIL'
        srows.append(r)

    for fname, rows in [('profile_force_diagnostics.csv', pts),
                        ('profile_validation_summary.csv', psum),
                        ('survey_validation.csv', srows)]:
        with (out / fname).open('w', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(rows)
    (out / 'validation_summary.json').write_text(
        json.dumps({'profiles': psum, 'survey': srows}, indent=2), encoding='utf-8')

    nbad = sum(1 for r in psum if r['force_balance_status'] != 'CONSISTENT')
    npass = sum(1 for r in srows if r['pass_within_tolerance'] == 'PASS')
    print('Validated %d profiles and %d tabulated points.' % (len(profiles), len(pts)))
    print('%d/%d profiles are prescribed structures that do not close the reduced '
          'pressure-free CAK momentum equation (tolerance %s).'
          % (nbad, len(profiles), args.residual_tol))
    print('%d/%d survey stars reproduce Mdot and v_inf within %.0f%%.'
          % (npass, len(srows), 100 * args.survey_tol))
    if len(pts) != 2412:
        raise SystemExit('Expected 2412 tabulated points, validated %d' % len(pts))
    if npass != 12:
        raise SystemExit('Survey validation failed: only %d/12 stars pass' % npass)


if __name__ == '__main__':
    main()
