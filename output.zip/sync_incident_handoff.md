# Red Mesa Offline Sync Recovery Handoff

Submission archive: red_mesa_sync_recovery.zip

This is the master document for the Red Mesa production recovery kit. The supporting components are `recovery_actions.csv`, `attachment_actions.csv`, and `sync_worker.ts`. Web Engineering owns controlled replay and worker deployment; Field Systems Support owns queue cleanup, evidence holds, attachment checks, and inspector follow-up.

## Incident reconstruction and recovery boundary

The tablet statement that synchronization had finished cannot be used as the recovery boundary. Several requests reached the server but their acknowledgements did not persist locally, while other rows represent actual prerequisites or conflicts. Device time is also unreliable: dev-a's NTP correction reversed the displayed times for sequences 41 and 42 without changing their committed device sequence. The run therefore starts from event key, payload hash, receipt, server revision, and device sequence—not queue_state or the newest local timestamp.

The current package permits automatic work only when those sources agree. It does not force Q-004, Q-005, Q-011, or Q-014 through the API. Q-004 is especially important: R-2002 confirms that the status field itself can be rebased, but the contract separately requires a finalized overview before SUBMITTED. Dana's paper packet says the overview box was checked; that is not attachment-ledger proof. The ledger has no row for TMP-B17 or INSP-8402. North 02 therefore remains revision 5 DRAFT until Field Support locates the overview, verifies it, links and finalizes it, or takes the missing evidence back to the inspector. No replay order is assigned to Q-004 in this run.

## Controlled recovery sequence

### 1. Reconcile receipts before any mutation

Close Q-001 and Q-002 locally against R-1001 without another patch. Q-003 receives its missing acknowledgement from R-2001 and remains INSP-8402 revision 5 with the west-flange note. Commit the TMP-D44→INSP-8404 mapping from R-4001 while acknowledging Q-006 in the same transaction; do the same for TMP-F70→INSP-8407 from R-7001 and Q-010. Q-012 is an acknowledgement repair against R-8001 and stays revision 3 COMPLETE. A matching event key and payload hash already marked APPLIED or CREATED is an acknowledgement, not permission to resend.

After the Q-006 mapping commit, relink the completed ATT-440 object to INSP-8404. Do not upload its three chunks again. ATT-701 and ATT-801 already have permanent links and matching checksums, so they receive no work.

### 2. Establish holds before opening replay lanes

Keep Q-004 in the North 02 prerequisite hold described above. Q-005 targets the terminal INSP-8403 tombstone; close the queue row without a patch or replacement create and retain its payload in the incident evidence. Q-011 reused EV-F701 with a different payload hash after dev-k inherited dev-f's key seed. Quarantine that row and ATT-702 together, leave target_server_id blank, and create no live TMP-K70 record.

Q-014 remains held because its queued field_note conflicts with the same field changed on the server at revision 4. Dana Wu and Jordan must compare both texts; automation must not select the newer timestamp. ATT-1001 remains unlinked because received checksum 0d71a6cf differs from expected 6b92c840. Recover the tablet original before any new upload decision.

### 3. Repair attachment prerequisites

For ATT-660, retain multipart chunks 1, 2, and 4. Upload only chunk 3 to the existing multipart upload, verify the completed object against expected checksum 17b9c662, and finalize once. Q-009 changes no inspection field; INSP-8406 stays revision 2.

ATT-901 is complete and its expected and received checksums match. Relink and finalize it against INSP-8409 before releasing Q-013. Replay the original EV-H901 key only after the overview link is visible. A successful status request moves INSP-8409 from revision 2 DRAFT to revision 3 SUBMITTED.

### 4. Run ordered record work

For INSP-8405, execute dev-a sequence 41 before sequence 42 even though sequence 41 has the later device_time. Q-007 changes condition to LEAKING at revision 4. Only after that acknowledgement may Q-008 change it to ISOLATED at revision 5.

Run Q-015 after the existing-record attachment work. Create the planned West 02 inspection, commit the returned server ID and local queue acknowledgement transactionally, and then rewrite ATT-1101's link from TMP-L11 to that returned ID. The new inspection remains revision 1 DRAFT because the field sheet has no submit mark.

## Worker correction and concurrency

`sync_worker.ts` opens one ascending device_seq lane per device. Before sending, it serializes work by stable event key, reconciles receipts, and stops a device lane on a different-hash collision or terminal conflict. A second keyed lock covers the inspection identity: existing records use server ID, while an unsent create uses its temporary ID. Consequently, two device lanes cannot mutate the same inspection at the same time even though different devices may make progress concurrently.

Create mappings and acknowledgements commit together. Dependent work waits for the mapping. HTTP 409 and 422 outcomes are checkpointed for rebase or prerequisite review instead of being retried indefinitely. On restart, the worker reloads pending rows and performs the same receipt reconciliation before selecting another mutation.

## Verification record

Run the following checks after each phase and retain the results with the incident:

- **Receipt and duplicate check:** group receipts by event_key and payload_hash. Q-001/Q-002 must still correspond to one APPLIED mutation. Simulate a lost acknowledgement and a same-key/same-hash retry; the second pass must write only an ACK_RECONCILED checkpoint.
- **Collision check:** present the dev-k EV-F701 hash beside the applied dev-f hash. The worker must quarantine the collision, stop that device lane, and issue no request for TMP-K70.
- **Inspection-lock check:** make two test device lanes ready for the same server ID. Instrument `api.send`; the second call must not begin until the first call exits and its checkpoint is written.
- **Mapping check:** restart after a CREATE receipt but before local cleanup. The worker must commit the receipt's mapping without another create, and dependent attachment work must use the committed server ID.
- **North 02 prerequisite check:** query attachment records by TMP-B17 and INSP-8402 for required_role OVERVIEW and finalize_status COMPLETE. The supplied snapshot returns no qualifying row, so Q-004 remains held and INSP-8402 remains revision 5 DRAFT.
- **Clock-skew check:** assert that dev-a sequence 41 is sent and acknowledged before sequence 42. Final INSP-8405 state must be revision 5 ISOLATED.
- **Revision-conflict check:** a stale revision touching a field unchanged since base may enter a rebase checkpoint, but a stale event touching the same changed field must remain held. This separates Q-004's potential future rebase from Q-014's human note conflict without bypassing Q-004's attachment prerequisite.
- **Tombstone check:** query INSP-8403 and require revision 4 DELETED with its tombstone intact. There must be no replayed patch or replacement create from Q-005.
- **Multipart check:** for ATT-660, storage must retain chunks 1, 2, and 4, receive only chunk 3, show one finalization, and match checksum 17b9c662. For ATT-901, require its live INSP-8409 overview link before the Q-013 receipt.
- **Attachment-link check:** require ATT-440→INSP-8404, ATT-660→INSP-8406, ATT-701→INSP-8407, ATT-801→INSP-8408, and ATT-901→INSP-8409. ATT-702 and ATT-1001 must have no live inspection link. ATT-1101 must link to the new West 02 ID, not to PENDING_NEW_MAPPING.
- **Restart check:** stop the worker after one successful event in a test lane. The restarted process must reload its checkpoint, reconcile receipts, and select the next device-sequence event without repeating the first mutation.

## Expected end state and open ownership

INSP-8401 and INSP-8408 receive local acknowledgement cleanup only. INSP-8402 stays revision 5 DRAFT until Field Support proves and finalizes its overview; Dana Wu owns the inspector follow-up. INSP-8403 remains deleted. INSP-8405 ends revision 5 ISOLATED. INSP-8409 ends revision 3 SUBMITTED after ATT-901 is linked. INSP-8410 remains revision 4 DRAFT with its note and image evidence held for Dana and Jordan. West 02 receives a new server ID at revision 1 DRAFT.

Recovery is not complete if an already-applied event gains a second mutation receipt, if two device lanes overlap on one inspection, if a temporary object scheduled for relinking remains under its temporary prefix, if any quarantined object gains a live link, or if Q-004 is released without a finalized North 02 overview.
