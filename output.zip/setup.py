import ctypes.util
import glob
import os
import shutil
import subprocess
import sys
import sysconfig

from setuptools import Extension, setup
from setuptools.command.build_ext import build_ext

PYTAG = f"{sys.version_info.major}{sys.version_info.minor}"
PYDOT = f"{sys.version_info.major}.{sys.version_info.minor}"

def brew_prefix(formula):
    if not shutil.which("brew"):
        return None

    try:
        return subprocess.check_output(
            ["brew", "--prefix", "--installed", formula],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip() or None
    except subprocess.CalledProcessError:
        return None


def has_boost(prefix):
    return bool(prefix) and os.path.exists(
        os.path.join(prefix, "include", "boost", "python.hpp")
    )


def find_boost():
    candidate = os.environ.get("BOOST_ROOT")
    if candidate:
        if not has_boost(candidate):
            sys.stderr.write(
                f"warning: BOOST_ROOT={candidate} does not contain "
                "include/boost/python.hpp\n"
            )
        return candidate

    # Prefer normal system installations.
    for candidate in ("/usr/local", "/usr", "/opt/local"):
        if has_boost(candidate):
            return candidate

    # Homebrew is a fallback.
    candidate = brew_prefix("boost")
    if has_boost(candidate):
        return candidate

    return None


def find_boost_python_lib(dirs):
    override = os.environ.get("BOOST_PYTHON_LIB")
    if override:
        return override

    candidates = [
        f"boost_python{PYTAG}",
        f"boost_python{PYDOT}",
        f"boost_python-py{PYTAG}",
        f"boost_python-py{sys.version_info.major}",
        "boost_python3",
        "boost_python",
    ]

    # Check explicitly known library directories first.
    for name in candidates:
        for directory in dirs:
            if glob.glob(os.path.join(directory, f"lib{name}.*")):
                return name

    # Then let the platform's normal linker/library cache help.
    for name in candidates:
        if ctypes.util.find_library(name):
            return name

    # Preserve a useful default; BOOST_PYTHON_LIB can override it.
    return candidates[0]


prefix = find_boost()

include_dirs = ["."]
library_dirs = []

if prefix:
    include_dirs.append(os.path.join(prefix, "include"))

    prefix_lib = os.path.join(prefix, "lib")
    if os.path.isdir(prefix_lib):
        library_dirs.append(prefix_lib)


# Explicit library-directory override.
boost_library_dir = os.environ.get("BOOST_LIBRARYDIR")
if boost_library_dir:
    library_dirs.append(boost_library_dir)


# Common Debian/Ubuntu multiarch library directory.
multiarch = sysconfig.get_config_var("MULTIARCH")
if multiarch:
    multiarch_lib = os.path.join("/usr/lib", multiarch)
    if os.path.isdir(multiarch_lib):
        library_dirs.append(multiarch_lib)


# Homebrew Boost.Python library is often a separate formula.
homebrew_boost_python = brew_prefix("boost-python3")
if homebrew_boost_python:
    homebrew_boost_python_lib = os.path.join(
        homebrew_boost_python,
        "lib",
    )
    if os.path.isdir(homebrew_boost_python_lib):
        library_dirs.append(homebrew_boost_python_lib)


# Remove duplicates while preserving order.
library_dirs = list(dict.fromkeys(library_dirs))
include_dirs = list(dict.fromkeys(include_dirs))

boost_python_lib = find_boost_python_lib(library_dirs)


class PortableBuildExt(build_ext):
    def build_extensions(self):
        compiler_type = self.compiler.compiler_type

        if compiler_type == "msvc":
            cpp_args = ["/std:c++14"]
        else:
            cpp_args = ["-std=c++14"]

        for extension in self.extensions:
            extension.extra_compile_args = cpp_args

        super().build_extensions()


extension_name = "ExtensionExample"
extension_version = "1.0"

source_files = [
    "boost_python_wrapper.cpp",
    "functions_to_wrap.cpp",
    "classes_to_wrap.cpp",
]

setup(
        name=extension_name,
        version=extension_version,
		cmdclass={"build_ext": PortableBuildExt},
        ext_modules=[
            Extension(
                extension_name,
                source_files,
                include_dirs=include_dirs,
                library_dirs=library_dirs,
                libraries=[boost_python_lib],
                language='c++'
            )
        ],
    )
