from setuptools import setup, Extension

# define the name of the extension to use
extension_name = 'ExtensionExample'
extension_version = '1.0'

# define the directories to search for include files
# to get this to work, you may need to include the path
# to your boost installation. Mine was in
# '/usr/local/include', hence the corresponding entry.
include_dirs = ['/opt/homebrew/opt/boost/include', '.']

# define the library directories to include any extra
# libraries that may be needed.  The boost::python
# library for me was located in '/usr/local/lib'
library_dirs = ['/opt/homebrew/opt/boost/lib']

# define the libraries to link with the boost python library
libraries = ['boost_python314']

# define the source files for the extension
source_files = ['boost_python_wrapper.cpp',
                'functions_to_wrap.cpp',
                'classes_to_wrap.cpp']

# create the extension and add it to the python distribution
setup(name=extension_name,
      version=extension_version,
      ext_modules=[Extension(
          extension_name,
          source_files,
          include_dirs=include_dirs,
          extra_compile_args=['-arch', 'arm64', '-std=c++11'],
          extra_link_args=['-arch', 'arm64'],
          extra_objects=['/opt/homebrew/opt/boost-python3/lib/libboost_python314.dylib']
    )]
)
