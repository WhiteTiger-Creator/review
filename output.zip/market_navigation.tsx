import Link from 'next/link';

export type LaunchedLocale = 'en-us' | 'de-de' | 'en-ca';

type MarketPaths = Partial<Record<LaunchedLocale, { label: string; href: string }>>;
type NavDefinition = { id: string; paths: MarketPaths };

// This is the single launch-approved collection used by both render variants.
// A missing locale entry means the CMS export has no releasable market route.
const NAV_ITEMS: NavDefinition[] = [
  {
    id: 'products',
    paths: {
      'en-us': { label: 'Products', href: '/products' },
      'de-de': { label: 'Produkte', href: '/de-de/produkte' },
      'en-ca': { label: 'Products', href: '/en-ca/products' },
    },
  },
  {
    id: 'solutions',
    paths: {
      'en-us': { label: 'Solutions', href: '/solutions' },
      'de-de': { label: 'Lösungen', href: '/de-de/loesungen' },
    },
  },
  {
    id: 'learning',
    paths: {
      'en-us': { label: 'Learning Center', href: '/learning-center' },
      'de-de': { label: 'Wissen', href: '/de-de/wissen' },
    },
  },
  {
    id: 'tools',
    paths: {
      'en-us': { label: 'Tools', href: '/tools/pump-selector' },
    },
  },
  {
    id: 'support',
    paths: {
      'en-us': { label: 'Support', href: '/support' },
    },
  },
  {
    id: 'contact-de',
    paths: {
      'de-de': { label: 'Kontakt', href: '/de-de/support/kontakt' },
    },
  },
  {
    id: 'about',
    paths: {
      'en-us': { label: 'About', href: '/about' },
    },
  },
];

function itemsFor(locale: LaunchedLocale) {
  return NAV_ITEMS.flatMap((item) => {
    const localized = item.paths[locale];
    return localized ? [{ id: item.id, ...localized }] : [];
  });
}

function NavigationItems({ locale }: { locale: LaunchedLocale }) {
  return (
    <ul>
      {itemsFor(locale).map((item) => (
        <li key={item.id}>
          <Link href={item.href}>{item.label}</Link>
        </li>
      ))}
    </ul>
  );
}

export function DesktopNavigation({ locale }: { locale: LaunchedLocale }) {
  return <NavigationItems locale={locale} />;
}

export function MobileNavigation({ locale }: { locale: LaunchedLocale }) {
  return <NavigationItems locale={locale} />;
}

export function MarketSelector() {
  const legacyUkOrigin = process.env.NEXT_PUBLIC_LEGACY_UK_ORIGIN;
  return (
    <ul aria-label="Market selector">
      <li><Link href="/">United States</Link></li>
      <li><Link href="/de-de">Deutschland</Link></li>
      <li><Link href="/en-ca">Canada (English)</Link></li>
      {legacyUkOrigin ? (
        <li><a href={legacyUkOrigin}>United Kingdom — legacy site</a></li>
      ) : null}
    </ul>
  );
}
