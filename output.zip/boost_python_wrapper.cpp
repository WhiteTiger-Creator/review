#include<boost/python.hpp>

#include"functions_to_wrap.h"
#include"classes_to_wrap.h"

using namespace boost::python;

// generate overloads for default arguments, this example is a function
// that takes a minimum of 1 argument and a maximum of four. the 
// overloads are generated in num_arguments_overloads, which is 
// then supplied to boost::python when defining the wrapper
BOOST_PYTHON_FUNCTION_OVERLOADS( num_arguments_overloads, num_arguments, 1, 4 );

// generate wrapper code for both the functions and classes
BOOST_PYTHON_MODULE(ExtensionExample){
	// declare the functions to wrap. note inclusion of the
	// num_arguments_overloads() to include the overloads 
	// that handle default function arguments
	def( "get_string",       get_string );
	def( "are_values_equal", are_values_equal );
	def( "num_arguments",    num_arguments, num_arguments_overloads() );
	
	// declare the classes to wrap. both the default
	// constructor and the constructor taking an 
	// integer argument are exposed
	class_<wrapped_class>("wrapped_class",init<>())
	.def(init<int>())
	.def("get_value", &wrapped_class::get_value )
	.def("set_value", &wrapped_class::set_value )
	;
}