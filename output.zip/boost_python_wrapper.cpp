#include<boost/python.hpp>

#include "functions_to_wrap.h"
#include "classes_to_wrap.h"

using namespace boost::python;

BOOST_PYTHON_MODULE(ExtensionExample)
{
    def("get_string", get_string);
    def("are_values_equal", are_values_equal);

    def(
        "num_arguments",
        num_arguments,
        (
            arg("arg0"),
            arg("arg1") = false,
            arg("arg2") = false,
            arg("arg3") = false
        )
    );

    class_<wrapped_class>("wrapped_class", init<>())
        .def(init<int>())
        .def("get_value", &wrapped_class::get_value)
        .def("set_value", &wrapped_class::set_value);
}
