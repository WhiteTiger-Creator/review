export type LaunchedLocale = 'en-us' | 'de-de' | 'en-ca';

export type CmsPage = {
  locale: LaunchedLocale;
  path: string;
  contentType: 'home' | 'listing' | 'category' | 'product' | 'article' | 'vertical' | 'legal' | 'form' | 'download' | 'tool';
  published: boolean;
  modelId?: string;
  familyId?: string;
};

type PageMetadata = {
  alternates?: {
    canonical: string;
    languages?: Record<string, string>;
  };
  robots: { index: boolean; follow: boolean };
};

const ORIGIN = 'https://www.atlasindustrial.com';
const LANGUAGE: Record<LaunchedLocale, string> = {
  'en-us': 'en-US',
  'de-de': 'de-DE',
  'en-ca': 'en-CA',
};

function absolute(path: string): string {
  const normalized = path === '/' ? '/' : `/${path.replace(/^\/+|\/+$/g, '')}`;
  return new URL(normalized, ORIGIN).toString().replace(/\/$/, normalized === '/' ? '/' : '');
}

function equivalent(a: CmsPage, b: CmsPage): boolean {
  if (a.contentType === 'legal' || b.contentType === 'legal') return false;
  if (a.contentType === 'product' && b.contentType === 'product') {
    return Boolean(a.modelId && a.modelId === b.modelId);
  }
  return Boolean(a.familyId && a.familyId === b.familyId);
}

export function buildMetadata(page: CmsPage, allPages: CmsPage[]): PageMetadata {
  // Redirect and retirement handlers do not call this function. A defensive
  // noindex remains in place if an unpublished CMS record reaches rendering.
  if (!page.published) return { robots: { index: false, follow: false } };

  const canonical = absolute(page.path);
  const publishedEquivalents = allPages.filter(
    (candidate) => candidate.published && equivalent(page, candidate),
  );
  const languages: Record<string, string> = {};

  for (const candidate of publishedEquivalents) {
    languages[LANGUAGE[candidate.locale]] = absolute(candidate.path);
  }

  // Include the current page in a language cluster when it has an explicit
  // family/model identity. Standalone pages receive only a self-canonical.
  if (page.modelId || page.familyId) {
    languages[LANGUAGE[page.locale]] = canonical;
    const usEquivalent = publishedEquivalents.find((candidate) => candidate.locale === 'en-us');
    if (page.locale === 'en-us') languages['x-default'] = canonical;
    else if (usEquivalent) languages['x-default'] = absolute(usEquivalent.path);
  }

  return {
    alternates: {
      canonical,
      ...(Object.keys(languages).length ? { languages } : {}),
    },
    robots: { index: true, follow: true },
  };
}
