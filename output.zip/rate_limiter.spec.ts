import { describe, expect, it } from "vitest";
import {
  costOf,
  MemoryTokenBucketStore,
  rateLimiter,
  type Decision,
  type KeyRecord,
} from "./rate_limiter";

const KEYS: Record<string, KeyRecord> = {
  brtn: { keyId: "key_live_brtn", environment: "production", status: "active", sustainedUnitsPerMin: 900 },
  kpln: { keyId: "key_live_kpln", environment: "production", status: "active", sustainedUnitsPerMin: 900 },
  nrby: { keyId: "key_live_ekst", environment: "production", status: "active", sustainedUnitsPerMin: 900 },
  dlta: { keyId: "key_live_whtc", environment: "production", status: "active", sustainedUnitsPerMin: 300 },
  vntg: { keyId: "key_live_nagy", environment: "production", status: "terminated", sustainedUnitsPerMin: 0 },
  sbx: { keyId: "key_sbx_sndr", environment: "sandbox", status: "active", sustainedUnitsPerMin: 0 },
  chkt: { keyId: "key_int_chkt", environment: "internal", status: "active", sustainedUnitsPerMin: 0 },
};

type Ctx = { status: number; headers: Record<string, string>; nexted: boolean; body: unknown };

function harness(opts: { observeOnly?: boolean; store?: MemoryTokenBucketStore } = {}) {
  const store = opts.store ?? new MemoryTokenBucketStore();
  let clock = 1_000_000;
  const decisions: Decision[] = [];
  const mw = rateLimiter({
    store,
    observeOnly: opts.observeOnly,
    now: () => clock,
    onDecision: (d) => decisions.push(d),
    lookupKey: (req) => KEYS[(req.header as (n: string) => string | undefined)("x-api-key") ?? ""],
  });

  async function call(apiKey: string, method: string, path: string): Promise<Ctx> {
    const ctx: Ctx = { status: 200, headers: {}, nexted: false, body: undefined };
    const req = { method, path, header: (n: string) => (n === "x-api-key" ? apiKey : undefined) };
    const res = {
      setHeader: (n: string, v: string) => { ctx.headers[n] = v; },
      status: (s: number) => { ctx.status = s; return res; },
      json: (b: unknown) => { ctx.body = b; return res; },
    };
    await mw(req as never, res as never, () => { ctx.nexted = true; });
    return ctx;
  }

  return { call, decisions, store, advance: (ms: number) => { clock += ms; }, at: () => clock };
}

describe("partner API rate limiter", () => {
  it("prices a request by endpoint cost rather than by request count", () => {
    expect(costOf("POST /v3/quotes")).toBe(10);
    expect(costOf("POST /v3/shipments")).toBe(6);
    expect(costOf("GET /v3/shipments/:id/tracking")).toBe(1);
    expect(costOf("GET /v3/service-points")).toBe(1);
    expect(() => costOf("POST /v3/unknown")).toThrow();
  });

  it("gives partners behind one shared egress address independent buckets", async () => {
    const h = harness();
    // Drain Bratton completely: capacity is 1800 units, so 180 quotes.
    for (let i = 0; i < 180; i += 1) await h.call("brtn", "POST", "/v3/quotes");
    const bratton = await h.call("brtn", "POST", "/v3/quotes");
    expect(bratton.status).toBe(429);
    // Kaplan shares 198.51.100.24 with Bratton and must be untouched.
    const kaplan = await h.call("kpln", "POST", "/v3/quotes");
    expect(kaplan.status).toBe(200);
    expect(kaplan.nexted).toBe(true);
  });

  it("does not refill a full allowance at a minute boundary", async () => {
    const h = harness();
    for (let i = 0; i < 180; i += 1) await h.call("brtn", "POST", "/v3/quotes");
    expect((await h.call("brtn", "POST", "/v3/quotes")).status).toBe(429);
    // Two seconds later, across what a calendar-window limiter would treat as a
    // reset, only two seconds of refill is available: 900/60000 per ms is 30
    // units, which buys three quotes. A fixed window would have restored all 180.
    h.advance(2_000);
    let allowed = 0;
    for (let i = 0; i < 180; i += 1) {
      if ((await h.call("brtn", "POST", "/v3/quotes")).status === 200) allowed += 1;
    }
    expect(allowed).toBe(3);
  });

  it("allows three times the sustained allowance in a minute from idle and no more", async () => {
    const h = harness();
    let allowed = 0;
    for (let i = 0; i < 400; i += 1) {
      if ((await h.call("dlta", "POST", "/v3/quotes")).status === 200) allowed += 1;
    }
    expect(allowed * 10).toBe(600); // burst capacity, twice the sustained 300
    h.advance(60_000);
    allowed = 0;
    for (let i = 0; i < 400; i += 1) {
      if ((await h.call("dlta", "POST", "/v3/quotes")).status === 200) allowed += 1;
    }
    expect(allowed * 10).toBe(300); // one minute of refill, capped at the sustained rate
  });

  it("returns Retry-After and the RateLimit headers on a throttled response", async () => {
    const h = harness();
    for (let i = 0; i < 180; i += 1) await h.call("brtn", "POST", "/v3/quotes");
    const throttled = await h.call("brtn", "POST", "/v3/quotes");
    expect(throttled.status).toBe(429);
    expect(Number(throttled.headers["Retry-After"])).toBeGreaterThanOrEqual(1);
    expect(throttled.headers["RateLimit-Limit"]).toBe("900");
    expect(throttled.headers["RateLimit-Remaining"]).toBe("0");
    expect(Number(throttled.headers["RateLimit-Reset"])).toBeGreaterThan(0);
    expect(throttled.body).toMatchObject({ error: "rate_limited" });
  });

  it("never answers a throttling decision with 503", async () => {
    const h = harness();
    const seen = new Set<number>();
    for (let i = 0; i < 200; i += 1) seen.add((await h.call("brtn", "POST", "/v3/quotes")).status);
    expect(seen.has(429)).toBe(true);
    expect(seen.has(503)).toBe(false);
  });

  it("exempts the health endpoint and asks it for no key", async () => {
    const h = harness();
    const health = await h.call("", "GET", "/v3/health");
    expect(health.nexted).toBe(true);
    expect(health.status).toBe(200);
  });

  it("refuses a terminated key instead of serving it an allowance", async () => {
    const h = harness();
    const res = await h.call("vntg", "POST", "/v3/quotes");
    expect(res.status).toBe(403);
    expect(res.nexted).toBe(false);
  });

  it("does not enforce a partner allocation on sandbox or internal keys", async () => {
    const h = harness();
    for (let i = 0; i < 500; i += 1) {
      expect((await h.call("sbx", "POST", "/v3/quotes")).nexted).toBe(true);
      expect((await h.call("chkt", "POST", "/v3/quotes")).nexted).toBe(true);
    }
  });

  it("records the decision without applying it in observe-only mode", async () => {
    const h = harness({ observeOnly: true });
    for (let i = 0; i < 200; i += 1) await h.call("brtn", "POST", "/v3/quotes");
    const over = await h.call("brtn", "POST", "/v3/quotes");
    expect(over.nexted).toBe(true);
    expect(over.status).toBe(200);
    const refused = h.decisions.filter((d) => !d.allowed);
    expect(refused.length).toBeGreaterThan(0);
    expect(refused.every((d) => d.enforced === false)).toBe(true);
  });

  it("holds one allowance across nodes that share the store", async () => {
    const shared = new MemoryTokenBucketStore();
    const nodeA = harness({ store: shared });
    const nodeB = harness({ store: shared });
    let allowed = 0;
    for (let i = 0; i < 120; i += 1) {
      if ((await nodeA.call("nrby", "POST", "/v3/quotes")).status === 200) allowed += 1;
      if ((await nodeB.call("nrby", "POST", "/v3/quotes")).status === 200) allowed += 1;
    }
    // 1800 units of burst, spent once in total rather than once per node.
    expect(allowed * 10).toBe(1800);
  });
});
