# Partner API rate limiting: enforcement redesign and allocation

Platform Engineering, Sanderson Logistics
For the tier launch review, 2026-09-01
## Decision

Replace the enforcement path before the tier launch, and change two allocations. The proposed allocations total **5,940 cost units per minute** against a partner budget of 6,300, which leaves 360 units of headroom. There is no room for the enterprise partner Sales is working; that answer is in the arithmetic below and it does not depend on the enforcement change.

## Why the 20 August afternoon happened

The limiter counts requests, in each node's memory, against a calendar minute, keyed on the client address. Each of those four choices fails on its own and they compound.

**It counts the wrong thing.** A quote costs ten units and a tracking read costs one. A flat allowance of 240 requests admits 2,400 units of quoting or 240 units of tracking, a tenfold difference in load behind an identical counter. The platform is sized in cost units and nothing in the enforcement path knew that.

**It keys on the address.** Bratton Supply, Kaplan Home and Prieto Medical Supply are three separate customers who share the egress address 198.51.100.24 because Vogel Integrations hosts all three. They share one bucket. That is the whole content of tickets SUP-4471, SUP-4488, SUP-4502, SUP-4510 and SUP-4540, and it is why Prieto is being throttled at a third of its own allowance. Partner Operations has now told Prieto twice that it does not share a quota with another customer, which today is not true.

**It counts per node.** Vogel holds one pooled connection, so all 358 of its requests in the 14:22 minute landed on api-03 and 118 of them were rejected. Ostrander opens a fresh connection per request, so its 612 requests spread across all six nodes at roughly 100 each, and no node ever reached 240. Ostrander was not throttled once during the incident it caused. The limiter failed closed for the customers behaving well and failed open for the one that was not.

**It resets on a calendar boundary.** The trace shows Vogel reaching 240 at 14:22:41, being refused for the rest of the minute, then passing 240 more between 14:23:00 and 14:23:18. That is 480 requests in thirty-seven seconds against a limit meant to permit 240 in sixty.

**It answers without `Retry-After`.** Every 429 in the trace omits it. Kaplan has asked for it twice in writing, in SUP-4488 and SUP-4547, and says plainly it cannot implement backoff without it. Ostrander's client retried six times at intervals between 37 and 44 milliseconds after each timeout. A throttled client with nothing to wait on retries immediately, and an immediate retry is indistinguishable from an attack.

The first-party consequence follows from all of it: checkout draws quotes from the same rating pool, so `key_int_chkt` took timeouts at 14:22:52 and 14:23:06. The people affected were not partners.

## Capacity arithmetic

The rating platform sustains 9,000 cost units per minute. The reserve is 30 percent, or 2,700 units, and first-party checkout draws on it at an observed 1,900. The partner budget is the remaining **6,300**.

Production partners are allocated **6,240** units today, which leaves 60 units of headroom. Their combined observed 95th-percentile use is **4,685** units per minute. The platform is not short of capacity; the allocations are simply the wrong shape, and one of them is held by a partner that left.

Two changes settle it.

**Ekstrom Freight is under-allocated.** Its observed p95 is 420 units against a Standard default of 300. Enforcing the Standard default would cut traffic the partner is already sending, which contract section 5 defines as a service reduction. Ekstrom also gave notice in SUP-4536 that it onboards forty-one store locations from 2026-10-01 and expects roughly a third more quoting. Move it to Growth at 900. Cost: 600 units. This is a service increase, so it owes no notice period and takes effect on the next billing period as an amendment note.

**Nagy Parcel still holds 900 units.** The agreement terminated on 2026-06-30, the integration stopped on 2026-07-02, and Partner Operations marked the key terminated on 2026-08-03 after the export window closed. Contract section 5 returns that allocation to the budget. Partner Operations has asked twice whether this had been done; it had not.

Proposed total: 6,240 + 600 - 900 = **5,940**, against a budget of 6,300. Headroom rises from 60 to **360** units per minute.

Ferraro Retail Group is worth stating explicitly, because its p95 of 840 sits under its 900 floor and looks trimmable. It is not. MSA-2025-014 clause 6.4 makes 900 a floor, and clause 6.9 says a seasonal increase inside that committed capacity is not excess use. Ferraro's quoting traffic rises in Q4. It holds 900, it is not trimmed, and the Q4 rise is not an excess-use event.

Every other allocation stays as it is. No partner's allocation falls, so no reduction notice is owed under any agreement. Nagy is not owed notice because its agreement terminated on 2026-06-30, before the allocation was released.

`limit_allocation.csv` carries the per-key figures and the basis for each, including the burst capacity, which is twice the sustained allocation on every key.

## The question Finance asked

There is no room for another enterprise partner. A new Enterprise agreement cannot be written below 1,800 units per minute of aggregate commitment without Finance approval, and 360 units are available. Taking one at 1,800 would require a partner budget of 7,740, which at the fixed seventy-thirty split means platform capacity of at least **11,058 cost units per minute**, roughly 23 percent above today's 9,000. That is a capacity purchase, not an allocation exercise, and it needs to be on the table before anything is signed.

## Ostrander

No fair-use notice should be served. The fair-use clause bites on repeated disregard of `Retry-After`, and Ostrander has never been sent one; on 20 August it was never throttled at all. Its retries followed 504 timeouts, not 429s. Ship the headers, send the notice described below, and re-measure. If the behaviour persists once the client has something to obey, the clause is available and the evidence will support it.

## Enforcement changes

`rate_limiter.ts` replaces the current middleware. It keys on the authenticated API key, prices each request from the published cost weights, and holds a token bucket in the shared store through a single atomic call, so one allowance is spent across all six nodes rather than one per node. Refill is continuous, so there is no boundary to reset across; an idle key can spend its burst of twice the allowance plus one minute of refill, and no more. Throttled responses carry `Retry-After` alongside `RateLimit-Limit`, `RateLimit-Remaining` and `RateLimit-Reset`, and a throttling decision is never a 503. `GET /v3/health` is exempt and needs no key. Terminated keys are refused rather than served an allowance. Sandbox and internal keys are not enforced against a partner allocation.

`rate_limiter.spec.ts` covers each of those behaviours, including the two that caused the incident: that two partners behind one address hold independent buckets, and that a drained key does not recover its full allowance at a minute boundary.

## Rollout

1. Deploy the middleware in observe-only mode with the proposed allocations loaded. Decisions are computed and recorded, nothing is refused.
2. Run one full business week and compare the recorded refusals against real traffic. Expect none for any partner other than Ostrander, and none at all for the three Vogel keys.
3. Release the Nagy allocation and apply the Ekstrom increase. Neither owes notice; the Ekstrom change is an increase and takes effect on the next billing period as an amendment note.
4. Send the partner notice: the new headers, the requirement to honour `Retry-After`, exponential backoff with jitter, and no more than five retries. Give thirty days before enforcement even though no reduction is being made, so partners can adopt the headers first.
5. Promote to enforcing. Watch the 429 rate per key for a week.
6. Take the capacity question to Finance before any new enterprise agreement is signed.

## Validation

- Send 180 quote requests on a Growth key, confirm the 181st is refused with `Retry-After`, wait two seconds and confirm exactly three further quotes are admitted rather than a fresh 180.
- Issue requests on the Bratton and Kaplan keys from the same address and confirm draining one leaves the other untouched.
- Drive one key through two nodes at once against the shared store and confirm the total admitted is one allowance, not two.
- Confirm `GET /v3/health` succeeds with no key and consumes nothing.
- Confirm the Nagy key returns 403 rather than an allowance.
- Confirm the sandbox key is never refused, and that its 3,200 units never appear in a partner-budget total.
