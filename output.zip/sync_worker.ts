export type QueueEvent = {
  queue_id: string;
  event_key: string;
  device_id: string;
  device_seq: number;
  temp_id: string;
  server_id?: string;
  operation: string;
  payload_hash: string;
  base_revision: number;
};

export type Receipt = {
  event_key: string;
  payload_hash: string;
  result: string;
  server_id?: string;
  result_revision?: number;
};

export interface Store {
  pending(): Promise<QueueEvent[]>;
  receipt(key: string): Promise<Receipt[]>;
  mapping(temp: string): Promise<string | undefined>;
  checkpoint(event: QueueEvent, action: string, receipt?: Receipt): Promise<void>;
  quarantine(event: QueueEvent, reason: string): Promise<void>;
  commitCreate(event: QueueEvent, receipt: Receipt): Promise<void>;
}

export interface Api {
  send(event: QueueEvent, target: string): Promise<Receipt>;
}

class KeyedMutex {
  private tails = new Map<string, Promise<void>>();

  async run<T>(key: string, action: () => Promise<T>): Promise<T> {
    const previous = this.tails.get(key) ?? Promise.resolve();
    let release!: () => void;
    const current = new Promise<void>((resolve) => {
      release = resolve;
    });
    const tail = previous.then(() => current);
    this.tails.set(key, tail);
    await previous;
    try {
      return await action();
    } finally {
      release();
      if (this.tails.get(key) === tail) this.tails.delete(key);
    }
  }
}

const terminal = new Set(["TOMBSTONED", "FIELD_CONFLICT", "IDEMPOTENCY_COLLISION"]);

export async function flush(store: Store, api: Api): Promise<void> {
  const events = await store.pending();
  const devices = [...new Set(events.map((event) => event.device_id))];
  const eventKeyLocks = new KeyedMutex();
  const inspectionLocks = new KeyedMutex();

  // Each device owns one sequential lane. Different devices may run together,
  // but event-key and inspection locks prevent cross-lane overlap.
  await Promise.all(
    devices.map(async (device) => {
      const ordered = events
        .filter((event) => event.device_id === device)
        .sort((left, right) => left.device_seq - right.device_seq);

      for (const event of ordered) {
        const stopDevice = await eventKeyLocks.run(event.event_key, async () => {
          const prior = await store.receipt(event.event_key);
          const acknowledged = prior.find(
            (receipt) =>
              receipt.payload_hash === event.payload_hash &&
              (receipt.result === "APPLIED" || receipt.result === "CREATED"),
          );

          if (acknowledged) {
            if (event.operation === "CREATE" && acknowledged.server_id) {
              await store.commitCreate(event, acknowledged);
            } else {
              await store.checkpoint(event, "ACK_RECONCILED", acknowledged);
            }
            return false;
          }

          if (prior.some((receipt) => receipt.payload_hash !== event.payload_hash)) {
            await store.quarantine(event, "IDEMPOTENCY_COLLISION");
            return true;
          }

          const target =
            event.operation === "CREATE"
              ? "collection"
              : event.server_id ?? (await store.mapping(event.temp_id));

          if (!target) {
            await store.checkpoint(event, "WAITING_FOR_MAPPING");
            return false;
          }

          // A new create is locked by its temporary inspection identity. Every
          // existing record is locked by server ID, satisfying the contract's
          // one-active-event-per-inspection rule across device lanes.
          const inspectionKey =
            event.operation === "CREATE" ? `temp:${event.temp_id}` : `server:${target}`;

          return inspectionLocks.run(inspectionKey, async () => {
            let receipt: Receipt;
            try {
              receipt = await api.send(event, target);
            } catch {
              return true;
            }

            if (receipt.result === "CREATED" && receipt.server_id) {
              await store.commitCreate(event, receipt);
              return false;
            }
            if (receipt.result === "APPLIED") {
              await store.checkpoint(event, "APPLIED", receipt);
              return false;
            }
            if (terminal.has(receipt.result)) {
              await store.quarantine(event, receipt.result);
              return true;
            }
            if (
              receipt.result === "REVISION_CONFLICT" ||
              receipt.result === "ATTACHMENT_INCOMPLETE" ||
              receipt.result === "REQUIRED_ATTACHMENT_MISSING"
            ) {
              await store.checkpoint(event, "PREREQUISITE_OR_REBASE_REQUIRED", receipt);
              return false;
            }
            return true;
          });
        });

        if (stopDevice) break;
      }
    }),
  );
}

// Store.commitCreate must persist the mapping and queue acknowledgement in one
// transaction. A restart reloads pending rows and repeats receipt reconciliation
// before any mutation is selected.
