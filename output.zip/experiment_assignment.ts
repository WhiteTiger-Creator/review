export type Variant = "A" | "B";

const EXPERIMENT_ID = "EXP-HOME-27";
const ASSIGNMENT_VERSION = 3;

export interface HomepageAssignment {
  experimentId: "EXP-HOME-27";
  assignmentVersion: 3;
  sessionId: string;
  anonymousId: string;
  bucket: number;
  variant: Variant;
  assignmentToken: string;
}

interface HomepageRequest {
  sessionId: string;
  anonymousId: string;
  entryStatus: "PROSPECT" | "SUBSCRIBER";
  userAgentClass: "HUMAN" | "BOT";
  existingAssignment?: HomepageAssignment;
}

// The contract's assignment unit is eligible_session_anonymous_id: the same anonymousId must
// land on the same bucket on every call, with nothing supplied by the caller. FNV-1a is a
// stable, dependency-free hash; folding in the experiment ID and version keeps buckets from
// correlating across experiments or a version bump.
function bucketForAssignmentUnit(anonymousId: string): number {
  const unit = `${EXPERIMENT_ID}:v${ASSIGNMENT_VERSION}:${anonymousId}`;
  let hash = 0x811c9dc5;
  for (let i = 0; i < unit.length; i++) {
    hash ^= unit.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0) % 10000;
}

function variantAt(bucket: number): Variant {
  // bucketForAssignmentUnit only ever returns 0-9999, but the boundary check stays: a
  // 10,000-slot space is a contract fact, not an implementation detail to trust blindly.
  if (!Number.isInteger(bucket) || bucket < 0 || bucket >= 10000) {
    throw new RangeError(`homepage assignment bucket out of range: ${bucket}`);
  }
  return bucket < 5000 ? "A" : "B";
}

function belongsToRequest(saved: HomepageAssignment, req: HomepageRequest) {
  return saved.experimentId === EXPERIMENT_ID &&
    saved.assignmentVersion === ASSIGNMENT_VERSION &&
    saved.sessionId === req.sessionId &&
    saved.anonymousId === req.anonymousId;
}

export function assignmentForHomepage(req: HomepageRequest): HomepageAssignment | null {
  if (req.entryStatus === "SUBSCRIBER" || req.userAgentClass === "BOT") return null;

  // Keep the entry assignment when the anonymous visitor signs in. The old caller
  // swapped to userId once auth came back and bucketed the session a second time.
  if (req.existingAssignment) {
    if (!belongsToRequest(req.existingAssignment, req)) {
      throw new Error("homepage assignment does not belong to this session entry");
    }
    return req.existingAssignment;
  }

  const bucket = bucketForAssignmentUnit(req.anonymousId);
  const variant = variantAt(bucket);
  const assignmentToken = [
    EXPERIMENT_ID,
    `v${ASSIGNMENT_VERSION}`,
    req.sessionId,
    req.anonymousId,
    bucket,
    variant,
  ].join(":");

  return {
    experimentId: EXPERIMENT_ID,
    assignmentVersion: ASSIGNMENT_VERSION,
    sessionId: req.sessionId,
    anonymousId: req.anonymousId,
    bucket,
    variant,
    assignmentToken,
  };
}

export function homepageCacheSegment(a: HomepageAssignment) {
  // Only the arm-specific shell can be cached. The token is attached afterward.
  return `home:v${a.assignmentVersion}:${a.variant}`;
}

export function assignmentEnvelope(a: HomepageAssignment) {
  return {
    experimentId: a.experimentId,
    assignmentVersion: a.assignmentVersion,
    sessionId: a.sessionId,
    variant: a.variant,
    assignmentToken: a.assignmentToken,
  };
}
