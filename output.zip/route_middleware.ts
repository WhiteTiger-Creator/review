import { NextRequest, NextResponse } from 'next/server';

const MARKET_COOKIE = 'site_market';
const COOKIE_MAX_AGE = 60 * 60 * 24 * 180;
const TRACKING_KEYS = new Set([
  'utm_source', 'utm_medium', 'utm_campaign', 'utm_content',
  'utm_term', 'gclid', 'fbclid',
]);
const FILE_EXTENSION = /\.[^/]+$/;
const BYPASS_PREFIXES = ['/_next', '/assets', '/api', '/health'];
const BYPASS_FILES = new Set(['/robots.txt', '/sitemap.xml']);

// Derived from the completed approved_redirect_manifest.csv, not the old sample map.
// The release tables cover 31 cleared redirects, 11 retained routes, and 2
// retirements. Three UK pass-through rows use the legacy-origin branch below;
// the blocked water-treatment proposal is deliberately absent from active routing.
const PERMANENT_REDIRECTS = new Map<string, string>([
  ['/products/precision-pumps/ax-420', '/products/precision-pumps/ax-series-420'],
  ['/products/precision-pumps/ax-430', '/products/precision-pumps/ax-440'],
  ['/industries', '/solutions'],
  ['/industries/food-beverage', '/solutions/food-and-beverage'],
  ['/industries/pharmaceutical', '/solutions/pharma'],
  ['/resources', '/learning-center'],
  ['/resources/cavitation-guide', '/learning-center/avoiding-pump-cavitation'],
  ['/resources/pump-sizing-tool', '/tools/pump-selector'],
  ['/resources/vx-maintenance-checklist', '/support/library/vx-maintenance-checklist'],
  ['/support/rma', '/support/request-return'],
  ['/company', '/about'],
  ['/company/about', '/about'],
  ['/company/locations', '/about/locations'],
  ['/de', '/de-de'],
  ['/de/produkte', '/de-de/produkte'],
  ['/de/produkte/praezisionspumpen', '/de-de/produkte/praezisionspumpen'],
  ['/de/produkte/praezisionspumpen/ax-410', '/de-de/produkte/praezisionspumpen/ax-410'],
  ['/de/produkte/prozessventile', '/de-de/produkte/prozessventile'],
  ['/de/branchen', '/de-de/loesungen'],
  ['/de/branchen/lebensmittel-getraenke', '/de-de/loesungen/lebensmittel-und-getraenke'],
  ['/de/ressourcen', '/de-de/wissen'],
  ['/de/ressourcen/kavitationsleitfaden', '/de-de/wissen/pumpenkavitation-vermeiden'],
  ['/de/kontakt', '/de-de/support/kontakt'],
  ['/ca', '/en-ca'],
  ['/ca/products', '/en-ca/products'],
  ['/ca/products/precision-pumps', '/en-ca/products/precision-pumps'],
  ['/ca/products/process-valves/vx-10', '/en-ca/products/process-valves/vx-10'],
  ['/ca/industries/food-beverage', '/en-ca/solutions/food-and-beverage'],
  ['/ca/resources/cavitation-guide', '/en-ca/learning-center/avoiding-pump-cavitation'],
  ['/ca/support/contact', '/en-ca/support/contact'],
  ['/legal/privacy', '/legal/privacy-us'],
]);

const RETAINED_ROUTES = new Set([
  '/', '/products', '/products/precision-pumps',
  '/products/precision-pumps/ax-410', '/products/process-valves',
  '/products/process-valves/vx-8', '/products/process-valves/vx-10',
  '/support', '/support/contact', '/company/careers', '/legal/terms',
]);
const RETIRED_ROUTES = new Set(['/search', '/compare']);

function normalizedPath(pathname: string): string {
  const lower = pathname.toLowerCase();
  return lower !== '/' && lower.endsWith('/') ? lower.slice(0, -1) : lower;
}

function bypass(pathname: string): boolean {
  const lower = pathname.toLowerCase();
  return BYPASS_FILES.has(lower)
    || BYPASS_PREFIXES.some((prefix) => lower === prefix || lower.startsWith(`${prefix}/`))
    || FILE_EXTENSION.test(lower);
}

function sanitizedSearch(request: NextRequest): string {
  const kept = new URLSearchParams();
  for (const [key, value] of request.nextUrl.searchParams.entries()) {
    if (!TRACKING_KEYS.has(key.toLowerCase())) kept.append(key, value);
  }
  const query = kept.toString();
  return query ? `?${query}` : '';
}

function redirectTo(request: NextRequest, pathname: string): NextResponse {
  const target = request.nextUrl.clone();
  target.pathname = pathname;
  target.search = sanitizedSearch(request);
  return NextResponse.redirect(target, 308);
}

function setMarket(response: NextResponse, market: 'US' | 'DE' | 'CA'): void {
  response.cookies.set(MARKET_COOKIE, market, {
    path: '/', sameSite: 'lax', secure: true, maxAge: COOKIE_MAX_AGE,
  });
}

function rootMarket(request: NextRequest): 'US' | 'DE' | 'CA' {
  const cookie = request.cookies.get(MARKET_COOKIE)?.value;
  if (cookie === 'US' || cookie === 'DE' || cookie === 'CA') return cookie;
  const firstLanguage = (request.headers.get('accept-language') ?? '')
    .split(',')[0].trim().toLowerCase();
  return firstLanguage.startsWith('de') ? 'DE' : 'US';
}

export function middleware(request: NextRequest): NextResponse {
  const rawPath = request.nextUrl.pathname;
  if (bypass(rawPath)) return NextResponse.next();

  const path = normalizedPath(rawPath);

  // UK remains on the configured legacy origin. It is never locale-detected.
  if (path === '/uk' || path.startsWith('/uk/')) {
    const legacyOrigin = process.env.LEGACY_UK_ORIGIN;
    if (!legacyOrigin) return new NextResponse('Legacy UK origin is not configured', { status: 503 });
    const legacyUrl = new URL(`${path}${request.nextUrl.search}`, legacyOrigin);
    return NextResponse.rewrite(legacyUrl);
  }

  // Legacy market prefixes are explicit signals and resolve before root detection.
  const destination = PERMANENT_REDIRECTS.get(path);
  if (destination) return redirectTo(request, destination);
  if (RETIRED_ROUTES.has(path)) return new NextResponse(null, { status: 410 });

  // Normalize only routes proven to exist in the approved manifest.
  if (RETAINED_ROUTES.has(path) && rawPath !== path) return redirectTo(request, path);

  // Cookie and browser-language selection is restricted to the unprefixed root.
  if (path === '/') {
    const market = rootMarket(request);
    if (market === 'DE') return redirectTo(request, '/de-de');
    if (market === 'CA') return redirectTo(request, '/en-ca');
  }

  const response = NextResponse.next();
  if (path === '/de-de' || path.startsWith('/de-de/')) setMarket(response, 'DE');
  else if (path === '/en-ca' || path.startsWith('/en-ca/')) setMarket(response, 'CA');
  else if (!path.startsWith('/de') && !path.startsWith('/ca')) setMarket(response, 'US');
  return response;
}

export const config = { matcher: '/:path*' };
